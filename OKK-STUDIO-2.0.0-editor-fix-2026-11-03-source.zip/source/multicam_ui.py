"""Native multi-camera editing workspace for RTX Video Render Studio."""
from __future__ import annotations

from camera_display import camera_number, camera_id_for_number

import copy
from bisect import bisect_right
import math
import os
import json
import subprocess
import queue
import threading
import time
import uuid
import tempfile
import shutil
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from tkinter import font as tkfont

from editor_core import (align_audio_segments, format_time, format_signed_time,
                         parse_timecode, parse_signed_timecode, probe_media_duration,
                         normalize_video_bitrate)
from exporter_core import CREATE_NO_WINDOW, ExportCancelled, ExportSettings, find_binary, probe_media
from multicam_core import CameraClip, Cut, MulticamProject, render_multicam
from multicam_player import MulticamPlayer
from delivery_panel import init_delivery_variables, build_delivery_panel, make_delivery_settings
from creative_panel import build_creative_panel
from subtitle_core import subtitle_at
from multicam_frame_clock import canonical_frame_rate
from creative_core import ColorGrade, Transition, validate_grade, validate_transitions
from creative_render import plan_creative_segments
from program_edits import program_spans, program_media_spans, split_at, set_camera_on_range, set_grade_on_range, grade_at
from clip_transform import ClipTransform, transform_at, set_transform_on_range, validate_transform
from project_settings import DEFAULT_SETTINGS
from color_workspace import ColorWorkspace
from finishing_workspace import FinishingWorkspace
from effect_workspace import EffectsWorkspaceMixin
from stabilization_panel import open_stabilization_dialog
from image_stabilization_panel import open_image_stabilization_dialog
from cache_paths import cache_dir
from camera_metadata import CameraMetadata, read_camera_metadata
from auto_color_workspace import AutoColorWorkspaceMixin
from reference_sync import align_to_camera, align_camera_tracks, quantized_alignment_targets
from camera_import import batch_import
from camera_import_ui import CameraImportMixin
from timeline_interaction import TimelineInteractionMixin
from proxy_media import validate_proxy_media
from proxy_cache import register_proxy
from library_apply import LibraryApplyMixin
from multicam_proxy import MulticamProxyMixin
from clip_inspector import ClipInspector
from transport_controls import TransportControlsMixin
from workspace_docking import WorkspaceDockingMixin
from video_stack_ui import VideoStackUIMixin
from stack_preview_ui import StackPreviewUIMixin
from timeline_selection import TimelineSelectionMixin
from timeline_sync import TimelineSyncMixin, selected_video_clips, reference_audio_clips
from video_placement_ui import VideoPlacementMixin
from timeline_insert import TimelineInsertMixin
from timeline_merge_ui import TimelineMergeMixin
from preview_focus import PreviewFocusMixin
from timeline_audio_ui import TimelineAudioUIMixin
from timeline_markers_ui import TimelineMarkersMixin
from keyboard_edit_ui import KeyboardEditMixin
from camera_list_ui import CameraListUIMixin
from timeline_controls import TimelineControlsMixin
from timeline_link import preserve_source_audio, move_source_audio
from timeline_audio import source_audio_clips, master_audio_clips
from project_settings_ui import ProjectSettingsMixin
from playback_metrics import PlaybackMetricsUIMixin
from export_progress_ui import ExportProgressUIMixin, export_phase_text
from prerender_ui import PrerenderUIMixin
from timeline_import_ui import TimelineImportMixin
from timeline_view import TimelineViewMixin
from project_upgrade import read_project_snapshot, upgraded_standalone_payload, write_project_upgrade

BG = '#202124'
PANEL = '#292b2e'
INPUT = '#18191b'
INK = '#dedfe3'
MUTED = '#969ba3'
ACCENT = '#58a6d6'
PINK = '#ef675d'  # Playback and recording indicator, kept for compatibility.
GREEN = '#73aa9c'
COLORS = ['#496e87', '#4b8289', '#667e9e', '#64867c', '#7c718d', '#7e8870', '#807a65', '#557f92', '#8c7374']
VIDEO_TYPES = [('视频', '*.mp4 *.mov *.mkv *.mxf *.avi *.mts *.m2ts *.webm'), ('所有文件', '*.*')]


class MulticamWorkspace(ExportProgressUIMixin, VideoPlacementMixin, TimelineSyncMixin, TimelineViewMixin, TimelineImportMixin, PrerenderUIMixin, ProjectSettingsMixin, PlaybackMetricsUIMixin, TimelineControlsMixin, CameraListUIMixin, KeyboardEditMixin, TimelineAudioUIMixin, TimelineMarkersMixin, CameraImportMixin, PreviewFocusMixin, TimelineMergeMixin, TimelineInsertMixin, TimelineSelectionMixin, StackPreviewUIMixin, VideoStackUIMixin, WorkspaceDockingMixin, TransportControlsMixin, TimelineInteractionMixin, MulticamProxyMixin, LibraryApplyMixin, AutoColorWorkspaceMixin, EffectsWorkspaceMixin, tk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, bg=BG)
        self.app = app
        self.ui_scale = max(1.0, self.winfo_fpixels('1i') / 96.0)
        self._media_width = self._px(304)
        self._inspector_width = self._px(400)
        self._timeline_left = max(self._px(128), tkfont.Font(self, family='Microsoft YaHei UI', size=8).measure('A0 主音频 出声') + self._px(16))
        self._timeline_label_font = tkfont.Font(self, family='Microsoft YaHei UI', size=8)
        self._timeline_title_font = tkfont.Font(self, family='Microsoft YaHei UI', size=9)
        self._timeline_ruler_font = tkfont.Font(self, family='Cascadia Mono', size=8)
        self.project = MulticamProject()
        self.project_path = ''
        self.dirty = False
        self.undo_stack = []
        self.redo_stack = []
        self.current = 0.0
        self.playing = False
        self.busy = False
        self.sync_running = False
        self.sync_results = {}
        self.player = None
        self.player_queue = queue.Queue()
        self.jobs = queue.Queue()
        self.selected_cut = None
        self.selected_program_range = None
        self.grade_target = None
        self._grade_target_chosen = False
        self._grade_preview_after = None
        self._grade_preview_pending = None
        self._grade_preview_active = False
        self._color_mode = False
        self._timeline_saved_sash = None
        self.timeline_program_items = {}
        self.zoom = 1.0
        self.view_start = 0.0
        self.timeline_drag = None
        self.subtitle_drag = None
        self._init_timeline_interaction()
        self._init_timeline_selection()
        self._init_timeline_controls()
        self.timeline_subtitle_items = {}
        self.timeline_transition_items = {}
        self.timeline_audio_items = set()
        self._creative_preview_folder = None
        self._creative_preview_worker = None
        self._creative_preview_sequence = 0
        self._camera_metadata_cancel = threading.Event()
        self._camera_metadata_attempted = set()
        self._camera_metadata_worker = None
        self._displayed_camera = None
        self.camera_page=0
        self.camera_page_var=tk.StringVar(value='1/1')
        self.camera_rows = self.camera_columns = 3
        self.camera_rows_var = tk.StringVar(self, value='3')
        self.camera_columns_var = tk.StringVar(self, value='3')
        self._camera_grid_layout = None
        self._visible_camera_ids=()
        self._retired_camera_frames={}
        self._init_effects()
        self._init_auto_color()
        self.alive = True
        self.record_var = tk.BooleanVar(value=True)
        self.sync_mode_var = tk.StringVar(value='中段波形（推荐）')
        self.sync_reference_var=tk.StringVar(value='主音频')
        self._sync_reference_choices={'主音频':None}
        self._sync_reference_combos=[]
        self._alignment_reference_label='主音频'
        self.stabilization_compare_var=tk.BooleanVar(value=False)
        self._comparison_layout_enabled=False
        self._comparison_requested=None
        self.proxy_var = tk.BooleanVar(value=True)
        self.gpu_live_var = tk.BooleanVar(value=True)
        self._gpu_live_active = False
        self._gpu_live_failed = False
        self.status = tk.StringVar(value='导入素材后拖到时间线开始剪辑 · 空格播放 / 暂停 · 数字键 1–9 切换机位')
        self.time_var = tk.StringVar(value='00:00:00.000 / 00:00:00.000')
        self.master_var = tk.StringVar(value='主音频：尚未选择')
        self.offset_var = tk.StringVar(value='00:00:00.000')
        self.seek_var = tk.StringVar(value='00:00:00.000')
        self._seek_display_text = self.seek_var.get()
        self.start_var = tk.StringVar(value='00:00:00.000')
        self.end_var = tk.StringVar()
        self.cut_time_var = tk.StringVar()
        self.cut_camera_var = tk.StringVar(value='1')
        self.bitrate_var = tk.StringVar(value='80M')
        self.export_mode = tk.StringVar(value='自动（沿用统一编码设置）')
        self.fps_var = tk.StringVar(value='30')
        self.output_var = tk.StringVar()
        self.program_var = tk.StringVar(value='成片监看 · 机位 —')
        self.export_metrics_var = tk.StringVar(value='等待导出')
        self.export_speed_var = tk.StringVar(value='近3秒：— FPS · —×')
        self.export_elapsed_var = tk.StringVar(value='00:00:00')
        self.export_eta_var = tk.StringVar(value='—')
        self.export_phase_var = tk.StringVar(value='就绪')
        self.export_progress_var = tk.DoubleVar(value=0)
        self._export_started_at = None
        self._export_last_snapshot = {}
        init_delivery_variables(self)
        self._init_quick_proxy()
        self._init_video_stack_ui()
        self._init_stack_preview()
        self._init_transport_controls()
        self._init_timeline_audio()
        self._init_timeline_markers()
        self._init_playback_metrics()
        self._init_prerender()
        self._build()
        self._set_keyboard_tool('select')
        self._setup_camera_drop()
        self._init_workspace_docking()
        self._bind_timeline_interaction()
        self._bind_timeline_selection()
        self._bind_transport_controls()
        self._init_preview_focus()
        self._loading_fields = False
        for variable in (self.start_var, self.end_var, self.fps_var):
            variable.trace_add('write', self._field_changed)
        self.app.bind('<KeyPress>', self._key, add='+')
        self.after(80, self._poll)
        self._player_poll_after = self.after(8, self._poll_player)

    def _field_changed(self, *args):
        if not self._loading_fields:
            self._mark_dirty()

    def _px(self, value):
        return max(0, round(value * self.ui_scale))

    def _button(self, parent, text, command, **pack):
        button = ttk.Button(parent, text=text, command=command, style='Compact.TButton')
        button.pack(side='left', padx=self._px(2), pady=self._px(2), **pack)
        return button

    def _label(self, parent, text=None, variable=None):
        return tk.Label(parent, text=text, textvariable=variable, bg=parent.cget('bg'), fg=MUTED,
                        font=('Microsoft YaHei UI', 9), anchor='w')

    def _entry(self, parent, variable, width=15):
        return tk.Entry(parent, textvariable=variable, width=width, bg=INPUT, fg=INK,
                        insertbackground=INK, relief='flat', highlightthickness=1,
                        highlightbackground='#3a3c40', highlightcolor=ACCENT,
                        font=('Cascadia Mono', 10))

    def _clip_camera_label(self,clip):
        return CameraMetadata(clip.camera_make,clip.camera_model,clip.camera_metadata_source).camera_label

    def _label_camera(self,camera,time=None):
        if camera is None: return '机位 —'
        clip = self.project.clip_at(camera,self.current if time is None else time)
        if clip is None: clip = next((clip for clip in self.project.clips if clip.camera==camera),None)
        label = self.project.camera_names.get(camera) or (self._clip_camera_label(clip) if clip else '未知相机')
        return f'机位 {camera_number(self.project, camera)} · {label}'

    def _camera_context(self, event):
        row = self.media_tree.identify_row(event.y)
        if not row: return
        if row == 'source_library' or row.startswith('source::'):
            self.status.set('原片保留在素材库中；拖入时间线新建片段，删除时间线片段不会删除原片。')
            return 'break'
        if not row.startswith('camera_'):
            return self._clip_proxy_context(event, row)
        camera = int(row.split('_', 1)[1])
        if camera not in self.project.cameras: return
        self.media_tree.selection_set(row)
        self.media_tree.focus(row)
        menu = tk.Menu(self, tearoff=False, bg=PANEL, fg=INK, activebackground='#3c5263')
        state = 'normal' if not (self.busy or self.app.working) else 'disabled'
        menu.add_command(label='重命名机位…', command=lambda: self.rename_camera(camera), state=state)
        menu.add_command(label='恢复默认名称', command=lambda: self.reset_camera_name(camera),
                         state=state if camera in self.project.camera_names else 'disabled')
        menu.add_separator()
        menu.add_command(label='取消该机位全部代理（使用原片）',
                         command=lambda: self.unlink_material_proxies((row,)), state=state)
        previous = getattr(self, 'camera_context_menu', None)
        if previous is not None: previous.destroy()
        self.camera_context_menu = menu
        try: menu.tk_popup(event.x_root, event.y_root)
        finally: menu.grab_release()
        return 'break'

    def rename_camera(self, camera):
        if not self._available() or camera not in self.project.cameras: return
        initial = self._label_camera(camera).split(' · ', 1)[-1]
        while True:
            name = simpledialog.askstring('重命名机位', f'机位 {camera_number(self.project, camera)} 的新名称：',
                                          initialvalue=initial, parent=self)
            if name is None: return
            candidate = copy.deepcopy(self.project)
            try: candidate.set_camera_name(camera, name)
            except ValueError as error:
                messagebox.showerror('重命名机位', str(error), parent=self)
                initial = name
                continue
            if candidate.camera_names == self.project.camera_names: return
            self._remember()
            self.project.camera_names = candidate.camera_names
            self._refresh_camera_labels()
            self.draw_timeline()
            self.status.set(f'已重命名：{self._label_camera(camera)}')
            return

    def reset_camera_name(self, camera):
        if not self._available() or camera not in self.project.camera_names: return
        self._remember()
        del self.project.camera_names[camera]
        self._refresh_camera_labels()
        self.draw_timeline()
        self.status.set(f'已恢复默认名称：{self._label_camera(camera)}')

    def _camera_button_label(self,camera):
        visible=getattr(self,'_visible_camera_ids',())
        number = camera_number(self.project, camera)
        if camera in visible and (self.camera_columns > 3 or self.camera_rows > 3):
            index = visible.index(camera)+1
            number = f'{index}:{number}' if index <= 9 and index != number else str(number)
            name = self.project.camera_names.get(camera)
            return number + ' · ' + name if name else number
        if camera in visible and len(visible)>4:
            model=self._label_camera(camera).split(' · ',1)[-1]
            if model=='未知相机':model='未知'
            shortcut=visible.index(camera)+1
            return (f'{shortcut}:{number}' if shortcut!=number else str(number))+' '+model
        if camera in visible and visible.index(camera)+1 != number:
            return f'{visible.index(camera)+1} · {number}/'+self._label_camera(camera).split(' · ',1)[-1]
        return self._label_camera(camera)

    def _set_program_label(self,camera,preview=False):
        if self.project.video_stack_enabled and not preview:
            self.program_var.set(f'图层合成 · {len(self.project.stacked_cameras())} 层 · 选择 V{camera_number(self.project, self._displayed_camera or camera) or "—"}')
            return
        self._displayed_camera = camera
        if preview:
            text = self._label_camera(camera)+' · 效果预览'
        elif self._color_mode:
            scope = '所选片段' if self.grade_target=='selection' else '全片' if self.grade_target is None else '整机位'
            text = self._label_camera(camera)+f' · {scope}调色'
        else: text = self._label_camera(camera)+' · 成片监看'
        self.program_var.set(text)

    def _refresh_camera_labels(self):
        self._refresh_proxy_badges(force=True)
        for camera,button in self.camera_buttons.items():
            label = self._camera_button_label(camera)
            if button.cget('text') != label: button.configure(text=label)
        for camera in self.project.cameras:
            parent = f'camera_{camera}'
            if self.media_tree.exists(parent):
                pending = any(self._sync_clip_state(clip.id) == 'review' for clip in self.project.clips if clip.camera == camera)
                self.media_tree.item(parent, text=self._camera_tree_label(camera), tags=('review',) if pending else ())
        for clip in self.project.clips:
            if self.media_tree.exists(clip.id):
                tag = self._sync_clip_state(clip.id)
                self.media_tree.item(clip.id, text=self._camera_clip_tree_text(clip), tags=(tag,) if tag else ())
        self._refresh_sync_review()
        camera=self._displayed_camera if self._displayed_camera in self.project.cameras else self.project.camera_at(self.current)
        self._set_program_label(camera)
        self._refresh_sync_reference_choices()
        workspace=vars(self).get('color_workspace')
        panel=vars(workspace).get('auto_panel') if workspace is not None else None
        if panel is not None:panel.refresh_reference_choices()

    def _refresh_sync_reference_choices(self):
        self._sync_reference_choices={'主音频':None}
        self._sync_reference_choices.update({self._label_camera(camera):camera for camera in self._media_camera_order()})
        reference=self.project.alignment_reference_camera
        if reference not in self.project.cameras: self.project.alignment_reference_camera=reference=None
        label=next((label for label,value in self._sync_reference_choices.items() if value==reference),'主音频')
        self.sync_reference_var.set(label)
        for combo in self._sync_reference_combos:combo.configure(values=list(self._sync_reference_choices))

    def _sync_reference_changed(self,event=None):
        if self.busy or self.sync_running:
            self._refresh_sync_reference_choices();return
        reference=self._sync_reference_choices.get(self.sync_reference_var.get())
        if reference!=self.project.alignment_reference_camera:
            self.project.alignment_reference_camera=reference;self._mark_dirty()
            self.sync_results.clear()
            self._refresh_camera_labels()

    def _schedule_camera_metadata(self):
        if not self.alive or (self._camera_metadata_worker and self._camera_metadata_worker.is_alive()): return
        ffprobe = self.app.caps.ffprobe_path
        if not ffprobe or not Path(ffprobe).is_file(): return
        sources = []
        for clip in self.project.clips:
            if clip.camera_make or clip.camera_model: continue
            try:
                stat = Path(clip.path).stat();key=(clip.path,stat.st_size,stat.st_mtime_ns)
            except OSError: continue
            if key in self._camera_metadata_attempted: continue
            self._camera_metadata_attempted.add(key);sources.append((clip.id,clip.path))
        if not sources: return
        def worker():
            for identifier,path in sources:
                if self._camera_metadata_cancel.is_set(): return
                try: metadata=read_camera_metadata(path,ffprobe,cancel_event=self._camera_metadata_cancel)
                except Exception: metadata=CameraMetadata()
                self.jobs.put(('camera_metadata',(identifier,path,metadata)))
        self._camera_metadata_worker=threading.Thread(target=worker,name='camera-metadata',daemon=False)
        self._camera_metadata_worker.start()

    def _build(self):
        style = ttk.Style(self)
        font = tkfont.Font(self, family='Microsoft YaHei UI', size=10)
        style.configure('Multicam.Treeview', background=INPUT, fieldbackground=INPUT,
                        foreground=INK, borderwidth=0, font=('Microsoft YaHei UI', 10),
                        rowheight=font.metrics('linespace') + self._px(10))
        style.configure('Multicam.Treeview.Heading', background=PANEL, foreground=MUTED,
                        font=('Microsoft YaHei UI', 9))
        style.map('Multicam.Treeview', background=[('selected', '#3c5263')],
                  foreground=[('selected', INK)])
        style.configure('Multicam.TNotebook', background=PANEL, borderwidth=0)
        style.configure('Multicam.TNotebook.Tab', padding=(self._px(14), self._px(6)))
        style.configure('Multicam.TPanedwindow', background=INPUT, sashwidth=5)
        style.configure('Inspector.TButton', font=('Microsoft YaHei UI', 9), padding=(self._px(7), self._px(6)))
        style.configure('Inspector.Multicam.TNotebook.Tab', padding=(self._px(8), self._px(6)))
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        self._media_visible = True
        self._inspector_visible = False
        self._layout_initialized = False

        bar = tk.Frame(self, bg=PANEL, height=self._px(40))
        self.workspace_bar = bar
        bar.grid(row=0, column=0, sticky='ew')
        project_menu = tk.Menu(self, tearoff=False, bg=PANEL, fg=INK,
                               activebackground='#3c5263', activeforeground=INK)
        for title, action in [('新建工程', self.new), ('打开工程…', self.open), ('保存工程', self.save)]:
            project_menu.add_command(label=title, command=action)
        project_menu.add_command(label='导入时间线…', command=self.import_timeline)
        view_menu = tk.Menu(project_menu, tearoff=False)
        view_menu.add_command(label='合并显示为多机位时间线', command=lambda: self.set_multicam_timeline_view(True))
        view_menu.add_command(label='在时间线上打开多机位', command=lambda: self.set_multicam_timeline_view(False))
        project_menu.add_cascade(label='多机位时间线', menu=view_menu)
        project_menu.add_separator()
        project_menu.add_command(label='工程设置…', accelerator='Shift+9', command=self.show_project_settings)
        project_menu.add_command(label='操作说明', command=self.help)
        file_button = ttk.Menubutton(bar, text='文件 ▾', menu=project_menu, style='Compact.TMenubutton')
        file_button.pack(side='left', padx=(self._px(8), self._px(4)), pady=self._px(5))
        self._button(bar, '媒体池', self.toggle_media_pool)
        self.project_label = tk.Label(bar, text='未保存工程', bg=PANEL, fg=INK,
                                      font=('Microsoft YaHei UI', 10), anchor='w')
        self.project_label.pack(side='left', padx=self._px(14))
        self._button(bar, '撤销', self.undo)
        self._button(bar, '重做', self.redo)
        self.inspector_button = ttk.Button(bar, text='检查器', command=self.show_inspector,
                                           style='Compact.TButton')
        self.inspector_button.pack(side='right', padx=(self._px(2), self._px(8)), pady=self._px(5))

        self.workspace_split = ttk.Panedwindow(self, orient='vertical', style='Multicam.TPanedwindow')
        self.workspace_split.grid(row=1, column=0, sticky='nsew', pady=(self._px(1), self._px(0)))
        self.body = ttk.Panedwindow(self.workspace_split, orient='horizontal', style='Multicam.TPanedwindow')
        self.workspace_split.add(self.body, weight=3)
        self.sidebar = tk.Frame(self.body, bg=PANEL, width=self._media_width)
        self.sidebar.pack_propagate(False)
        self.body.add(self.sidebar, weight=0)
        self.tools = ttk.Notebook(self.sidebar, style='Multicam.TNotebook')
        self.tools.pack(fill='both', expand=True, padx=self._px(1), pady=(self._px(0), self._px(1)))
        media_tab = self.media_tab = tk.Frame(self, bg=PANEL)
        edit_tab = self.cut_tab = tk.Frame(self, bg=PANEL)
        self.tools.add(media_tab, text='素材')
        self.tools.add(edit_tab, text='切点')

        line = tk.Frame(media_tab, bg=PANEL)
        line.pack(fill='x', padx=self._px(5), pady=self._px(5))
        ttk.Button(line, text='＋ 导入素材', command=self.add_camera,
                   style='Compact.TButton').pack(side='left', padx=self._px(2))
        import_menu = ttk.Menubutton(line, text='导入 ▾', style='Compact.TButton')
        import_menu.pack(side='left', padx=self._px(2))
        menu = tk.Menu(import_menu, tearoff=False, bg=PANEL, fg=INK)
        menu.add_command(label='导入视频…', command=self.add_camera)
        menu.add_command(label='导入分段视频…', command=self.add_camera_parts)
        menu.add_command(label='导入文件夹（含子文件夹）…', command=self.add_camera_folder)
        import_menu.configure(menu=menu)
        self._button(line, '追加到机位', self.append_clips)
        self._button(line, '移除', self.remove_clip)
        self._build_camera_list_tools(media_tab)
        tree_frame = tk.Frame(media_tab, bg=INPUT)
        tree_frame.pack(fill='both', expand=True, padx=self._px(6))
        self.media_tree = ttk.Treeview(tree_frame, columns=('start', 'duration'), show='tree headings',
                                       height=5, selectmode='browse', style='Multicam.Treeview')
        self.media_tree.heading('#0', text='机位 / 素材')
        self.media_tree.heading('start', text='起点')
        self.media_tree.heading('duration', text='时长')
        self.media_tree.column('#0', width=self._px(140), minwidth=self._px(95))
        self.media_tree.column('start', width=self._px(78), minwidth=self._px(65))
        self.media_tree.column('duration', width=self._px(65), minwidth=self._px(55))
        self.media_tree.pack(side='left', fill='both', expand=True)
        ttk.Scrollbar(tree_frame, orient='vertical', command=self.media_tree.yview).pack(side='right', fill='y')
        self.media_tree.configure(yscrollcommand=tree_frame.winfo_children()[-1].set)
        self.media_tree.bind('<<TreeviewSelect>>', self._select_clip)
        self.media_tree.bind('<Double-1>', self._jump_clip)
        self.media_tree.bind('<Button-3>', self._camera_context)
        self.media_tree.bind('<BackSpace>', self._delete_media_selection)
        self.media_tree.bind('<Delete>', self._delete_media_selection)
        self.media_tree.bind('<<TreeviewOpen>>', self._queue_camera_fold_update, add='+')
        self.media_tree.bind('<<TreeviewClose>>', self._queue_camera_fold_update, add='+')
        reference_row=tk.Frame(media_tab,bg=PANEL)
        reference_row.pack(fill='x',padx=self._px(8),pady=self._px(3))
        tk.Label(reference_row,text='对齐参考',bg=PANEL,fg=MUTED,font=('Microsoft YaHei UI',9)).pack(side='left')
        reference_combo=ttk.Combobox(reference_row,textvariable=self.sync_reference_var,state='readonly',width=18)
        reference_combo.pack(side='left',fill='x',expand=True,padx=self._px(5))
        reference_combo.bind('<<ComboboxSelected>>',self._sync_reference_changed)
        self._sync_reference_combos.append(reference_combo)
        self.media_tree.tag_configure('synced', foreground=GREEN)
        self.media_tree.tag_configure('review', foreground='#d3b880')
        self._label(media_tab, variable=self.master_var).pack(fill='x', padx=self._px(9), pady=(self._px(7), self._px(2)))
        line = tk.Frame(media_tab, bg=PANEL)
        line.pack(fill='x', padx=self._px(5), pady=(self._px(0), self._px(6)))
        self._button(line, '主音频…', self.choose_master)
        self._button(line, '同步并对齐', self.auto_align)
        self._button(line, '精调', lambda: self.show_inspector('clip'))

        cut_frame = tk.Frame(edit_tab, bg=INPUT)
        cut_frame.pack(fill='both', expand=True, padx=self._px(6), pady=self._px(6))
        self.cut_tree = ttk.Treeview(cut_frame, columns=('time', 'camera'), show='headings',
                                     height=5, selectmode='browse', style='Multicam.Treeview')
        self.cut_tree.heading('time', text='切换时间')
        self.cut_tree.heading('camera', text='机位')
        self.cut_tree.column('time', width=self._px(190), minwidth=self._px(120))
        self.cut_tree.column('camera', width=self._px(55), minwidth=self._px(40), anchor='center')
        self.cut_tree.pack(side='left', fill='both', expand=True)
        cut_scroll = ttk.Scrollbar(cut_frame, orient='vertical', command=self.cut_tree.yview)
        cut_scroll.pack(side='right', fill='y')
        self.cut_tree.configure(yscrollcommand=cut_scroll.set)
        self.cut_tree.bind('<<TreeviewSelect>>', self._select_cut)
        self.cut_tree.bind('<Double-1>', self._jump_cut)
        line = tk.Frame(edit_tab, bg=PANEL)
        line.pack(fill='x', padx=self._px(8), pady=(self._px(2), self._px(5)))
        self._entry(line, self.cut_time_var, 15).pack(side='left', fill='x', expand=True, ipady=self._px(5))
        self.cut_camera_combo = ttk.Combobox(line, textvariable=self.cut_camera_var, values=(),
                     width=4, state='readonly')
        self.cut_camera_combo.pack(side='left', padx=(self._px(6), self._px(0)))
        line = tk.Frame(edit_tab, bg=PANEL)
        line.pack(fill='x', padx=self._px(5), pady=(self._px(0), self._px(6)))
        self._button(line, '更新切点', self.edit_cut)
        self._button(line, '删除', self.delete_cut)

        self.monitors = tk.Frame(self.body, bg=BG)
        self.body.add(self.monitors, weight=1)
        self.monitors.grid_columnconfigure(0, weight=1)
        self.monitors.grid_rowconfigure(0, weight=1)
        monitor_body = self.monitor_body = tk.Frame(self.monitors, bg=INPUT)
        monitor_body.grid(row=0, column=0, sticky='nsew')
        monitor_body.grid_columnconfigure(0, weight=1, uniform='monitor')
        monitor_body.grid_columnconfigure(1, weight=1, uniform='monitor')
        monitor_body.grid_rowconfigure(0, weight=1)
        source = self.source_panel = tk.Frame(self, bg=BG)
        source.grid(in_=monitor_body, row=0, column=0, sticky='nsew', padx=(self._px(0), self._px(2)))
        source.grid_columnconfigure(0, weight=1)
        source.grid_rowconfigure(1, weight=1)
        source_title = self.source_title = tk.Frame(source, bg=PANEL, height=self._px(30))
        source_title.grid(row=0, column=0, sticky='ew')
        tk.Label(source_title, text='多机位', bg=PANEL, fg=INK,
                 font=('Microsoft YaHei UI', 10)).pack(side='left', padx=self._px(10), pady=self._px(5))
        self.source_fps_label = tk.Label(source_title, textvariable=self.source_fps_var, bg=PANEL, fg=GREEN,
            font=('Cascadia Mono', 9))
        self.source_fps_label.pack(side='left', padx=self._px(6))
        self.release_cache_button = ttk.Button(source_title, text='释放缓存',
            command=self.unload_preview_cache, style='Compact.TButton')
        self.release_cache_button.pack(side='right', padx=self._px(3))
        self.camera_pager=tk.Frame(source_title,bg=PANEL)
        self.camera_prev=ttk.Button(self.camera_pager,text='‹',width=2,command=lambda:self._change_camera_page(-1),style='Compact.TButton')
        self.camera_prev.pack(side='left')
        tk.Label(self.camera_pager,textvariable=self.camera_page_var,bg=PANEL,fg=MUTED,font=('Cascadia Mono',8)).pack(side='left',padx=self._px(2))
        self.camera_next=ttk.Button(self.camera_pager,text='›',width=2,command=lambda:self._change_camera_page(1),style='Compact.TButton')
        self.camera_next.pack(side='left')
        self.camera_shortcut_hint=tk.Label(source_title,text='1–9',bg=PANEL,fg=MUTED,font=('Microsoft YaHei UI',9))
        self.camera_shortcut_hint.pack(side='right',padx=self._px(4))
        proxy_tools = tk.Frame(source, bg=PANEL)
        proxy_tools.grid(row=1, column=0, sticky='ew')
        self._build_quick_proxy_controls(proxy_tools)
        self.camera_grid_toolbar = tk.Frame(source, bg=PANEL)
        self.camera_grid_toolbar.grid(row=2, column=0, sticky='ew')
        tk.Label(self.camera_grid_toolbar, text='网格', bg=PANEL, fg=MUTED,
                 font=('Microsoft YaHei UI', 8)).pack(side='left', padx=(self._px(5), self._px(3)))
        for label, variable in (('行', self.camera_rows_var), ('列', self.camera_columns_var)):
            tk.Label(self.camera_grid_toolbar, text=label, bg=PANEL, fg=INK,
                     font=('Microsoft YaHei UI', 8)).pack(side='left', padx=self._px(2))
            choice = ttk.Combobox(self.camera_grid_toolbar, textvariable=variable,
                                 values=tuple(str(value) for value in range(1, 7)), width=2, state='readonly')
            choice.pack(side='left', padx=self._px(2), pady=self._px(2))
            choice.bind('<<ComboboxSelected>>', self._apply_camera_grid)
        tk.Label(self.camera_grid_toolbar, text='1–9 前9格 · 其余点选', bg=PANEL, fg=MUTED,
                 font=('Microsoft YaHei UI', 8)).pack(side='left', padx=self._px(5))
        self.camera_grid = tk.Frame(source, bg=INPUT)
        source.grid_rowconfigure(1, weight=0)
        source.grid_rowconfigure(2, weight=0)
        source.grid_rowconfigure(3, weight=1)
        self.camera_grid.grid(row=3, column=0, sticky='nsew')
        program = self.program_panel = tk.Frame(self, bg=BG)
        program.grid(in_=monitor_body, row=0, column=1, sticky='nsew', padx=(self._px(2), self._px(0)))
        program.grid_columnconfigure(0, weight=1)
        program.grid_rowconfigure(1, weight=1)
        program_title=self.program_title=tk.Frame(program,bg=PANEL)
        program_title.grid(row=0,column=0,sticky='ew')
        self.program_fullscreen_button=ttk.Button(program_title,text='全屏 (F11)',
            command=self._toggle_program_fullscreen,style='Compact.TButton')
        self.program_fullscreen_button.pack(side='right',padx=self._px(4))
        self.compare_button=tk.Checkbutton(program_title,text='防抖对比',variable=self.stabilization_compare_var,
            command=self.toggle_stabilization_compare,bg=PANEL,fg=INK,activebackground=PANEL,activeforeground=INK,
            selectcolor=INPUT,font=('Microsoft YaHei UI',9),state='disabled')
        self.compare_button.pack(side='right',padx=self._px(4))
        tk.Checkbutton(program_title,text='GPU 实时',variable=self.gpu_live_var,
            command=self._toggle_gpu_live,bg=PANEL,fg=ACCENT,activebackground=PANEL,
            activeforeground=INK,selectcolor=INPUT,font=('Microsoft YaHei UI',9)).pack(side='right')
        tk.Label(program_title, textvariable=self.program_var, bg=PANEL, fg=INK,
                 font=('Microsoft YaHei UI', 10), anchor='w', padx=self._px(10), pady=self._px(5)).pack(side='left')
        self.program_fps_label = tk.Label(program_title, textvariable=self.program_fps_var, bg=PANEL, fg=GREEN,
            font=('Cascadia Mono', 9), anchor='w')
        self.program_fps_label.pack(side='left', padx=self._px(6))
        self.program_viewport = tk.Frame(program, bg='#0e0f10', width=self._px(280), height=self._px(180))
        self.program_viewport.grid(row=1, column=0, sticky='nsew')
        self.program_surface = tk.Frame(self.program_viewport, bg='#0e0f10')
        self.program_surface.place(x=0, y=0, relwidth=1, relheight=1)
        self.program_viewport.bind('<Configure>', self._update_program_canvas)
        self.program_views = [tk.Frame(self.program_surface, bg='#0e0f10') for _ in range(2)]
        for view in self.program_views:
            view.place(x=0, y=0, relwidth=1, relheight=1)
        self._program_front_window = self.program_views[0].winfo_id()
        self.program_views[0].lift()
        self.comparison_views=[tk.Frame(self.program_surface,bg='#0e0f10') for _ in range(2)]
        self._comparison_front_window=self.comparison_views[0].winfo_id()
        self.comparison_original_label=tk.Label(self.program_surface,text='原片 · 完整视野',bg=PANEL,fg=INK,
            font=('Microsoft YaHei UI',9),anchor='center')
        self.comparison_stabilized_label=tk.Label(self.program_surface,text='防抖后 · 含裁切',bg=PANEL,fg=ACCENT,
            font=('Microsoft YaHei UI',9),anchor='center')
        self._build_stack_preview()
        self.audio_surface = tk.Frame(program, bg=BG, width=1, height=1)
        self.audio_surface.place(x=0, y=0, width=1, height=1)
        self.camera_frames = {}
        self.camera_surfaces = {}
        self.camera_buttons = {}
        self._show_empty_media()

        transport = tk.Frame(self.monitors, bg=PANEL)
        transport.grid(row=1, column=0, sticky='ew', pady=(self._px(1), self._px(0)))
        self._button(transport, '监看', self.start_monitors)
        self._button(transport, '◀|', lambda: self.step_frame(-1))
        self._button(transport, '▶ / Ⅱ', self.toggle)
        self._button(transport, '|▶', lambda: self.step_frame(1))
        self._button(transport, '回放', self.replay)
        tk.Checkbutton(transport, text='记录', variable=self.record_var, bg=PANEL, fg=PINK,
                       activebackground=PANEL, activeforeground=PINK, selectcolor=INPUT,
                       font=('Microsoft YaHei UI', 9), borderwidth=0).pack(side='left', padx=(self._px(8), self._px(4)))
        self._label(transport, variable=self.time_var).pack(side='right', padx=self._px(9))

        timeline_section = tk.Frame(self, bg=BG, height=self._px(230))
        self.timeline_section = timeline_section
        timeline_section.grid_columnconfigure(0, weight=1)
        timeline_section.grid_rowconfigure(2, weight=1)
        self.workspace_split.add(timeline_section, weight=2)
        self._build_timeline_resize_grip(timeline_section)
        timeline_bar = self.timeline_bar = tk.Frame(timeline_section, bg=PANEL)
        timeline_bar.grid(row=1, column=0, sticky='ew', pady=(self._px(1), self._px(0)))
        tk.Label(timeline_bar, text='时间线', bg=PANEL, fg=INK,
                 font=('Microsoft YaHei UI', 10)).pack(side='left', padx=self._px(10))
        self.seek_entry = self._entry(timeline_bar, self.seek_var, 13)
        self.seek_entry.pack(side='left', padx=(self._px(5), self._px(2)), pady=self._px(5), ipady=self._px(2))
        self.seek_entry.bind('<Return>', self.seek_text)
        self.seek_entry.bind('<KP_Enter>', self.seek_text)
        self.seek_entry.bind('<FocusOut>', self.seek_text)
        self.seek_entry.bind('<Escape>', self._cancel_seek_text)
        self._button(timeline_bar, '定位', self.seek_text)
        self._button(timeline_bar, '−', lambda: self.change_zoom(0.5))
        self._button(timeline_bar, '适配', self.fit_timeline)
        self._button(timeline_bar, '＋', lambda: self.change_zoom(2))
        self._button(timeline_bar, '标记 M', self.add_timeline_marker)
        self._build_timeline_controls(timeline_bar)
        self._build_video_stack_control(timeline_bar)
        self._build_timeline_size_control(timeline_bar)
        self._keyboard_hint_var = tk.StringVar(self)
        tk.Label(timeline_bar, textvariable=self._keyboard_hint_var, bg=PANEL, fg=MUTED,
                 font=('Microsoft YaHei UI', 9)).pack(side='right', padx=self._px(10))
        self.timeline = tk.Canvas(timeline_section, bg='#222427', height=self._px(200), highlightthickness=0)
        self.timeline.grid(row=2, column=0, sticky='nsew')
        self.timeline.bind('<Configure>', lambda e: self.draw_timeline())
        self.timeline.bind('<Configure>', self._queue_timeline_view_restore, add='+')
        self.timeline.bind('<Map>', self._queue_timeline_view_restore, add='+')
        self.timeline.bind('<ButtonPress-1>', self.timeline_press)
        self.timeline.bind('<B1-Motion>', self.timeline_motion)
        self.timeline.bind('<ButtonRelease-1>', self.timeline_release)
        self.timeline.bind('<Button-3>', self.timeline_context)
        self.timeline.configure(takefocus=True)
        self.timeline.bind('<Shift-MouseWheel>', self.pan_timeline)
        self.scroll = ttk.Scrollbar(timeline_section, orient='horizontal', command=self._scroll_timeline)
        self.scroll.grid(row=3, column=0, sticky='ew')
        self.timeline.configure(xscrollcommand=self.scroll.set)
        self.timeline_vscroll = ttk.Scrollbar(timeline_section, orient='vertical', command=self.timeline.yview)
        self.timeline_vscroll.grid(row=2, column=1, sticky='ns')
        self.timeline.configure(yscrollcommand=self.timeline_vscroll.set)
        self.timeline_vscroll.grid_remove()
        footer = tk.Frame(self, bg=BG)
        footer.grid(row=3, column=0, sticky='ew', padx=self._px(8), pady=(self._px(4), self._px(3)))
        self._label(footer, variable=self.status).pack(side='left', fill='x', expand=True)
        self.project_settings_button = ttk.Button(footer, text='⚙ 工程设置', command=self.show_project_settings, style='Compact.TButton')
        self.project_settings_button.pack(side='right')
        self._build_inspector()
        self.color_workspace = ColorWorkspace(self, self)
        self.finishing_workspace = FinishingWorkspace(self, self)
        self._build_export_monitor()
        self.bind('<Configure>', self._initial_layout, add='+')
        self.after_idle(self._initial_layout)

    def _show_empty_media(self):
        empty = tk.Frame(self.camera_grid, bg=INPUT)
        self._empty_camera_widget=empty
        empty.place(relx=.5, rely=.5, anchor='center')
        self.empty_label = tk.Label(empty, text='从素材库拖到时间线开始剪辑', bg=INPUT, fg=INK,
                                     font=('Microsoft YaHei UI', 12))
        self.empty_label.pack(pady=(self._px(0), self._px(8)))
        ttk.Button(empty, text='＋ 导入相机素材', command=self.add_camera,
                   style='Compact.TButton').pack()
        tk.Label(empty, text='导入只添加到素材库，拖放决定位置与轨道', bg=INPUT, fg=MUTED,
                 font=('Microsoft YaHei UI', 9)).pack(pady=(self._px(8), self._px(0)))

    def _initial_layout(self, event=None):
        if self._layout_initialized or not self.winfo_ismapped() or self.winfo_width() < 600:
            return
        self._layout_initialized = True
        self.update_idletasks()
        try:
            self.body.sashpos(0, min(self._media_width, max(self._px(180), round(self.body.winfo_width() * .28))))
            available = self.workspace_split.winfo_height()
            self.workspace_split.sashpos(0, max(self._px(160), round(available * .59)))
        except tk.TclError:
            pass

    def toggle_media_pool(self):
        if self._media_visible:
            self.body.forget(self.sidebar)
        else:
            self.body.insert(0, self.sidebar, weight=0)
            self.update_idletasks()
            self.body.sashpos(0, min(self._media_width, max(self._px(180), round(self.body.winfo_width() * .28))))
        self._media_visible = not self._media_visible

    def _inspector_panel(self, name):
        outer = tk.Frame(self, bg=PANEL)
        self.inspector_tabs.add(outer, text=name)
        canvas = tk.Canvas(outer, bg=PANEL, highlightthickness=0, width=self._px(278))
        scrollbar = ttk.Scrollbar(outer, orient='vertical', command=canvas.yview)
        scrollbar.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)
        canvas.configure(yscrollcommand=scrollbar.set)
        inner = tk.Frame(canvas, bg=PANEL)
        window = canvas.create_window(0, 0, window=inner, anchor='nw')
        inner.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>', lambda e: canvas.itemconfigure(window, width=e.width))
        return outer, inner

    def _section(self, parent, title):
        tk.Label(parent, text=title, bg=PANEL, fg=INK, anchor='w',
                 font=('Microsoft YaHei UI', 10, 'bold')).pack(fill='x', padx=self._px(12), pady=(self._px(16), self._px(7)))

    def _setting_row(self, parent, title, variable, width=14):
        row = tk.Frame(parent, bg=PANEL)
        row.pack(fill='x', padx=self._px(12), pady=self._px(5))
        tk.Label(row, text=title, bg=PANEL, fg=MUTED, anchor='w',
                 font=('Microsoft YaHei UI', 9)).pack(side='left')
        field = self._entry(row, variable, width)
        field.pack(side='right', ipady=self._px(5))
        return field

    def _build_inspector(self):
        self.inspector = tk.Frame(self.body, bg=PANEL, width=self._inspector_width)
        self.inspector.pack_propagate(False)
        title = tk.Frame(self.inspector, bg=PANEL)
        title.pack(fill='x')
        tk.Label(title, text='检查器', bg=PANEL, fg=INK,
                 font=('Microsoft YaHei UI', 10)).pack(side='left', padx=self._px(12), pady=self._px(7))
        ttk.Button(title, text='关闭', command=self.hide_inspector,
                   style='Compact.TButton').pack(side='right', padx=self._px(4))
        self.inspector_tabs = ttk.Notebook(self.inspector, style='Inspector.Multicam.TNotebook')
        self.inspector_tabs.pack(fill='both', expand=True)
        self.program_inspector_tab = tk.Frame(self, bg=PANEL)
        self.inspector_tabs.add(self.program_inspector_tab, text='片段')
        self.library_tab = tk.Frame(self, bg=PANEL)
        self.inspector_tabs.add(self.library_tab, text='特效库')
        self.clip_tab, clip = self._inspector_panel('同步')
        self.delivery_tab = tk.Frame(self, bg=PANEL)
        self.inspector_tabs.add(self.delivery_tab, text='交付')
        self._section(clip, '同步精调')
        tk.Label(clip,text='对齐参考（固定该轨道）',bg=PANEL,fg=MUTED,font=('Microsoft YaHei UI',9)).pack(
            anchor='w',padx=self._px(12))
        reference_combo=ttk.Combobox(clip,textvariable=self.sync_reference_var,state='readonly')
        reference_combo.pack(fill='x',padx=self._px(12),pady=self._px(4))
        reference_combo.bind('<<ComboboxSelected>>',self._sync_reference_changed)
        self._sync_reference_combos.append(reference_combo)
        ttk.Combobox(clip, textvariable=self.sync_mode_var, state='readonly',
                     values=['中段波形（推荐）', '完整波形（手动选择）']).pack(
                         fill='x', padx=self._px(12), pady=self._px(5))
        tk.Label(clip, text='先在媒体池中选择一个片段', bg=PANEL, fg=MUTED,
                 font=('Microsoft YaHei UI', 9), anchor='w').pack(fill='x', padx=self._px(12))
        self._setting_row(clip, '主时间起点', self.offset_var)
        line = tk.Frame(clip, bg=PANEL)
        line.pack(fill='x', padx=self._px(8), pady=self._px(3))
        self._button(line, '− 1帧', lambda: self.nudge(-1))
        self._button(line, '＋ 1帧', lambda: self.nudge(1))
        self._button(line, '应用', self.apply_offset)
        ttk.Button(clip, text='自动对齐所选视频…', command=self.align_selected,
                   style='Compact.TButton').pack(fill='x', padx=self._px(12), pady=self._px(5))
        self._section(clip, '主音频')
        ttk.Button(clip, text='选择连续主录音…', command=self.choose_master,
                   style='Compact.TButton').pack(fill='x', padx=self._px(12), pady=self._px(4))
        ttk.Button(clip, text='选中片段作为主音频', command=self.master_from_clip,
                   style='Compact.TButton').pack(fill='x', padx=self._px(12), pady=self._px(4))
        self._section(clip, '预览代理')
        tk.Checkbutton(clip, text='优先使用代理', variable=self.proxy_var,
                       command=self._configure_player, bg=PANEL, fg=INK, selectcolor=INPUT,
                       activebackground=PANEL, activeforeground=INK,
                       font=('Microsoft YaHei UI', 9)).pack(anchor='w', padx=self._px(8))
        ttk.Button(clip, text='指定选中片段代理…', command=self.choose_proxy,
                   style='Compact.TButton').pack(fill='x', padx=self._px(12), pady=self._px(5))
        tk.Label(clip, text='预览使用代理，导出使用原片', bg=PANEL, fg=MUTED,
                 font=('Microsoft YaHei UI', 9), anchor='w').pack(fill='x', padx=self._px(12), pady=(self._px(2), self._px(14)))

        build_delivery_panel(self, self.delivery_tab)
        self.creative_tab = build_creative_panel(self, self.inspector_tabs)
        self.inspector_tabs.tab(self.creative_tab, text='创作')
        for position, page in enumerate((self.program_inspector_tab, self.creative_tab,
                                         self.library_tab, self.clip_tab, self.delivery_tab)):
            self.inspector_tabs.insert(position, page)
        self.clip_inspector = ClipInspector(self.program_inspector_tab, self)
        self.clip_inspector.pack(fill='both', expand=True)
        self.inspector_tabs.bind('<<NotebookTabChanged>>', self._inspector_tab_changed, add='+')
        self.library_tab.bind('<Map>', self._ensure_effects_library, add='+')

    def _inspector_tab_changed(self, _event=None):
        if self.inspector_tabs.select() == str(self.library_tab) and vars(self).get('effects_browser') is None:
            self.show_effects_library()

    def show_inspector(self, section=None):
        if self._inspector_visible and section is None:
            self.hide_inspector()
            return
        if vars(self).get('dock_manager') is None:
            self._show_inspector_host()
        if section in {'color', 'transition', 'subtitle'}:
            if section == 'color' and self.selected_program_range is not None and not self._color_mode:
                self.set_grade_target('selection')
            self._select_workspace_page(self.inspector_tabs, self.creative_tab)
            self.creative_panel.select(section)
        elif section == 'library':
            self._select_workspace_page(self.inspector_tabs, self.library_tab)
        else:
            self._select_workspace_page(self.inspector_tabs,
                self.delivery_tab if section == 'delivery' else self.clip_tab
                if section == 'clip' else self.program_inspector_tab)
            if vars(self).get('clip_inspector'): self.clip_inspector.refresh()
        self.inspector_button.configure(text='检查器 ●' if self._inspector_visible else '检查器')

    def hide_inspector(self):
        if self._inspector_visible:
            self.body.forget(self.inspector)
            self._inspector_visible = False
        self.inspector_button.configure(text='检查器')

    def show_delivery(self):
        if 'delivery' in getattr(self.app, 'page_frames', {}):
            self.app._select_page('delivery')
            return
        self.exit_color_workspace()
        self.show_inspector('delivery')
        self._ensure_delivery_height()


    def show_creative(self, section='color'):
        if section == 'color':
            self.enter_color_workspace()
            return
        self.show_inspector(section)
        if section == 'color':
            self.enter_color_workspace()
        else:
            self.exit_color_workspace()
            self._ensure_delivery_height()


    def show_inspector_tool(self, section):
        if section == 'color':
            self.enter_color_workspace()
            return
        self.exit_color_workspace()
        if section == 'transition':
            self.show_inspector('edit')
            self.clip_inspector.scroll_to('transition')
        else:
            self.show_inspector(section)


    def show_effects_library(self):
        from effects_browser import show_effects_browser
        browser = show_effects_browser(self)
        self._tag_transport_widgets(browser)
        return browser

    def _ensure_effects_library(self, _event=None):
        if not self.alive or vars(self).get('effects_browser') is not None: return
        from effects_browser import ensure_effects_browser
        browser = ensure_effects_browser(self)
        self._tag_transport_widgets(browser)

    def _program_span_at(self, time):
        spans = program_media_spans(self.project)
        if not spans: return None
        frame = max(0, min(math.floor(float(time) * self.project.fps + .5),
                           math.floor(self.project.duration * self.project.fps + .5) - 1))
        return next((span for span in spans
            if math.floor(span.start*self.project.fps+.5) <= frame < math.floor(span.end*self.project.fps+.5)), None)

    def select_program_range(self, start, end, seek=True):
        if not self._available() or self.project.duration <= 0: return
        fps = self.project.fps
        last = math.floor(self.project.duration * fps + .5)
        first = max(0, min(last-1, math.floor(float(start)*fps+.5)))
        stop = max(first+1, min(last, math.floor(float(end)*fps+.5)))
        if self._color_mode:
            self._cancel_grade_drafts()
            self.grade_target, self._grade_target_chosen = 'selection', True
        self.selected_program_range = (first/fps, stop/fps)
        self.pause()
        selected = next((i for i, cut in enumerate(self.project.cuts)
                         if math.floor(cut.time*fps+.5) == first), None)
        self.selected_cut = selected
        if selected is not None and self.cut_tree.exists(str(selected)):
            self.cut_tree.selection_set(str(selected)); self._select_cut()
        elif self.cut_tree.selection():
            self.cut_tree.selection_remove(*self.cut_tree.selection())
        if self._color_mode and self.grade_target == 'selection':
            self.creative_panel.grade_scope_var.set('所选片段')
        self.creative_panel_refresh()
        self.draw_timeline()
        if vars(self).get('color_workspace'):
            self.color_workspace.refresh()
        if seek: self.seek(first/fps)
        if self._color_mode: self._audition_grade_target()
        if vars(self).get('clip_inspector'):
            self.clip_inspector.refresh()
            if not self._color_mode and (not self._inspector_visible or self.inspector_tabs.select() == str(self.clip_tab)):
                self.show_inspector('edit')
        self.status.set(f'已选片段 {format_time(first/fps)} — {format_time(stop/fps)} · {self._split_shortcut_label()}切开 · 数字键切换机位')

    def get_selected_grade(self):
        selected = self.selected_program_range
        position = selected[0] if selected else self.current
        return copy.deepcopy(grade_at(self.project, position) or ColorGrade())

    def program_range_at_playhead(self):
        """A real programme picture at the playhead, without selecting/editing it."""
        position = self.current
        if not math.isfinite(position) or not 0 <= position < self.project.duration: return None
        camera = self.project.camera_at(position)
        clip = self.project.clip_at(camera, position)
        if clip is None: return None
        span = self._program_span_at(position)
        if span is None: return None
        fps = self.project.fps
        first = max(0, round(max(span.start, clip.start)*fps))
        stop = round(min(span.end, clip.end, self.project.duration)*fps)
        return (first/fps, stop/fps) if stop > first else None

    def select_program_at_playhead(self):
        if not self._available(): return False
        target = self.program_range_at_playhead()
        if target is None:
            self.status.set('播放头处没有节目画面，请移动到视频片段后再试。')
            return False
        self.select_program_range(*target, seek=False)
        self._set_timeline_selection({('program', target)})
        return self.selected_program_range == target

    def get_selected_transform(self):
        selected = self.selected_program_range
        return copy.deepcopy(transform_at(self.project, selected[0] if selected else self.current))

    def apply_selected_transform(self, transform, *, aspect_16_9=False):
        if not self._available(): return False
        if self.selected_program_range is None:
            self.status.set('请先选中节目轨中的片段。'); return False
        try:
            validate_transform(transform)
            candidate = copy.deepcopy(self.project)
            if aspect_16_9:
                settings = dict(candidate.project_settings or DEFAULT_SETTINGS)
                # Exact 16:9 with even dimensions; retain the current width
                # as closely as possible for HD, UHD and custom timelines.
                unit = max(1, min(512, round(settings['width']/32)))
                settings.update(width=unit*32, height=unit*18)
                candidate.project_settings = settings
            set_transform_on_range(candidate, *self.selected_program_range, transform)
            candidate.validate()
        except (ValueError, TypeError) as error:
            messagebox.showerror('裁切与缩放', str(error), parent=self); return False
        if aspect_16_9 and hasattr(self.app, 'resolution_var'):
            self.app.resolution_var.set('时间线分辨率')
        if candidate == self.project: return True
        self._remember(); self.project = candidate
        self._refresh()
        self._update_program_canvas()
        self.status.set('所选片段裁切与缩放已应用 · 成片监看与导出使用相同构图。')
        return True

    def get_active_grade(self):
        if self.grade_target == 'selection':
            return self.get_selected_grade()
        if self.grade_target is None:
            return copy.deepcopy(self.project.global_grade)
        return copy.deepcopy(self.project.camera_grades.get(self.grade_target, ColorGrade()))

    def _cancel_grade_drafts(self, publishing=False):
        workspace = vars(self).get('color_workspace')
        if workspace is not None:
            workspace.cancel_drafts(clear_preview=False)
        panel = vars(self).get('creative_panel')
        cancel = getattr(panel, 'cancel_grade_preview', None)
        if callable(cancel): cancel(clear_preview=False)
        if publishing:
            if self._grade_preview_after is not None:
                self.after_cancel(self._grade_preview_after)
                self._grade_preview_after = None
            self._grade_preview_pending = None
            self._grade_preview_active = False
        else:
            self.clear_grade_preview()

    def set_grade_target(self, target):
        if not self._available(): return False
        if target not in (None, 'selection') and (type(target) is not int or target not in self.project.cameras):
            return False
        if target == 'selection' and self.selected_program_range is None:
            span = self._program_span_at(self.current)
            if span is None: return False
            self.selected_program_range = (span.start, span.end)
        self._cancel_grade_drafts()
        self.grade_target, self._grade_target_chosen = target, True
        label = '所选片段' if target == 'selection' else '全片' if target is None else f'机位 {camera_number(self.project, target)}'
        self.creative_panel.grade_scope_var.set(label)
        self.creative_panel._load_grade()
        self.color_workspace.refresh()
        if self._color_mode:
            self._audition_grade_target()
        self.status.set(f'调色目标：{label} · 拖动色轮实时显示 · 松开保存')
        return True

    def _audition_grade_target(self):
        self._refresh_color_media_policy()
        if self.player:
            if self.project.video_stack_enabled:
                self.player.submit('audition', camera=None)
                return
            # A selected range controls where grades are saved, while its
            # viewer follows the programme cut at the moving playhead.
            camera = self.grade_target if type(self.grade_target) is int else None
            self.player.submit('audition', camera=camera)
            if camera is not None:
                self._highlight(camera)
                label = '所选片段' if self.grade_target == 'selection' else '整机位'
                self.program_var.set(f'{self._label_camera(camera)} · {label}调色实时监看')

    def _follow_color_playhead(self):
        if not self._color_mode or self.grade_target != 'selection' or self.project.video_stack_enabled:
            return
        panel = self.color_workspace
        drag = panel._drag
        if drag and drag['mode'] != 'seek':
            return
        fps = self.project.fps
        frame = math.floor(self.current*fps+.5)
        selected = self.selected_program_range
        if selected and math.floor(selected[0]*fps+.5) <= frame < math.floor(selected[1]*fps+.5):
            return
        span = self._program_span_at(self.current)
        if span is None or selected == (span.start, span.end):
            return
        # Follow navigation without calling select_program_range: that public
        # selection action deliberately pauses playback and seeks its start.
        self._cancel_grade_drafts()
        self.selected_program_range = (span.start, span.end)
        self.selected_cut = next((i for i, cut in enumerate(self.project.cuts)
                                  if round(cut.time*fps) == round(span.start*fps)), None)
        if self.selected_cut is not None and self.cut_tree.exists(str(self.selected_cut)):
            self.cut_tree.selection_set(str(self.selected_cut))
            self._select_cut()
            self.cut_tree.see(str(self.selected_cut))
        elif self.cut_tree.selection():
            self.cut_tree.selection_remove(*self.cut_tree.selection())
        self._set_timeline_selection({('program', self.selected_program_range)}, redraw=False)
        self.creative_panel_refresh()
        panel.refresh()
        self._refresh_color_media_policy()

    def _grade_preview_target(self):
        if self.grade_target == 'selection':
            return ('selection', *self.selected_program_range) if self.selected_program_range else None
        if self.grade_target is None:
            return ('global',)
        return ('camera', self.grade_target)

    def preview_active_grade(self, grade):
        if not self._available() or not self.project.clips: return False
        target = self._grade_preview_target()
        if target is None: return False
        try: validate_grade(grade, check_lut=False)
        except ValueError: return False
        self._grade_preview_pending = (target, copy.deepcopy(grade))
        if self._grade_preview_after is None:
            self._grade_preview_after = self.after(33, self._flush_grade_preview)
        return True

    def _flush_grade_preview(self):
        if self._grade_preview_after is not None:
            self.after_cancel(self._grade_preview_after)
        self._grade_preview_after = None
        pending, self._grade_preview_pending = self._grade_preview_pending, None
        if pending is None or not self.alive or not self._available(): return
        if self.player:
            self.player.submit('grade_preview', target=pending[0], grade=pending[1])
            self._grade_preview_active = True

    def clear_grade_preview(self):
        if self._grade_preview_after is not None:
            self.after_cancel(self._grade_preview_after)
            self._grade_preview_after = None
        self._grade_preview_pending = None
        if self._grade_preview_active and self.player:
            self.player.submit('grade_preview', grade=None)
        self._grade_preview_active = False

    def apply_active_grade(self, grade):
        if not self._available(): return False
        if self.grade_target == 'selection':
            return self.apply_selected_grade(grade)
        if self.grade_target is not None and self.grade_target not in self.project.cameras:
            return False
        try:
            validate_grade(grade)
            if grade == self.get_active_grade():
                self.clear_grade_preview()
                return True
            candidate = copy.deepcopy(self.project)
            if self.grade_target is None: candidate.global_grade = copy.deepcopy(grade)
            else: candidate.camera_grades[self.grade_target] = copy.deepcopy(grade)
            candidate.validate()
        except Exception as exc:
            messagebox.showerror('机位调色', str(exc), parent=self); return False
        # A configure publishes the saved grade and clears its preview in one
        # worker action, so release does not flash the old colour in between.
        if self._grade_preview_after is not None:
            self.after_cancel(self._grade_preview_after)
            self._grade_preview_after = None
        self._grade_preview_pending = None
        self._grade_preview_active = False
        self._remember(); self.project = candidate; self._refresh()
        label = '全片' if self.grade_target is None else f'机位 {camera_number(self.project, self.grade_target)}'
        self.status.set(f'{label} 调色已保存 · 其他机位参数保持独立')
        return True

    def apply_selected_grade(self, grade):
        if not self._available(): return False
        if self.selected_program_range is None:
            span = self._program_span_at(self.current)
            if span is None:
                self.status.set('请先导入视频并选择调色片段。'); return False
            self.selected_program_range = (span.start, span.end)
        try:
            validate_grade(grade)
            candidate = copy.deepcopy(self.project)
            set_grade_on_range(candidate, *self.selected_program_range, grade)
            candidate.validate()
        except Exception as exc:
            messagebox.showerror('片段调色', str(exc), parent=self); return False
        self._remember(); self.project = candidate
        self._refresh()
        self.status.set('所选片段调色已应用，监看实时更新。')
        return True

    def enter_color_workspace(self, embedded=False):
        if not embedded and 'color' in getattr(self.app, 'page_frames', {}):
            self.app._select_page('color')
            return
        if not self._available(): return
        if self.selected_program_range is None:
            span = self._program_span_at(self.current)
            if span is not None:
                self.selected_program_range = (span.start, span.end)
        if not self._color_mode:
            self._timeline_saved_sash = (self.workspace_split.sashpos(0)
                if len(self.workspace_split.panes()) > 1 else None)
            self._color_mode = True
            self._refresh_color_media_policy()
            manager = vars(self).get('dock_manager')
            if manager is not None:
                manager.show('grading')
            else:
                self.workspace_split.add(self.color_workspace, weight=3)
            self._color_replaced_timeline = (str(self.color_workspace) in self.workspace_split.panes()
                and str(self.timeline_section) in self.workspace_split.panes())
            if self._color_replaced_timeline:
                self.workspace_split.forget(self.timeline_section)
        self.grade_target = 'selection' if self.selected_program_range else None
        self.set_grade_target(self.grade_target)
        self.creative_panel_refresh()
        self.color_workspace.refresh()
        self.update_idletasks()
        height = self.workspace_split.winfo_height()
        color_page = self.color_workspace
        chrome_height = max(0, color_page.winfo_height() - color_page.controls_canvas.winfo_height())
        requested_height = max(self._px(350),
            chrome_height + color_page.controls.winfo_reqheight() + self._px(4))
        sash_height = max(0, height - self.body.winfo_height() - color_page.winfo_height())
        # Fit the numeric rows as well as the wheel canvases at the active DPI.
        # Short windows retain a useful viewer and scroll the colour controls.
        if str(self.color_workspace) in self.workspace_split.panes() and len(self.workspace_split.panes()) > 1:
            self.workspace_split.sashpos(0, max(self._px(130), height-requested_height-sash_height))
        if not self.player and self.project.clips and self.app.mpv_path:
            self.start_monitors()
        self._audition_grade_target()
        self.status.set('调色页 · 单画面监看 · 调色及标准机位使用原片 · 拖动色轮实时显示 · '+self._split_shortcut_label()+'切开 · ←/→逐帧')


    def exit_color_workspace(self):
        finishing = vars(self).get('finishing_workspace')
        if finishing and finishing.mode == 'color':
            if 'multicam' in getattr(self.app, 'page_frames', {}):
                self.app._select_page('multicam')
            else:
                finishing.show('edit')
            return
        if not self._color_mode: return
        self._cancel_grade_drafts()
        if self.player: self.player.submit('audition', camera=None)
        self._color_mode = False
        self._refresh_color_media_policy()
        self._clear_timeline_selection()
        manager = vars(self).get('dock_manager')
        if manager is not None:
            manager.hide('grading')
        elif str(self.color_workspace) in self.workspace_split.panes():
            self.workspace_split.forget(self.color_workspace)
        if vars(self).get('_color_replaced_timeline', True) and not self.timeline_section.winfo_manager():
            self.workspace_split.add(self.timeline_section, weight=2)
        self.update_idletasks()
        if self._timeline_saved_sash is not None and len(self.workspace_split.panes()) > 1:
            self.workspace_split.sashpos(0, self._timeline_saved_sash)
        self.draw_timeline()


    def split_program_at_playhead(self, position=None):
        if not self._available(): return False
        position = self.current if position is None else position
        span = self._program_span_at(position)
        if span is None: return False
        try:
            candidate = copy.deepcopy(self.project)
            changed = split_at(candidate, position)
            if not changed:
                self.status.set('播放头已在片段边界；请逐帧移动后再按 '+self._split_shortcut_label()+'。'); return False
            candidate.validate()
        except Exception as exc:
            messagebox.showerror('切开片段', str(exc), parent=self); return False
        self._remember(); self.project = candidate
        cut = math.floor(position*self.project.fps+.5)/self.project.fps
        self._set_timeline_selection({('program', (cut, span.end))}, redraw=False)
        if self._color_mode: self.grade_target = 'selection'
        self._refresh()
        self.status.set(f'已在 {format_time(cut)} 切开；右侧片段已选中。')
        return True

    def _switch_selected_camera(self, camera):
        from multicam_outer import outer_cameras
        if camera in outer_cameras(self.project):
            self.status.set('这是外层机位，请在对应外层轨道上编辑；多机位内部切点保持不变。')
            return
        selected = self.selected_program_range
        try:
            candidate = copy.deepcopy(self.project)
            set_camera_on_range(candidate, *selected, camera)
            if candidate.multicam_outer_order: candidate.video_stack_enabled = self.project.video_stack_enabled
            if not candidate.multicam_outer_order: candidate.video_stack_enabled = False
            candidate.validate()
        except Exception as exc:
            messagebox.showerror('切换片段机位', str(exc), parent=self); return
        self._remember(); self.project = candidate
        self._set_timeline_selection({('program', selected)}, redraw=False)
        self._finish_preview_epoch(seek=False)
        if not self.project.multicam_outer_order: self._set_stack_preview_mode(False)
        self._refresh()
        current_camera = self.project.camera_at(self.current)
        self._set_program_label(current_camera)
        self._highlight(current_camera)
        self.status.set(f'所选片段已切换到机位 {camera_number(self.project, camera)}。')

    def add_transition_at_selected_end(self, kind='fade', duration=.5):
        if not self._available() or self.selected_program_range is None: return
        start, end = self.selected_program_range
        next_span = next((span for span in program_spans(self.project)
                          if math.floor(span.start*self.project.fps+.5) == math.floor(end*self.project.fps+.5)), None)
        if next_span is None:
            self.status.set('此片段已到成片结尾，没有可连接的后续片段。'); return
        try:
            duration = float(duration)
            if not math.isfinite(duration) or not .05 <= duration <= 5:
                raise ValueError('转场时长请输入 0.05–5 秒。')
            duration = min(duration, 2*(end-start), 2*next_span.duration)
            candidate = copy.deepcopy(self.project)
            split_at(candidate, end)
            candidate.transitions = [item for item in candidate.transitions
                if math.floor(item.time*candidate.fps+.5) != math.floor(end*candidate.fps+.5)]
            candidate.transitions.append(Transition(end, kind, duration))
            candidate.transitions.sort(key=lambda item: item.time)
            candidate.validate()
            plan_creative_segments(candidate, candidate.segments())
        except Exception as exc:
            messagebox.showerror('片段末尾转场', str(exc), parent=self); return
        self._remember(); self.project = candidate; self._refresh()
        self.status.set(f'已在片段末尾 {format_time(end)} 添加转场。')

    def _ensure_delivery_height(self):
        tabs = {str(self.delivery_tab), str(vars(self).get('creative_tab', self.delivery_tab))}
        if (not self._inspector_visible or self.inspector_tabs.select() not in tabs
                or len(self.workspace_split.panes()) < 2):
            return
        self.update_idletasks()
        available = self.workspace_split.winfo_height()
        # Opening delivery or revealing its status uses a little more of the
        # vertical split, while keeping the timeline available below it.
        target = min(self._px(360), max(self._px(180), available - self._px(100)))
        if self.workspace_split.sashpos(0) < target:
            self.workspace_split.sashpos(0, target)

    def _build_export_monitor(self):
        self.export_monitor = tk.Frame(self, bg=PANEL, padx=self._px(10), pady=self._px(6))
        self.export_monitor.grid(row=2, column=0, sticky='ew', pady=(self._px(2), 0))
        self.export_monitor.columnconfigure(0, weight=1)
        tk.Label(self.export_monitor, textvariable=self.export_phase_var, bg=PANEL, fg=INK,
                 font=('Microsoft YaHei UI', 10, 'bold'), anchor='w').grid(row=0, column=0, sticky='ew')
        self.export_percent_label = tk.Label(self.export_monitor, text='0.0%', bg=PANEL, fg=INK,
                                            font=('Cascadia Mono', 10))
        self.export_percent_label.grid(row=0, column=1, sticky='e')
        self.export_speed_label = tk.Label(self.export_monitor, textvariable=self.export_speed_var,
            bg=PANEL, fg=ACCENT, font=('Microsoft YaHei UI', 10), anchor='w')
        self.export_speed_label.grid(row=1, column=0, sticky='ew', pady=self._px(3))
        timing = tk.Frame(self.export_monitor, bg=PANEL)
        timing.grid(row=1, column=1, sticky='e')
        for label, variable in (('已用 ', self.export_elapsed_var), ('  剩余 ', self.export_eta_var)):
            tk.Label(timing, text=label, bg=PANEL, fg=MUTED, font=('Microsoft YaHei UI', 9)).pack(side='left')
            tk.Label(timing, textvariable=variable, bg=PANEL, fg=INK,
                     font=('Cascadia Mono', 9)).pack(side='left')
        style = ttk.Style(self)
        style.configure('Delivery.Horizontal.TProgressbar', thickness=self._px(7),
                        background=ACCENT, troughcolor=INPUT)
        self.export_progress_bar = ttk.Progressbar(self.export_monitor,
            variable=self.export_progress_var, maximum=100, style='Delivery.Horizontal.TProgressbar')
        self.export_progress_bar.grid(row=2, column=0, columnspan=2, sticky='ew')
        self.export_cache_var = tk.StringVar(self, value='')
        self.export_cache_label = tk.Label(self.export_monitor, textvariable=self.export_cache_var,
            bg=PANEL, fg=MUTED, font=('Microsoft YaHei UI', 9), anchor='w', justify='left',
            wraplength=self._px(900))
        self.export_cache_label.grid(row=3, column=0, columnspan=2, sticky='ew', pady=(self._px(4), 0))
        self.export_monitor.bind('<Configure>', lambda event: self.export_cache_label.configure(
            wraplength=max(self._px(100), event.width-self._px(24))), add='+')
        self.export_monitor.grid_remove()

    @staticmethod
    def _duration_text(seconds):
        try: value = float(seconds)
        except (TypeError, ValueError): return '—'
        if not math.isfinite(value) or value < 0: return '—'
        value = round(value)
        return f'{value//3600:02d}:{value%3600//60:02d}:{value%60:02d}'

    def _update_export_metrics(self, snapshot):
        finishing = vars(self).get("finishing_workspace")
        if finishing: finishing.update_metrics(snapshot)
        path=snapshot.get('diagnostic_path')
        if path and path!=getattr(self,'_export_diagnostic_path',''):
            self._export_diagnostic_path=path
            self.app._log('多机位导出诊断日志：'+str(path))
        self._export_last_snapshot = dict(snapshot)
        self._update_export_tracking(snapshot)
        first_show = not self.export_monitor.winfo_manager()
        self.export_monitor.grid()
        if first_show:
            self._ensure_delivery_height()
        stage = str(snapshot.get('stage', 'encoding'))
        phase = export_phase_text(snapshot)
        total_duration = float(snapshot.get('total_seconds') or 0)
        if total_duration > 0:
            phase += f' · 成片 {self._duration_text(total_duration)}'
        percent = max(0.0, min(100.0 if stage == 'done' else 99.9,
                             float(snapshot.get('progress_percent', 0))))
        fps = max(0.0, float(snapshot.get('fps') or 0))
        speed = max(0.0, float(snapshot.get('speed') or 0))
        workers = max(0, int(snapshot.get('active_workers') or 0))
        elapsed = snapshot.get('elapsed', 0)
        eta = snapshot.get('eta')
        if stage == 'muxing':
            rate = f'FPS — · 封装 {speed:.2f}×'
        elif stage == 'done':
            duration = float(snapshot.get('total_seconds') or 0)
            elapsed_value = float(elapsed or 0)
            average = duration/elapsed_value if elapsed_value > 0 else 0
            rate = f'完成 · 全程平均 {average:.2f}×'
            eta = 0
        elif stage in {'cancelled', 'failed'}:
            rate = '导出已取消' if stage == 'cancelled' else '导出失败'
            eta = None
        else:
            rate = f'近3秒：{fps:.1f} FPS · {speed:.2f}×'
            if workers > 1: rate += f' · {workers} 路合计'
            average=snapshot.get('average_fps')
            if isinstance(average,(int,float)) and math.isfinite(average):rate+=f' · 全程 {max(0.,average):.1f} FPS'
        self.export_phase_var.set(phase)
        self.export_speed_var.set(rate)
        self.export_progress_var.set(percent)
        self.export_elapsed_var.set(self._duration_text(elapsed))
        self.export_eta_var.set(self._duration_text(eta))
        self.export_percent_label.configure(text=f'{percent:.1f}%')
        summary = f'{phase} · {percent:.1f}% · {rate} · 已用 {self.export_elapsed_var.get()} · 剩余 {self.export_eta_var.get()}'
        self.export_metrics_var.set(summary)
        self.app.progress_var.set(percent)
        self.app.progress_text_var.set(summary)
        self.status.set(phase)

    def _available(self):
        if self.busy or self.app.working:
            self.status.set('当前任务仍在运行；可以取消或等待完成。')
            return False
        return True

    def _remember(self):
        self.undo_stack.append(copy.deepcopy(self.project))
        self.undo_stack = self.undo_stack[-100:]
        self.redo_stack.clear()
        self._mark_dirty()

    def _mark_dirty(self):
        self.dirty = True
        path = self.project_path or getattr(self.app, 'project_path', None)
        self.project_label.configure(text=(Path(path).name if path else '未保存工程') + ' *')

    def _selected_clip(self):
        selection = self.media_tree.selection()
        return next((clip for clip in self.project.clips if selection and clip.id == selection[0]), None)

    def _refresh(self, reconfigure=True):
        self._update_program_canvas()
        self._refresh_timeline_controls()
        self._refresh_video_stack_ui()
        self._cancel_grade_drafts(publishing=reconfigure)
        if self.project.color_reference_camera not in self.project.cameras:self.project.color_reference_camera=None
        if self.project.alignment_reference_camera not in self.project.cameras:
            self.project.alignment_reference_camera=None
        self.compare_button.configure(state='normal' if self.project.stabilizations else 'disabled')
        if not self.project.stabilizations and self.stabilization_compare_var.get():
            self.stabilization_compare_var.set(False);self.toggle_stabilization_compare()
        identifiers = {clip.id for clip in self.project.clips}
        self.project.stabilizations = [item for item in self.project.stabilizations
            if item.source_id in identifiers and item.start < self.project.duration]
        for item in self.project.stabilizations: item.end = min(item.end,self.project.duration)
        if isinstance(self.grade_target, int) and self.grade_target not in self.project.cameras:
            self.grade_target = min(self.project.cameras) if self.project.cameras else None
        if self.grade_target == 'selection' and not self.project.clips:
            self.grade_target = None
        label = '所选片段' if self.grade_target == 'selection' else '全片' if self.grade_target is None else f'机位 {camera_number(self.project, self.grade_target)}'
        self.creative_panel.grade_scope_var.set(label)
        fps = self.project.fps
        frame = lambda value: math.floor(value * fps + .5)
        last = frame(self.project.duration)
        self.project.edit_points = sorted({frame(value)/fps for value in self.project.edit_points
                                           if 0 < frame(value) < last})
        trimmed_grades = []
        for item in self.project.clip_grades:
            first, stop = max(0, frame(item.start)), min(last, frame(item.end))
            if stop > first:
                item.start, item.end = first/fps, stop/fps
                trimmed_grades.append(item)
        self.project.clip_grades = trimmed_grades
        trimmed_transforms = []
        for item in self.project.clip_transforms:
            first, stop = max(0, frame(item.start)), min(last, frame(item.end))
            if stop > first:
                item.start, item.end = first/fps, stop/fps
                trimmed_transforms.append(item)
        self.project.clip_transforms = trimmed_transforms
        boundary_times = [cut.time for cut in self.project.cuts] + self.project.edit_points
        cut_frames = {frame(value) for value in boundary_times if frame(value) > 0}
        self.project.transitions = [item for item in self.project.transitions
            if frame(item.time) in cut_frames and item.time - item.duration/2 >= 0
            and item.time + item.duration/2 <= self.project.duration
            and not any(item.time - item.duration/2 < value < item.time + item.duration/2
                        and frame(value) != frame(item.time) for value in boundary_times)]
        if last <= 0:
            self.selected_program_range = None
        elif self.selected_program_range is not None:
            first = max(0, min(last-1, frame(self.selected_program_range[0])))
            stop = max(first+1, min(last, frame(self.selected_program_range[1])))
            self.selected_program_range = first/fps, stop/fps
        if self._color_mode and self.selected_program_range is None:
            span = self._program_span_at(self.current)
            if span: self.selected_program_range = (span.start, span.end)
        selection = self.media_tree.selection()
        expanded = {parent: self.media_tree.item(parent, 'open') for parent in self.media_tree.get_children()}
        self.media_tree.delete(*self.media_tree.get_children())
        from source_media import retain_source_media, populate_source_rows
        retain_source_media(self.project)
        populate_source_rows(self.media_tree, self.project, expanded)
        for camera in self._media_camera_order():
            parent = f'camera_{camera}'
            self.media_tree.insert('', 'end', iid=parent, text=self._camera_tree_label(camera),
                open=expanded.get(parent, not getattr(self, '_media_tree_collapsed', False)))
            for clip in sorted((c for c in self.project.clips if c.camera == camera), key=lambda c: c.start):
                tag = self._sync_clip_state(clip.id)
                self.media_tree.insert(parent, 'end', iid=clip.id, text=self._camera_clip_tree_text(clip),
                                       tags=(tag,) if tag else (),
                                       values=(format_signed_time(clip.start), format_time(clip.duration)))
        selection = tuple(identifier for identifier in selection if self.media_tree.exists(identifier))
        if selection: self.media_tree.selection_set(selection)
        self._update_camera_fold_button()
        self.cut_tree.delete(*self.cut_tree.get_children())
        from multicam_outer import outer_cameras
        self.cut_camera_combo.configure(values=tuple(str(camera_number(self.project, camera))
            for camera in self._media_camera_order() if camera not in outer_cameras(self.project)))
        for i, cut in enumerate(self.project.cuts):
            self.cut_tree.insert('', 'end', iid=str(i), values=(format_time(cut.time), str(camera_number(self.project, cut.camera))))
        if self.selected_cut is not None and self.selected_cut < len(self.project.cuts):
            self.cut_camera_var.set(str(camera_number(self.project, self.project.cuts[self.selected_cut].camera)))
        self.master_var.set('主音频：' + Path(self.project.master_audio).name if self.project.master_audio else '未选择主音频（可在 A 轨选择机位原声）')
        self._build_camera_frames()
        self.draw_timeline()
        self._show_time()
        refresh_creative = vars(self).get('creative_panel_refresh')
        if refresh_creative:
            refresh_creative()
        if vars(self).get('color_workspace'):
            self.color_workspace.refresh()
        if vars(self).get('audio_workspace'):
            self.audio_workspace.refresh()
        if reconfigure:
            self._configure_player()
        finishing = vars(self).get("finishing_workspace")
        if finishing and finishing.mode != "edit": finishing.refresh_clips()
        self._check_prerender_project()
        self._schedule_transition_previews()
        self._refresh_camera_labels()
        self._schedule_camera_metadata()
        if vars(self).get('clip_inspector'): self.clip_inspector.refresh(force=True)

    @staticmethod
    def _checked_camera_grid(rows, columns):
        values = []
        for value in (rows, columns):
            if isinstance(value, str) and value.isdecimal(): value = int(value)
            if type(value) is not int or not 1 <= value <= 6:
                raise ValueError('监看行数和列数必须为 1–6 的整数。')
            values.append(value)
        return tuple(values)

    def _apply_camera_grid(self, _event=None):
        try:
            self.set_camera_grid(self.camera_rows_var.get(), self.camera_columns_var.get())
        except (ValueError, tk.TclError) as error:
            self.camera_rows_var.set(str(self.camera_rows))
            self.camera_columns_var.set(str(self.camera_columns))
            self.status.set(str(error))

    def set_camera_grid(self, rows, columns, *, persist=True):
        rows, columns = self._checked_camera_grid(rows, columns)
        if (rows, columns) == (self.camera_rows, self.camera_columns): return
        cameras = tuple(self._monitor_camera_order())
        visible = self._visible_camera_ids
        current = self._displayed_camera if self._displayed_camera in visible else (visible[0] if visible else None)
        self.camera_rows, self.camera_columns = rows, columns
        self.camera_rows_var.set(str(rows)); self.camera_columns_var.set(str(columns))
        self.camera_page = cameras.index(current) // (rows*columns) if current in cameras else 0
        self._build_camera_frames()
        self._refresh_camera_labels()
        self.status.set(f'监看 {rows}×{columns} · 每页最多 {rows*columns} 个机位 · 数字 1–9 选择前九格，其余鼠标点选')
        if persist and vars(self).get('dock_manager'):
            self._workspace_layout_changed()

    def _build_camera_frames(self):
        self.camera_proxy_badges = vars(self).get('camera_proxy_badges', {})
        all_cameras=tuple(self._monitor_camera_order())
        rows, cols = self.camera_rows, self.camera_columns
        capacity = rows*cols
        pages=max(1,math.ceil(len(all_cameras)/capacity))
        self.camera_page=max(0,min(self.camera_page,pages-1))
        self.camera_page_var.set(f'{self.camera_page+1}/{pages}')
        self.camera_prev.configure(state='normal' if self.camera_page>0 else 'disabled')
        self.camera_next.configure(state='normal' if self.camera_page+1<pages else 'disabled')
        if pages>1:
            self.camera_shortcut_hint.pack_forget()
            self.camera_pager.pack(side='right',padx=self._px(2))
        else:
            self.camera_pager.pack_forget()
            self.camera_shortcut_hint.pack(side='right',padx=self._px(4))
        cameras=all_cameras[self.camera_page*capacity:(self.camera_page+1)*capacity]
        self._visible_camera_ids=cameras
        layout = rows, cols, cameras
        if self._camera_grid_layout == layout and tuple(self.camera_frames) == cameras:
            return
        old_windows = {camera: surface.winfo_id() for camera, surface in self.camera_surfaces.items()}
        empty=vars(self).get('_empty_camera_widget')
        if empty is not None and empty.winfo_exists():empty.destroy()
        can_release = not self.player and self._can_start_transport_monitors(report=False)
        for camera,frame in list(self.camera_frames.items()):
            if camera in cameras: continue
            frame.grid_forget()
            if not can_release:
                self._retired_camera_frames[self.camera_surfaces[camera].winfo_id()]=frame
            else:frame.destroy()
            del self.camera_frames[camera]; del self.camera_surfaces[camera]; del self.camera_buttons[camera]
            self.camera_proxy_badges.pop(camera, None)
        if can_release:
            self._release_camera_frames(list(self._retired_camera_frames))
        if not cameras:
            self._show_empty_media()
            self._camera_grid_layout = layout
            if self.player and old_windows:self.player.submit('camera_windows',windows={})
            return
        for i in range(6):
            self.camera_grid.columnconfigure(i, weight=1 if i < cols else 0,
                                             uniform='angle' if i < cols else '', minsize=0)
            self.camera_grid.rowconfigure(i, weight=1 if i < rows else 0,
                                          uniform='angle' if i < rows else '', minsize=0)
        for i, camera in enumerate(cameras):
            if camera in self.camera_frames:
                self.camera_frames[camera].grid(row=i // cols, column=i % cols, sticky='nsew', padx=1, pady=1)
                continue
            frame = tk.Frame(self.camera_grid, bg='#414449', padx=1, pady=1)
            frame.pack_propagate(False)
            frame.grid(row=i // cols, column=i % cols, sticky='nsew', padx=1, pady=1)
            surface = tk.Frame(frame, bg='#0e0f10', width=1, height=1)
            surface.pack(fill='both', expand=True)
            surface.bind('<Button-1>', lambda event, c=camera: self._monitor_camera_click(c))
            footer = tk.Frame(frame, bg=PANEL)
            footer.pack(fill='x')
            button = tk.Button(footer, text=self._camera_button_label(camera), bg=PANEL, fg=INK,
                               activebackground='#3a4047', activeforeground=INK,
                               relief='flat', borderwidth=0, highlightthickness=0,
                               font=('Microsoft YaHei UI', 9), pady=3, width=1, anchor='w', padx=self._px(6),
                               command=lambda c=camera: self._monitor_camera_click(c))
            badge = tk.Label(footer, text='', bg=PANEL, fg=GREEN,
                             font=('Microsoft YaHei UI', 8), padx=self._px(5), cursor='hand2')
            badge.pack(side='right')
            badge.bind('<Button-1>', lambda event, c=camera: self._monitor_camera_click(c))
            self.camera_proxy_badges[camera] = badge
            button.pack(side='left', fill='x', expand=True)
            self.camera_frames[camera] = frame
            self.camera_surfaces[camera] = surface
            self.camera_buttons[camera] = button
            self._tag_transport_widgets(frame)
        self.camera_frames = {camera: self.camera_frames[camera] for camera in cameras}
        self.camera_surfaces = {camera: self.camera_surfaces[camera] for camera in cameras}
        self.camera_buttons = {camera: self.camera_buttons[camera] for camera in cameras}
        dense = rows > 3 or cols > 3
        for camera, button in self.camera_buttons.items():
            button.configure(text=self._camera_button_label(camera), font=('Microsoft YaHei UI', 8 if dense else 9),
                             pady=1 if dense else 3)
        self._camera_grid_layout = layout
        self._highlight(self._displayed_camera if self._displayed_camera in all_cameras else self.project.camera_at(self.current))
        windows = {camera: surface.winfo_id() for camera, surface in self.camera_surfaces.items()}
        if self.player and windows != old_windows:
            self.update_idletasks()
            self.player.submit('camera_windows',windows=windows)

    def _release_camera_frames(self,windows):
        for window in windows:
            frame=self._retired_camera_frames.pop(window,None)
            if frame is not None and frame.winfo_exists():frame.destroy()

    def _change_camera_page(self,delta):
        if not self._available():return
        pages=max(1,math.ceil(len(self._monitor_camera_order())/(self.camera_rows*self.camera_columns)))
        page=max(0,min(self.camera_page+delta,pages-1))
        if page==self.camera_page:return
        self.camera_page=page;self._build_camera_frames();self._refresh_camera_labels()
        self._saved_camera_page = page
        self._workspace_layout_changed()
        self.status.set(f'监看第 {page+1}/{pages} 页 · 数字1–9选择本页前九格，其余鼠标点选')

    def add_camera(self):
        if not self._available(): return
        paths=filedialog.askopenfilenames(parent=self,title='导入视频到素材库',filetypes=VIDEO_TYPES)
        if paths: self._start_camera_import(paths, separate_files=True)

    def append_clips(self):
        if not self._available(): return
        clip = self._selected_clip()
        selection = self.media_tree.selection()
        camera = clip.camera if clip else (int(selection[0].split('_')[1]) if selection and selection[0].startswith('camera_') else None)
        if camera is None:
            messagebox.showinfo('多机位', '先在素材列表中选择一个机位。', parent=self)
            return
        paths = filedialog.askopenfilenames(parent=self, title=f'追加机位 {camera_number(self.project, camera)} 的片段', filetypes=VIDEO_TYPES)
        if paths: self._import(paths, camera)

    def _import(self, paths, camera):
        return self._start_camera_import(paths, camera=camera, library_only=False)

    def remove_clip(self):
        if not self._available(): return
        identifiers = set(self.media_tree.selection())
        keys = {('clip', clip.id) for clip in self.project.clips if clip.id in identifiers}
        if not keys: return
        self._set_timeline_selection(keys)
        self._delete_timeline_selection()

    def _delete_media_selection(self, _event=None):
        """Delete only the focused media list's selection in one undo step."""
        if not self._available(): return 'break'
        identifiers = set(self.media_tree.selection())
        keys = {('clip', clip.id) for clip in self.project.clips
                if clip.id in identifiers or f'camera_{clip.camera}' in identifiers}
        if not keys:
            self.status.set('素材库原片保持不变；请在时间线上选择要删除的片段。')
            return 'break'
        self._set_timeline_selection(keys, redraw=False)
        return self._delete_timeline_selection()

    def _select_clip(self, event=None):
        selection = self.media_tree.selection()
        if selection and selection[0].startswith('source::'):
            self.status.set('拖入时间线可重复使用原片；现有片段保持原位。')
        clip = self._selected_clip()
        if clip: self.offset_var.set(format_signed_time(clip.start))
        if vars(self).get('clip_inspector'):
            self.clip_inspector._refresh_placement()

    def _jump_clip(self, event=None):
        clip = self._selected_clip()
        if clip: self.seek(max(0, clip.start))

    def apply_offset(self):
        if not self._available(): return
        clip = self._selected_clip()
        if not clip: return
        try: value = parse_signed_timecode(self.offset_var.get())
        except ValueError as exc:
            messagebox.showerror('时间码', str(exc), parent=self); return
        value = round(value*self.project.fps)/self.project.fps
        if not self._can_move_timeline_clip(clip, value): return
        self._remember();self._move_clip_start(clip, value)
        self._refresh()

    def _move_clip_start(self,clip,value):
        if not self._can_move_timeline_clip(clip, value): return False
        delta=value-clip.start
        if self.project.timeline_link_enabled:
            if clip.id in self.project.audio_overrides:
                move_source_audio(self.project, {clip.id}, delta)
        else:
            preserve_source_audio(self.project, {clip.id})
        for item in self.project.stabilizations:
            if item.source_id==clip.id:
                item.start=max(0.,item.start+delta);item.end+=delta
        self.project.stabilizations=[item for item in self.project.stabilizations if item.end>item.start]
        clip.start=value
        return True

    def nudge(self, frames):
        clip = self._selected_clip()
        if clip:
            self.offset_var.set(format_signed_time(clip.start + frames / self.project.fps))
            self.apply_offset()

    def choose_proxy(self):
        return self.link_existing_proxy()

    def choose_master(self):
        if not self._available(): return
        path = filedialog.askopenfilename(parent=self, title='选择从主时间 00:00 开始的连续主录音',
                                         filetypes=[('音视频', '*.wav *.flac *.mp3 *.m4a *.aac *.aif *.aiff *.mov *.mp4 *.mkv'), ('所有文件', '*.*')])
        if path: self._load_master(path)

    def master_from_clip(self):
        if not self._available(): return
        clip = self._selected_clip()
        if clip: self._load_master(clip.path)

    def _load_master(self, path):
        ffprobe = self.app.caps.ffprobe_path or find_binary('ffprobe', Path(__file__).parent)
        self.busy = True
        self.status.set('正在读取主音频…')
        def worker():
            try:
                result = subprocess.run([ffprobe, '-v', 'error', '-select_streams', 'a:0',
                    '-show_entries', 'stream=index', '-of', 'json', path],
                    capture_output=True, text=True, encoding='utf-8', timeout=30,
                    creationflags=CREATE_NO_WINDOW)
                if result.returncode or not json.loads(result.stdout).get('streams'):
                    raise ValueError('这个文件不包含可读取的音轨。')
                duration = probe_media_duration(ffprobe, path)
                self.jobs.put(('master', (path, duration)))
            except Exception as exc: self.jobs.put(('error', str(exc)))
        threading.Thread(target=worker, daemon=True).start()

    def align(self, selected=False, *, reference_audio_keys=None, use_master=False):
        if not self._available(): return
        ffmpeg = self.app.caps.ffmpeg_path
        clips = (selected_video_clips(self.project, self._timeline_selection, self.media_tree.selection())
                 if selected else list(self.project.clips))
        if selected and not clips:
            messagebox.showinfo('同步', '请先选择需要同步的视频片段或机位。', parent=self)
            return
        reference = None if use_master or reference_audio_keys is not None else self.project.alignment_reference_camera
        if not selected and reference_audio_keys is None and reference is None and self.project.master_audio:
            master_key = os.path.normcase(os.path.abspath(self.project.master_audio))
            partial = next((item for item in self.project.clips
                if os.path.normcase(os.path.abspath(item.path)) == master_key
                and sum(part.duration for part in self.project.clips if part.camera == item.camera)
                    > self.project.master_duration + .25), None)
            if partial is not None:
                choice = messagebox.askyesnocancel('选择完整同步参考',
                    f'当前主音频只是机位 {partial.camera} 的一个分段，无法覆盖这条完整轨道。\n\n'
                    '是：选择全程音频或全程视频，然后重新点击同步。\n'
                    '否：用该机位的完整轨道对齐其他机位。节目主音频仍需另选全程文件。\n'
                    '取消：保留当前时间线。', parent=self)
                if choice is None:
                    return
                if choice:
                    self.choose_master()
                    return
                self.project.alignment_reference_camera = reference = partial.camera
                self._refresh_sync_reference_choices()
                self._mark_dirty()
        reference_clips = None
        reference_label = '主音频' if reference is None else self._label_camera(reference)
        if reference_audio_keys is not None:
            try:
                reference_clips = reference_audio_clips(self.project, reference_audio_keys)
            except ValueError as error:
                messagebox.showinfo('同步', str(error), parent=self); return
            if not reference_clips:
                messagebox.showinfo('同步', '请选择至少一个参考音频片段。', parent=self); return
            # A linked reference includes its picture. Keep that pair anchored,
            # but let other selected parts on the same camera move independently.
            if self.project.timeline_link_enabled:
                anchored = {identifier for kind, identifier in reference_audio_keys if kind == 'camera_audio'}
                clips = [item for item in clips if item.id not in anchored]
            reference_label = f'所选音频（{len(reference_clips)} 段）'
        elif reference is not None:
            reference_clips = [copy.deepcopy(item) for item in self.project.clips if item.camera == reference]
            clips = [item for item in clips if item.camera != reference]
        elif self.project.master_audio:
            master_parts = master_audio_clips(self.project)
            # Preserve the established batch matcher for an untouched A0. An
            # edited/moved master must instead use its actual anchored intervals.
            if (len(master_parts) != 1 or master_parts[0].start != 0 or master_parts[0].source_in != 0
                    or abs(master_parts[0].duration-self.project.master_duration) > 1e-8):
                reference_clips = reference_audio_clips(self.project, {('audio', item.id) for item in master_parts})
        if not clips:
            messagebox.showinfo('同步', '所选视频都是参考音频的绑定片段，已保持原位。请再选中需要移动的视频片段。', parent=self)
            return
        if not clips or not ffmpeg or (reference_clips is None and not self.project.master_audio):
            messagebox.showinfo('同步', '请选择待同步素材，以及主音频或一个参考机位；参考机位自身保持固定。', parent=self); return
        if any(not self._can_move_timeline_clip(item) for item in clips): return
        self.stop_monitors()
        self.busy = True
        self.sync_running = True
        self.app.cancel_event.clear()
        self.app._set_working(True)
        self.app._begin_shared_progress('同步并对齐 0.0%')
        self._alignment_reference_label = reference_label
        self.status.set('正在多窗口匹配'+self._alignment_reference_label+'；逐段核对真实起点，未确认的片段保留原位。底部可取消。')
        sync_clips = copy.deepcopy(clips)
        sync_fps = self.project.fps
        sync_ffprobe = self.app.caps.ffprobe_path
        reference_clips = copy.deepcopy(reference_clips)
        ids = [c.id for c in clips]
        self._alignment_attempt_ids = tuple(ids)
        master = self.project.master_audio
        mode = 'full' if self.sync_mode_var.get().startswith('完整') else 'fast'
        began = time.monotonic()
        def worker():
            try:
                progress=lambda percent,phase:self.jobs.put(('sync_progress',(percent,phase)))
                results = align_camera_tracks(ffmpeg, sync_clips, master,
                    reference_clips=reference_clips,
                    ffprobe_path=sync_ffprobe, mode=mode,
                    cancel_event=self.app.cancel_event, progress=progress, fps=sync_fps)
                if self.app.cancel_event.is_set(): raise ExportCancelled('同步已取消')
                self.jobs.put(('aligned', (list(zip(ids, results)), time.monotonic() - began)))
            except ExportCancelled:
                self.jobs.put(('align_cancelled', None))
            except Exception as exc: self.jobs.put(('align_error', str(exc)))
        threading.Thread(target=worker, daemon=False).start()

    def _finish_alignment(self, pairs, elapsed=0.0):
        self.busy = False
        self.sync_running = False
        self.app._set_working(False)
        if self.app.cancel_event.is_set():
            message = '已取消同步，保留原时间线'
            self.status.set(message)
            self.app.progress_text_var.set(message)
            return
        targets = quantized_alignment_targets(self.project.clips, pairs, self.project.fps)
        for clip_id, result in pairs:
            clip = next((c for c in self.project.clips if c.id == clip_id), None)
            if clip is not None and clip_id in targets:
                target = targets[clip_id]
                if not self._can_move_timeline_clip(clip, target):
                    self.app.progress_text_var.set(self.status.get())
                    return
        self._remember()
        details = []
        placed = []
        review = []
        for clip_id, result in pairs:
            clip = next((c for c in self.project.clips if c.id == clip_id), None)
            if clip is None: continue
            self.sync_results[clip_id] = result
            if clip_id in targets:
                self._move_clip_start(clip, targets[clip_id])
                placed.append(clip)
            else:
                review.append(clip)
            position = format_signed_time(-result.offset_seconds) if math.isfinite(result.offset_seconds) else '无效位置'
            details.append(f'{Path(clip.path).name}: {result.confidence:.3f}, {position} · {result.engine}')
        self.app._log('多机位同步并对齐：\n'+'\n'.join(details))
        self._refresh()
        self.fit_timeline()
        if not self._media_visible: self.toggle_media_pool()
        self._select_workspace_page(self.tools, self.media_tab)
        target = placed[0] if placed else review[0] if review else None
        if target:
            self.media_tree.selection_set(target.id)
            self.media_tree.see(target.id)
            self.seek(max(0.0, target.start))
        self.app.progress_var.set(100)
        reference_label=getattr(self,'_alignment_reference_label','主音频')
        message = f'已将 {len(placed)} 段机位画面直接对齐到{reference_label}时间线 · {elapsed:.1f} 秒'
        if review: message += f' · {len(review)} 段待检查（保留原位置）'
        self.status.set(message)
        self.app.progress_text_var.set(message)
        self._alignment_attempt_ids = ()
        if review: self._show_sync_review()

    def _select_cut(self, event=None):
        selection = self.cut_tree.selection()
        if selection:
            self.selected_cut = int(selection[0])
            cut = self.project.cuts[self.selected_cut]
            self.cut_time_var.set(format_time(cut.time)); self.cut_camera_var.set(str(camera_number(self.project, cut.camera)))

    def _jump_cut(self, event=None):
        self._select_cut()
        if self.selected_cut is not None and self.selected_cut < len(self.project.cuts):
            self.seek(self.project.cuts[self.selected_cut].time)

    def edit_cut(self):
        if not self._available(): return
        try:
            time = parse_timecode(self.cut_time_var.get())
            camera = camera_id_for_number(self.project, self.cut_camera_var.get())
            from multicam_outer import outer_cameras
            if camera in outer_cameras(self.project): raise ValueError('外层机位不属于多机位内部切点，请在对应外层轨道上编辑。')
            if camera not in self.project.cameras: raise ValueError('这个机位还没有素材。')
            if not 0 <= time < self.project.duration: raise ValueError('切点须位于工程范围内。')
        except ValueError as exc:
            messagebox.showerror('切点', str(exc), parent=self); return
        self._remember()
        if self.selected_cut is not None and self.selected_cut < len(self.project.cuts):
            del self.project.cuts[self.selected_cut]
        self.project.set_cut(time, camera)
        self.selected_cut = None
        self._refresh()

    def delete_cut(self):
        if not self._available(): return
        selection = self.cut_tree.selection()
        if selection:
            self._remember(); del self.project.cuts[int(selection[0])]
            self.selected_cut = None; self._refresh()

    def _monitor_camera_click(self, camera):
        # Monitor clicks are edits even after Replay has disabled recording.
        # switch() resolves a selected programme range before inserting a cut.
        self.switch(camera, record=True)
        self._focus_preview()

    def switch(self, camera, *, record=None):
        if not self._available() or camera not in self.project.cameras: return
        from multicam_outer import outer_cameras
        if camera in outer_cameras(self.project) and not self._color_mode:
            self._displayed_camera = camera
            self._highlight(camera)
            self.status.set(self._label_camera(camera)+' · 外层机位；在外层轨道上编辑，内部切点保持不变。')
            return
        if self.project.video_stack_enabled and self._color_mode:
            self._displayed_camera = camera
            self.set_grade_target(camera)
            self._highlight(camera)
            self._set_program_label(camera)
            self.status.set(f'已选图层 V{camera_number(self.project, camera)}；可调整整机位调色，合成顺序及原节目切点保留。')
            return
        if self.selected_program_range is not None:
            self._switch_selected_camera(camera)
            return
        was_stack = self.project.video_stack_enabled and not self.project.multicam_outer_order
        recording = self.record_var.get() if record is None else record
        if recording or was_stack:
            self._remember()
        if was_stack:
            self._finish_preview_epoch(seek=False)
            self.project.video_stack_enabled = False
            self._set_stack_preview_mode(False)
        if recording:
            self.project.set_cut(self.current, camera)
        if recording or was_stack:
            self._refresh(False)
            self._configure_player()
        if not recording and self.player:
            self.player.submit('audition', camera=camera)
        self._displayed_camera = camera
        self.program_var.set('成片监看 · '+self._label_camera(camera) + ('' if recording else '（试听）'))
        self._highlight(camera)
        self.status.set(f'已切换到机位 {camera_number(self.project, camera)}' + ('，已在播放头记录切点。' if recording else '（试听，未记录切点）。'))

    def start_monitors(self):
        if not self._available() or not (self.project.clips or source_audio_clips(self.project) or self.project.master_audio): return
        if not self._can_start_transport_monitors(): return
        if not self.app.mpv_path:
            messagebox.showerror('监看', '请将 mpv.exe 放入 bin 文件夹。', parent=self); return
        if not self.player:
            self.update_idletasks()
            self._show_program_view(self.program_views[0].winfo_id())
            self.player = MulticamPlayer(self.app.mpv_path,
                {c: surface.winfo_id() for c, surface in self.camera_surfaces.items()},
                self.program_views[0].winfo_id(), self.audio_surface.winfo_id(), self.player_queue,
                program_standby_window=self.program_views[1].winfo_id(),
                gpu_live=self.gpu_live_var.get(),gpu_output_window=self.program_surface.winfo_id(),
                stack_gpu=self._ensure_stack_gpu(),
                comparison_window=self.comparison_views[0].winfo_id(),comparison_standby_window=self.comparison_views[1].winfo_id())
        self._configure_player()
        # Navigation can happen before the first player exists. Preserve its
        # request fence, otherwise every player state (id 0) is rejected and
        # the UI play state/time never advances after that first seek.
        self.player.submit('seek', time=self.current, request_id=self._transport_request_id)
        self.status.set('正在打开调色监看：调色及标准机位使用原片，其他机位遵循代理设置。' if self._color_mode else
                        '正在打开同步监看；多路原片较大时请使用代理。')

    def _show_program_view(self, window):
        if self._stack_preview_active:
            self._program_front_window = window
            return True
        if self._gpu_live_active:return False
        view = next((view for view in self.program_views if view.winfo_id() == window), None)
        if view is None: return False
        view.lift()
        self._program_front_window = window
        return True

    def _show_comparison_view(self,window):
        if self._stack_preview_active:
            self._comparison_front_window = window
            return True
        view=next((view for view in self.comparison_views if view.winfo_id()==window),None)
        if view is None:return False
        view.lift();self._comparison_front_window=window
        return True

    def _set_comparison_layout(self,enabled):
        self._comparison_layout_enabled=bool(enabled)
        self.stabilization_compare_var.set(bool(enabled))
        header=self._px(23)
        if enabled:
            for view in self.program_views:view.place(relx=.5,x=0,y=header,relwidth=.5,relheight=1,height=-header)
            for view in self.comparison_views:view.place(relx=0,x=0,y=header,relwidth=.5,relheight=1,height=-header)
            self.comparison_original_label.place(relx=0,y=0,relwidth=.5,height=header)
            self.comparison_stabilized_label.place(relx=.5,y=0,relwidth=.5,height=header)
            self._show_comparison_view(self._comparison_front_window)
        else:
            for view in self.comparison_views:view.place_forget()
            self.comparison_original_label.place_forget();self.comparison_stabilized_label.place_forget()
            for view in self.program_views:
                if self._gpu_live_active:view.place_forget()
                else:view.place(relx=0,x=0,y=0,relwidth=1,relheight=1,height=0)
        self._show_program_view(self._program_front_window)
        self._raise_stack_preview()
        self.update_idletasks()

    def toggle_stabilization_compare(self):
        enabled=self.stabilization_compare_var.get()
        if not self._available():
            self.stabilization_compare_var.set(self._comparison_layout_enabled);return
        if enabled and not self.project.stabilizations:
            self.stabilization_compare_var.set(False);return
        self._set_comparison_layout(enabled)
        self._comparison_requested=enabled
        if enabled and not self.player:self.start_monitors()
        if self.player:self.player.submit('stabilization_compare',enabled=enabled)

    def _sync_comparison_state(self,payload):
        if 'comparison_enabled' not in payload:return
        enabled=bool(payload['comparison_enabled'])
        if self._comparison_requested is not None:
            if enabled!=self._comparison_requested:return
            self._comparison_requested=None
        if enabled!=self._comparison_layout_enabled:self._set_comparison_layout(enabled)
        self.comparison_stabilized_label.configure(text='防抖后 · 含裁切' if payload.get('stabilization_active') else '当前段未防抖')

    def _configure_player(self):
        use_proxies = self._preview_use_proxies()
        if self.player:
            cameras = self._color_original_cameras()
            self.player.submit('configure', project=copy.deepcopy(self.project), use_proxies=use_proxies,
                               gpu_live=self.gpu_live_var.get(), stack_gpu=self._ensure_stack_gpu(), original_cameras=cameras,
                               color_monitoring=bool(self._color_mode))
            self._published_original_cameras = cameras
            self._published_color_monitoring = bool(self._color_mode)
            self._publish_transition_previews()
            self._publish_prerender()
            if self.stabilization_compare_var.get():self.player.submit('stabilization_compare',enabled=True)
            if self._color_mode:
                self._audition_grade_target()
            else:
                self.player.submit('audition',camera=None)

    def _audio_track_changed(self):
        self._configure_player()

    def _toggle_gpu_live(self):
        self._gpu_live_failed=False
        self._configure_player()
        self._schedule_transition_previews()

    def _set_gpu_live_state(self,payload):
        enabled=bool(payload.get('enabled'))
        self._gpu_live_active=enabled
        if enabled:
            self._gpu_live_failed=False
            for view in self.program_views:view.place_forget()
            self.status.set('GPU 实时监看 · 双路纹理合成 · 转场后机位连续播放')
        else:
            self._set_comparison_layout(self._comparison_layout_enabled)
            if payload.get('reason'):
                self._gpu_live_failed=True
                self.status.set(str(payload['reason']))
                self._schedule_transition_previews()

    def stop_monitors(self):
        self._reset_playback_metrics()
        self._set_stack_preview_mode(False)
        self._close_stack_gpu()
        self._reset_transport_controls()
        self.clear_grade_preview()
        if self.player:
            self._track_stopped_player(self.player)
            self.player.close()
            self.player = None
            self.player_queue = queue.Queue()
        self._gpu_live_active=False
        self._set_comparison_layout(self._comparison_layout_enabled)
        self.playing = False

    def pause(self):
        if self.player: self.player.submit('pause')
        self.playing = False
        self._reset_playback_metrics()

    def toggle(self):
        # Playback remains controllable while an independent import/proxy job
        # is running; only opening a new set of decoders requires availability.
        if self.player is None and not self._available(): return
        audio = vars(self).get('audio_workspace')
        if not self.playing and audio and not audio.ensure_playback(): return
        self._stop_transport_hold()
        if not self.player: self.start_monitors()
        if self.player: self.player.submit('toggle')

    def replay(self):
        if not self._available(): return
        audio = vars(self).get('audio_workspace')
        if audio and not audio.ensure_playback(): return
        self.record_var.set(False)
        if not self.player: self.start_monitors()
        if self.player:
            self.player.submit('audition', camera=None)
            try: start = self._read_range()[0]
            except ValueError as exc:
                messagebox.showerror('成片范围', str(exc), parent=self); return
            self.player.submit('seek', time=start)
            self.player.submit('play')

    def seek(self, time):
        return self._request_transport_seek(time, pause=True)

    def _sync_seek_time(self, *, force=False):
        # Keep an unfinished edit intact while player state keeps arriving.
        if force or self.seek_var.get() == self._seek_display_text:
            self._seek_display_text = format_time(self.current)
            if self.seek_var.get() != self._seek_display_text:
                self.seek_var.set(self._seek_display_text)

    def _cancel_seek_text(self, _event=None):
        self._sync_seek_time(force=True)
        return 'break'

    def seek_text(self, event=None):
        focus_out = event is not None and event.type == tk.EventType.FocusOut
        if focus_out and self.seek_var.get() == self._seek_display_text:
            return
        try:
            self.seek(parse_timecode(self.seek_var.get()))
        except ValueError as exc:
            self._sync_seek_time(force=True)
            if focus_out:
                self.status.set('定位时间无效：' + str(exc))
            else:
                messagebox.showerror('时间码', str(exc), parent=self)
        else:
            self._sync_seek_time(force=True)
        if not focus_out:
            return 'break'

    def _show_time(self):
        self._refresh_proxy_badges()
        self.time_var.set(f'{format_time(self.current)} / {format_time(self.project.duration)}')
        self._sync_seek_time()
        for camera,button in self.camera_buttons.items():
            label=self._camera_button_label(camera)
            if button.cget('text')!=label: button.configure(text=label)
        inspector = vars(self).get('clip_inspector')
        if inspector is not None and not self.playing and self._inspector_visible:
            inspector.refresh_playhead()

    def _highlight(self, camera):
        states = getattr(self, '_camera_highlight_states', {})
        current = {}
        for c, button in self.camera_buttons.items():
            selected = c == camera
            frame = self.camera_frames[c]
            state = (button, frame, selected)
            current[c] = state
            if states.get(c) == state: continue
            button.configure(bg='#42302f' if selected else PANEL,
                             fg=PINK if selected else INK)
            frame.configure(bg=PINK if selected else '#414449')
        self._camera_highlight_states = current

    def _key(self, event):
        if not self.winfo_ismapped(): return
        if self._transport_input_widget(event.widget): return
        if event.keysym == 'F11':
            return self._toggle_program_fullscreen(event)
        if event.keysym == 'Escape' and self.dock_manager.fullscreen.exit():
            return 'break'
        action = self._keyboard_action(event)
        if action == 'escape':
            if self._media_drag_cancel() == 'break': return 'break'
            browser = vars(self).get('effects_browser')
            if browser is not None and vars(browser).get('_effect_drag') is not None:
                browser._effect_drag_cancel(event)
                return 'break'
            self._stop_transport_hold()
            if self._end_timeline_divider_drag(cancel=True): return 'break'
            if self._finish_selection_gesture(cancel=True): return 'break'
            if self._timeline_scrubbing:
                self._timeline_scrubbing = False
                self._timeline_drag_geometry = None
            if self._end_video_stack_drag(cancel=True): return 'break'
            if self._end_program_boundary_drag(cancel=True): return 'break'
            self._set_keyboard_tool('select')
            self.selected_program_range = None
            self._set_timeline_selection(set(), redraw=False)
            self.creative_panel_refresh()
            self.draw_timeline()
            if vars(self).get('color_workspace'): self.color_workspace.refresh()
            self.status.set('已取消片段选中；数字键恢复播放头机位操作。')
            return 'break'
        return self._dispatch_keyboard_action(action, event)

    def undo(self):
        if self._finish_selection_gesture(cancel=True): return
        if getattr(self, '_end_video_stack_drag', lambda **_kwargs: False)(cancel=True): return
        if getattr(self, '_end_program_boundary_drag', lambda **_kwargs: False)(cancel=True): return
        if not self._available() or not self.undo_stack: return
        self._cancel_grade_drafts()
        self.redo_stack.append(copy.deepcopy(self.project)); self.project = self.undo_stack.pop()
        self._restore_timeline_range_fields()
        self.selected_program_range = None
        self.sync_results.clear()
        self._mark_dirty(); self._refresh()

    def redo(self):
        if self._finish_selection_gesture(cancel=True): return
        if getattr(self, '_end_video_stack_drag', lambda **_kwargs: False)(cancel=True): return
        if getattr(self, '_end_program_boundary_drag', lambda **_kwargs: False)(cancel=True): return
        if not self._available() or not self.redo_stack: return
        self._cancel_grade_drafts()
        self.undo_stack.append(copy.deepcopy(self.project)); self.project = self.redo_stack.pop()
        self._restore_timeline_range_fields()
        self.selected_program_range = None
        self.sync_results.clear()
        self._mark_dirty(); self._refresh()

    def _confirm_discard(self):
        if not self.dirty:
            self._persist_timeline_view()
            return True
        answer = messagebox.askyesnocancel('多机位工程', '保存当前多机位工程后再继续？', parent=self)
        if answer is None: return False
        if answer: return self.save()
        self._persist_timeline_view()
        return True

    def new(self):
        if not self.project_path and getattr(self.app, 'project_path', None):
            return self.app._project_new()
        if not self._available() or not self._confirm_discard(): return
        self._reset_quick_proxy()
        self.stop_monitors(); self.project = MulticamProject(); self.project_path = ''
        self._project_upgrade_blocked_path = None
        self.selected_program_range = None
        self.camera_page=0
        self._camera_metadata_attempted.clear()
        self.grade_target = None; self._grade_target_chosen = False
        self.sync_results.clear()
        self.dirty = False; self.undo_stack.clear(); self.redo_stack.clear(); self.current = 0
        self._sync_seek_time(force=True)
        self._loading_fields = True
        self.start_var.set(format_time(0)); self.end_var.set(''); self.fps_var.set('30')
        self._loading_fields = False
        self.project_label.configure(text='未保存工程'); self._refresh()
        self._restore_timeline_view()

    def open(self):
        if not self._available(): return
        path = filedialog.askopenfilename(parent=self, title='打开工程',
            filetypes=[('OKK STUDIO 工程', '*.rtxproj *.multicam.json'),
                       ('完整工程', '*.rtxproj'), ('多机位工程', '*.multicam.json'), ('JSON', '*.json')])
        if path: self.load_project(path)

    def load_project(self, path):
        if path:
            if Path(path).suffix.lower() == '.rtxproj':
                # Complete sessions have their own state container and save
                # lifecycle. Passing one to MulticamProject.load rejects its
                # outer format and can lose other workspaces on later saves.
                opener = getattr(self.app, '_project_open', None)
                if callable(opener):
                    return opener(path)
                messagebox.showerror('打开工程', '请在 OKK STUDIO 完整工程入口打开此文件。', parent=self)
                return
            if not self._available() or not self._confirm_discard(): return
            try:
                source_data, original_bytes = read_project_snapshot(path)
                project = MulticamProject.from_payload(source_data, Path(path).resolve().parent)
            except Exception as exc: messagebox.showerror('打开工程', str(exc), parent=self); return
            self._reset_quick_proxy()
            self.stop_monitors(); self.project = project; self.project_path = path; self.dirty = False
            self._project_upgrade_blocked_path = None
            self.selected_program_range = None
            self.camera_page=project.monitor_layout.get('page', self.camera_page)
            self._camera_metadata_attempted.clear()
            self.grade_target = None; self._grade_target_chosen = False
            self.sync_results.clear()
            self.undo_stack.clear(); self.redo_stack.clear(); self.current = 0
            self._sync_seek_time(force=True)
            self._loading_fields = True
            self.start_var.set(format_time(project.range_start))
            self.end_var.set(format_time(project.range_end) if project.range_end is not None else '')
            self.fps_var.set(f'{project.fps:.12g}'); self.project_label.configure(text=Path(path).name)
            self._loading_fields = False
            missing = [c.path for c in project.clips if not Path(c.path).is_file()]
            self._use_project_delivery_defaults()
            self._refresh()
            self._restore_monitor_layout()
            self._restore_timeline_view()
            try:
                upgraded = upgraded_standalone_payload(source_data, self, path)
                backup = write_project_upgrade(path, original_bytes, upgraded)
            except (OSError, ValueError, TypeError) as error:
                self._project_upgrade_blocked_path = str(Path(path).resolve())
                self.status.set('工程已打开，但自动升级未完成：' + str(error))
                messagebox.showwarning('工程自动升级',
                    '工程已打开，原文件保留。自动升级未完成：\n' + str(error), parent=self)
            else:
                if backup is not None:
                    self.project.timeline_view = upgraded['timeline_view']
                    self.project.monitor_layout = upgraded.get('monitor_layout', {})
                    self.status.set('工程已自动升级；原文件备份：' + backup.name)
            if missing: messagebox.showwarning('素材缺失', '\n'.join(missing[:8]), parent=self)

    def _read_range(self):
        start = parse_timecode(self.start_var.get() or '0')
        end = parse_timecode(self.end_var.get()) if self.end_var.get().strip() else None
        fps = float(self.fps_var.get())
        if not math.isfinite(fps) or not 1 <= fps <= 240: raise ValueError('FPS 请输入 1–240 之间的数字。')
        if start < 0 or (end is not None and end <= start): raise ValueError('成片终点必须晚于起点。')
        return start, end, fps

    def save(self):
        if not self._available(): return False
        if not self.project_path and getattr(self.app, 'project_path', None):
            return self.app._project_save()
        path = self.project_path or filedialog.asksaveasfilename(parent=self, title='保存多机位工程', defaultextension='.multicam.json', filetypes=[('多机位工程', '*.multicam.json')])
        if not path: return False
        try:
            self.project.range_start, self.project.range_end, self.project.fps = self._read_range()
            self.project.monitor_layout = self._capture_monitor_layout()
            self.project.timeline_view = self._capture_timeline_view()
            self.project.save(path)
        except Exception as exc: messagebox.showerror('保存工程', str(exc), parent=self); return False
        self.project_path = path; self.dirty = False; self.project_label.configure(text=Path(path).name)
        self._project_upgrade_blocked_path = None
        self.status.set('工程已保存（保留素材位置、同步时间与全部切点）。')
        return True

    def choose_output(self):
        suffix = '.' + self.delivery_container_var.get().strip().lower().lstrip('.')
        if suffix not in {'.mp4', '.mov', '.mkv'}: suffix = '.mp4'
        types = [(suffix[1:].upper(), '*'+suffix)] + [(name, '*.'+name.lower())
                 for name in ('MP4','MOV','MKV') if '.'+name.lower() != suffix]
        path = filedialog.asksaveasfilename(parent=self, title='多机位成片', defaultextension=suffix, filetypes=types)
        if path:
            self.output_var.set(path)
            chosen = Path(path).suffix.lower()
            if chosen in {'.mp4','.mov','.mkv'}: self.delivery_container_var.set(chosen[1:].upper())

    def preview_effects(self):
        if not self._available(): return
        if not self.project.clips:
            messagebox.showinfo('效果预览', '请先导入视频机位。字幕可以先导入、编辑并保存。', parent=self)
            return
        try:
            if not self.app.caps.ffmpeg_path or not self.app.caps.ffprobe_path:
                raise ValueError('请等待 FFmpeg 检测完成。')
            if not self.app.mpv_path:
                raise ValueError('未找到 mpv.exe，无法打开内嵌效果预览。')
            project = copy.deepcopy(self.project)
            project.fps = float(canonical_frame_rate(float(self.fps_var.get())))
            start = max(0.0, min(self.current - 2.0, project.duration - 5.0))
            end = min(project.duration, start + 5.0)
            start = math.floor(start * project.fps + .5) / project.fps
            end = math.floor(end * project.fps + 1e-9) / project.fps
            project.range_start, project.range_end = start, end
            project.subtitles.burn_in = True
            project.validate()
            if self._creative_preview_folder is None:
                self._creative_preview_folder = Path(tempfile.mkdtemp(prefix='okk_effect_preview_',dir=cache_dir('previews/effects')))
            self._creative_preview_sequence += 1
            output = self._creative_preview_folder / f'preview_{self._creative_preview_sequence:04d}.mp4'
            from hardware_encoders import preferred_codec
            codec = preferred_codec(self.app.caps, 'h264')
            settings = ExportSettings(codec=codec,
                preset='p2', quality=20, resolution='1080p',
                bit_depth='8-bit', audio='none', decode_mode='cuda' if codec.endswith('_nvenc') and self.app.caps.cuda_decode else 'cpu', parallel_workers=1)
        except Exception as exc:
            messagebox.showerror('效果预览', str(exc), parent=self); return
        self._comparison_requested=None
        self._set_comparison_layout(False)
        self.stop_monitors()
        self.app.cancel_event.clear(); self.app._set_working(True); self.busy = True
        self.export_monitor.grid_remove()
        self.app._begin_shared_progress('生成效果预览 0.0%')
        self.status.set('正在生成当前播放头附近的 5 秒效果预览…')

        def worker():
            try:
                render_multicam(project, output, self.app.caps.ffmpeg_path, self.app.caps.ffprobe_path,
                    settings, self.app.caps, self.app._run_editor_process,
                    progress=lambda done, total, phase: self.jobs.put(('preview_progress',
                        (min(99.9, 100 * done / max(total, .001)), phase))),
                    cancel_event=self.app.cancel_event)
                self.jobs.put(('preview_ready', (str(output), start, end)))
            except Exception as exc:
                self.jobs.put(('preview_error', (str(exc), self.app.cancel_event.is_set())))
        self._creative_preview_worker = threading.Thread(target=worker, daemon=False)
        self._creative_preview_worker.start()

    def export(self, render_job=None):
        if not self._available(): return False
        try:
            prepared = ((copy.deepcopy(render_job.project), copy.deepcopy(render_job.settings), render_job.output)
                        if render_job is not None else self.prepare_delivery_export())
            if prepared is None: return False
            project, settings, output = prepared
            project.validate()
            from hardware_encoders import available_codecs
            if settings.codec not in available_codecs(self.app.caps):
                raise ValueError('当前编码器不可用；请等待 GPU 检测完成或选择 CPU 兼容模式。')
            if not self.app.caps.ffmpeg_path or not self.app.caps.ffprobe_path:
                raise ValueError('未找到 FFmpeg / ffprobe。')
            if Path(output).exists() and not messagebox.askyesno('覆盖成片', f'替换已有成片？\n{output}', parent=self): return False
        except Exception as exc: messagebox.showerror('多机位导出', str(exc), parent=self); return False
        self.stop_monitors()
        if self.app.mpv:
            try: self.app.mpv.command(['set_property', 'pause', True])
            except Exception: pass
        self.app.cancel_event.clear(); self.app._set_working(True)
        self.busy = True
        self.delivery_export_button.configure(state='disabled')
        self._export_started_at = time.monotonic()
        self._export_last_snapshot = {}
        self._begin_export_tracking(project, output)
        self.app._begin_shared_progress('多机位导出 0.0%')
        self._update_export_metrics(dict(stage='preparing', phase='准备多机位导出', progress_percent=0,
            fps=0, speed=0, elapsed=0, eta=None, active_workers=0))
        self.status.set('正在按切点导出画面，并混合已设为出声的音轨…')
        def progress(done, total, phase):
            self.jobs.put(('progress', (min(99.9, 100*done/max(total, 0.001)), phase)))
        def worker():
            try:
                render_multicam(project, output, self.app.caps.ffmpeg_path, self.app.caps.ffprobe_path,
                                settings, self.app.caps, self.app._run_editor_process, progress=progress,
                                cancel_event=self.app.cancel_event,
                                metrics=lambda snapshot: self.jobs.put(('export_metrics', snapshot)))
                self.jobs.put(('exported', output))
            except Exception as exc:
                self.jobs.put(('export_error', (str(exc), self.app.cancel_event.is_set() or isinstance(exc, ExportCancelled))))
        threading.Thread(target=worker, daemon=False).start()
        return True


    def _scroll_timeline(self, *args):
        self.timeline.xview(*args)
        self._pin_timeline_headers()
        self.draw_playhead()
        self._queue_timeline_redraw()

    def change_zoom(self, factor):
        if self._timeline_navigation_locked():
            return
        canvas = self.timeline
        origin, old_scale = self._timeline_origin(), self._timeline_scale()
        anchor_time = self.current
        anchor_x = self._timeline_left+(anchor_time-origin)*old_scale-canvas.canvasx(0)
        left, right = self._timeline_left, canvas.winfo_width()-self._px(16)
        # Keep the visible playhead fixed on screen. If the user has panned
        # away from it, bring it to the middle of the editing area on zoom.
        if not left <= anchor_x <= right:
            anchor_x = (left+right)/2
        changed = min(10000, max(1, self.zoom*factor))
        if changed == self.zoom:
            return
        self.zoom = changed
        scale = self._timeline_scale()
        width = max(canvas.winfo_width(), self._timeline_left+
                    (self._timeline_view_duration()-origin)*scale+self._px(16))
        bounds = tuple(float(value) for value in canvas.cget('scrollregion').split())
        canvas.configure(scrollregion=(0, 0, width, bounds[3] if len(bounds) == 4 else canvas.winfo_height()))
        target_left = self._timeline_left+(anchor_time-origin)*scale-anchor_x
        canvas.xview_moveto(max(0., target_left/max(1., width)))
        self._pin_timeline_headers()
        self.draw_playhead()
        self._queue_timeline_redraw()

    def fit_timeline(self):
        if (self._timeline_drag_geometry is not None or getattr(self, '_selection_gesture', None)
                or getattr(self, '_timeline_divider_drag', None)):
            return
        self.zoom = 1; self.timeline.xview_moveto(0); self.draw_timeline()

    def pan_timeline(self, event):
        if self._timeline_navigation_locked(): return 'break'
        steps = self._timeline_wheel_steps(event, 'pan')
        if steps:
            self._scroll_timeline('scroll', -3 * steps, 'units')
        return 'break'

    def _pin_timeline_headers(self):
        headers = self.timeline.find_withtag('stack-header')
        if headers:
            coordinates = self.timeline.coords(headers[0])
            if coordinates:
                self.timeline.move('stack-header', self.timeline.canvasx(0)-coordinates[0], 0)

    def _timeline_fit_label(self, font, title, width):
        width = max(0, int(width))
        cache = vars(self).setdefault('_timeline_text_cache', {})
        key = (str(font), title, width)
        if key in cache:
            return cache[key]
        if font.measure(title) <= width:
            result = title
        else:
            low, high = 0, len(title)
            while low < high:
                middle = (low+high+1)//2
                if font.measure(title[:middle]) <= width:
                    low = middle
                else:
                    high = middle-1
            result = title[:low]
        if len(cache) >= 4096:
            cache.clear()
        cache[key] = result
        return result

    def _timeline_scale(self):
        if self._timeline_drag_geometry is not None: return self._timeline_drag_geometry[1]
        return max(1, self.timeline.winfo_width() - self._timeline_left - self._px(16)) / max(1, self._timeline_view_duration()-self._timeline_origin()) * self.zoom

    def _timeline_view_duration(self):
        marker_end = self._timeline_marker_extent()
        if self._timeline_drag_geometry is not None:
            return max(self.project.duration, self._timeline_drag_geometry[2], marker_end)
        if self.project.duration > 0: return max(self.project.duration, marker_end)
        track = self.project.subtitles
        return max(60., marker_end, max((cue.end + track.offset for cue in track.cues), default=0.0))

    def _timeline_origin(self):
        if self._timeline_drag_geometry is not None: return self._timeline_drag_geometry[0]
        return min(0.0, min((clip.start for clip in self.project.clips), default=0.0))

    def _timeline_x(self, time):
        return self._timeline_left + (time-self._timeline_origin())*self._timeline_scale()

    def draw_timeline(self):
        canvas = self.timeline
        canvas.delete('all')
        cameras = self._timeline_camera_order()
        source_cameras = self.project.timeline_cameras
        collapsed = self.project.timeline_multicam_collapsed
        height = max(self._px(100), canvas.winfo_height())
        left_edge = self._timeline_left
        origin = self._timeline_origin()
        pps = self._timeline_scale()
        timeline_x = lambda value: left_edge + (value-origin)*pps
        width = max(canvas.winfo_width(), left_edge + (self._timeline_view_duration()-origin) * pps + self._px(16))
        self.timeline_clip_items = {}
        self.timeline_program_items = {}
        self.timeline_subtitle_items = {}
        self.timeline_transition_items = {}
        self.timeline_audio_items = set()
        self._timeline_track_bounds = {}
        label_font = self._timeline_label_font
        title_font = self._timeline_title_font
        ruler_font = self._timeline_ruler_font
        ruler_h = max(self._px(27), ruler_font.metrics('linespace') + self._px(9))
        self._timeline_ruler_h = ruler_h
        program_h = max(self._px(31), title_font.metrics('linespace') + self._px(9))
        self._timeline_program_bounds = (ruler_h, ruler_h + program_h)
        audio_h = max(self._px(40), label_font.metrics('linespace') + self._px(20))
        subtitle_h = max(self._px(30), label_font.metrics('linespace') + self._px(8))
        subtitle_y = ruler_h + (0 if collapsed else program_h) + self._px(3)
        self._timeline_subtitle_bounds = (subtitle_y, subtitle_y+subtitle_h)
        track_top = subtitle_y + subtitle_h + self._px(6)
        minimum_row = label_font.metrics('linespace') + self._px(6)
        row_h, audio_y, content_height = self._timeline_track_layout(
            cameras, height, track_top, minimum_row, audio_h)
        program_top = ruler_h
        if collapsed:
            program_h = row_h
            program_top = track_top + cameras.index(0)*row_h
        program_bottom = program_top + program_h
        self._timeline_program_bounds = (program_top, program_bottom)
        canvas.configure(scrollregion=(0, 0, width, content_height))
        if content_height > canvas.winfo_height() + self._px(2):
            self.timeline_vscroll.grid()
        else:
            self.timeline_vscroll.grid_remove()
            canvas.yview_moveto(0)
        margin = self._px(3)
        view_left, view_right = canvas.canvasx(0)-margin, canvas.canvasx(canvas.winfo_width())+margin
        view_top, view_bottom = canvas.canvasy(0)-margin, canvas.canvasy(canvas.winfo_height())+margin
        def visible(x, y, x2, y2):
            return x2 >= view_left and x <= view_right and y2 >= view_top and y <= view_bottom
        duration = self._timeline_view_duration()
        canvas.create_rectangle(0, 0, width, ruler_h, fill='#292b2e', outline='')
        canvas.create_rectangle(0, program_top, width, program_bottom, fill='#27292c', outline='')
        canvas.create_text(self._px(8), program_top + program_h / 2, text='多机位' if collapsed else '合成' if self.project.video_stack_enabled else '节目', fill=INK, anchor='w',
                           font=title_font)
        displayed_project = self.project
        if self._timeline_drag_geometry is not None:
            # Keep existing cut/grade boundaries valid until the gesture is
            # committed and _refresh trims them to a shorter programme.
            displayed_project = copy.copy(self.project)
            displayed_project.master_duration = max(self.project.master_duration, self._timeline_drag_geometry[2])
        # Programme geometry is independent of selection and viewport. Avoid
        # validation/sorting again for every mouse movement or scroll tick.
        from multicam_outer import compound_duration
        group_end = compound_duration(self.project) if self.project.multicam_outer_order else displayed_project.duration
        span_key = (id(self.project), self.project.fps, displayed_project.duration, group_end, tuple(cameras),
                    tuple((item.time, item.camera) for item in self.project.cuts),
                    tuple(self.project.edit_points),
                    tuple((item.start, item.end) for item in self.project.clip_grades),
                    tuple((item.start, item.end) for item in self.project.clip_transforms),
                    tuple((clip.id, clip.camera, clip.start, clip.end) for clip in self.project.clips),
                    self.project.video_stack_enabled, tuple(self.project.stacked_cameras()))
        cached_spans = vars(self).get('_timeline_span_cache')
        if cached_spans is None or cached_spans[0] != span_key:
            from dataclasses import replace
            spans = [replace(span, end=min(span.end, group_end)) for span in program_media_spans(displayed_project)
                     if span.start < group_end]
            cached_spans = self._timeline_span_cache = (span_key, spans)
        displayed_spans = cached_spans[1]
        self._timeline_boundary_times = [span.start for span in displayed_spans if span.start > 0]
        self._update_timeline_snap_points()
        camera_clips = {camera: [] for camera in source_cameras}
        for clip in self.project.clips:
            camera_clips[clip.camera].append(clip)
        grades = sorted(self.project.clip_grades, key=lambda item: item.start)
        grade_starts = [item.start for item in grades]
        file_states = vars(self).setdefault('_timeline_cache_file_states', {})
        if len(file_states) > 2048:
            file_states.clear()
        checked_at = time.monotonic()
        for span in displayed_spans:
            x = timeline_x(span.start)
            x2 = timeline_x(span.end)
            if not visible(x, program_top, x2, program_bottom):
                continue
            span_sources = [clip for clip in camera_clips.get(span.camera, ())
                            if clip.start < span.end and clip.end > span.start]
            disabled = bool(span_sources) and not any(clip.enabled for clip in span_sources)
            item = canvas.create_rectangle(x, program_top + self._px(4), x2, program_bottom - self._px(3),
                fill='#383a3e' if disabled else COLORS[(span.camera-1) % 9], outline='#91a0ac',
                width=1, tags=('program',))
            self.timeline_program_items[item] = (span.start, span.end)
            if x2-x > self._px(24):
                stabilized = self.project.stabilization_at(span.camera,span.start)
                stabilization_label = ''
                if stabilized:
                    path = stabilized.cache_path
                    state = file_states.get(path)
                    if state is None or checked_at-state[0] >= 2.:
                        state = file_states[path] = (checked_at, Path(path).is_file())
                    stabilization_label = ' · 防抖' if state[1] else ' · 防抖待重建'
                sources = camera_clips.get(span.camera, ())
                source = max((clip for clip in sources if clip.start <= span.start < clip.end),
                             key=lambda clip: (clip.start, clip.id), default=None)
                if source is None:
                    source = next(iter(sources), None)
                camera_title = self.project.camera_names.get(span.camera) or (self._clip_camera_label(source) if source else '未知相机')
                grade_index = bisect_right(grade_starts, span.start+1e-8)-1
                graded = grade_index >= 0 and span.start < grades[grade_index].end-1e-8
                title=('已禁用 · ' if disabled else '')+f'{camera_number(self.project, span.camera)} · '+camera_title + (' · 调色' if graded else '') + stabilization_label
                title = self._timeline_fit_label(title_font, title, x2-x-self._px(12))
                item = canvas.create_text(x + self._px(7), program_top + program_h / 2,
                    text=title,
                    fill=MUTED if disabled else INK, anchor='w', font=title_font, tags=('program',))
                self.timeline_program_items[item] = (span.start, span.end)
        for transition in self.project.transitions:
            x = timeline_x(transition.time - transition.duration / 2)
            x2 = timeline_x(transition.time + transition.duration / 2)
            midpoint = timeline_x(transition.time)
            if x2 - x < self._px(10): x, x2 = midpoint - self._px(5), midpoint + self._px(5)
            if not visible(x, program_top, x2, program_bottom):
                continue
            item = canvas.create_rectangle(x, program_top + self._px(2), x2,
                program_bottom - self._px(2), fill='#a18a52', outline='#e3c980', tags=('transition',))
            self.timeline_transition_items[item] = transition.time
        for boundary in self._timeline_boundary_times:
            x = timeline_x(boundary)
            if not visible(x, program_top, x, program_bottom):
                continue
            self.timeline.create_line(x, program_top+self._px(2), x, program_bottom-self._px(2),
                fill='#c0d0dc', width=max(1, self._px(2)), tags=('program-boundary',))
        canvas.create_rectangle(0, subtitle_y, width, subtitle_y + subtitle_h, fill='#2b2831', outline='')
        canvas.create_text(self._px(8), subtitle_y + subtitle_h / 2, text='S1 字幕', fill='#c4a4e4',
                           anchor='w', font=label_font)
        track = self.project.subtitles
        for cue in track.cues:
            start, end = cue.start + track.offset, cue.end + track.offset
            if end <= 0 or start >= duration: continue
            x, x2 = timeline_x(max(0, start)), timeline_x(min(duration, end))
            if not visible(x, subtitle_y, x2, subtitle_y+subtitle_h):
                continue
            item = canvas.create_rectangle(x, subtitle_y + self._px(2), max(x+self._px(2), x2),
                subtitle_y + subtitle_h - self._px(2), fill='#71578a' if track.enabled else '#414048',
                outline='#b696d1', tags=('subtitle',))
            self.timeline_subtitle_items[item] = cue.id
            if x2-x > self._px(60):
                item = canvas.create_text(x+self._px(5), subtitle_y + subtitle_h/2,
                    text=cue.text.replace('\n', ' · ')[:60], fill=INK, anchor='w', font=label_font,
                    tags=('subtitle',))
                self.timeline_subtitle_items[item] = cue.id
        for i, camera in enumerate(cameras):
            y = track_top + i * row_h
            self._timeline_track_bounds[camera] = (y, y + row_h)
            if camera == 0:
                continue
            if y+row_h < view_top or y > view_bottom:
                continue
            canvas.create_rectangle(0, y, width, y + row_h, fill='#25272a' if i % 2 == 0 else '#222427',
                                    outline='')
            canvas.create_text(self._px(8), y + row_h / 2, text=f'V{camera_number(self.project, camera)}', fill=MUTED, anchor='w',
                               font=label_font)
            for clip in camera_clips[camera]:
                x = timeline_x(clip.start)
                x2 = timeline_x(clip.start + clip.duration)
                if x2 <= x or not visible(x, y, x2, y+row_h):
                    continue
                item = canvas.create_rectangle(x, y + self._px(1), x2, y + row_h - self._px(1),
                                                fill='#383a3e' if not clip.enabled or (self.project.video_stack_enabled and camera in self.project.video_stack_hidden) else COLORS[(camera-1) % 9], outline='#6b7f89', tags=('clip',))
                self.timeline_clip_items[item] = clip.id
                if x2-x > self._px(95):
                    camera_title = self.project.camera_names.get(camera) or self._clip_camera_label(clip)
                    title=('已禁用 · ' if not clip.enabled else '')+('α · ' if clip.has_alpha else '')+camera_title+' · '+Path(clip.path).name[:24]
                    title = self._timeline_fit_label(label_font, title, x2-x-self._px(12))
                    label = canvas.create_text(x + self._px(6), y + row_h / 2, text=title,
                                                fill=INK if clip.enabled else MUTED, anchor='w', font=label_font, tags=('clip',))
                    self.timeline_clip_items[label] = clip.id
            self._draw_stack_track_header(camera, y, row_h, label_font)
        if collapsed:
            self._draw_stack_track_header(0, program_top, program_h, label_font)
        for point in self.project.edit_points:
            x = timeline_x(point)
            if not visible(x, track_top, x, audio_y):
                continue
            canvas.create_line(x, track_top, x, audio_y-self._px(2), fill='#7193aa',
                               dash=(self._px(3), self._px(2)), tags=('edit-boundary',))
        self._draw_timeline_audio(cameras, audio_y, audio_h, width, label_font, timeline_x, visible)
        self._draw_timeline_divider(width)
        if not source_cameras:
            canvas.create_text(left_edge + self._px(15), ruler_h + program_h / 2, text='将素材拖到这里开始编辑',
                               fill=MUTED, anchor='w', font=title_font)
        label_width = ruler_font.measure('00:00:00.000') + self._px(35)
        step = max(1 / self.project.fps, label_width / max(pps, 0.00001))
        power = 10 ** math.floor(math.log10(step))
        step = next((m * power for m in (1, 2, 5, 10) if m * power >= step), 10 * power)
        left = canvas.canvasx(0)
        right = canvas.canvasx(canvas.winfo_width())
        tick = max(math.floor(origin/step)*step, math.floor((origin+(left-left_edge)/pps)/step)*step)
        count = 0
        ruler_top = self._timeline_ruler_top = canvas.canvasy(0)
        canvas.create_rectangle(0, ruler_top, width, ruler_top+ruler_h,
                                fill='#292b2e', outline='', tags=('timeline-ruler',))
        while (timeline_x(tick) <= right + label_width
               and tick <= duration and count < 500):
            x = timeline_x(tick)
            canvas.create_line(x, ruler_top+ruler_h - self._px(5), x, ruler_top+ruler_h,
                               fill='#63676d', tags=('timeline-ruler',))
            canvas.create_text(x + self._px(3), ruler_top+ruler_h / 2, text=format_signed_time(tick) if tick < 0 else format_time(tick), anchor='w', fill=MUTED,
                               font=ruler_font, tags=('timeline-ruler',))
            tick += step
            count += 1
        self._draw_prerender_line()
        self._draw_timeline_markers(ruler_h, content_height, ruler_font)
        self.draw_playhead()
        getattr(self, '_draw_timeline_selection', lambda: None)()
        canvas.tag_raise('timeline-ruler')
        canvas.tag_raise('head')

    def draw_playhead(self):
        self.timeline.delete('head')
        export_time = vars(self).get('_export_cursor_time')
        x = self._timeline_x(self.current if export_time is None else export_time)
        top = self.timeline.canvasy(0)
        bottom = self.timeline.canvasy(self.timeline.winfo_height())
        self.timeline.create_polygon(x-self._px(5), top, x+self._px(5), top,
                                      x+self._px(5), top+self._px(7), x, top+self._px(12),
                                      x-self._px(5), top+self._px(7), fill=PINK, outline='', tags='head')
        self.timeline.create_line(x, top+self._px(10), x, bottom, fill=PINK,
                                  width=max(1, self._px(1)), tags='head')
        if self._color_mode and vars(self).get('color_workspace'):
            self.color_workspace.update_playhead()

    def _follow_timeline_playhead(self, position=None):
        # Follow transport movement, not ordinary redraws: users can still
        # scroll elsewhere while paused without the viewport snapping back.
        if any(vars(self).get(name) for name in (
                'timeline_drag', 'subtitle_drag', '_program_boundary_drag',
                '_video_stack_drag', '_selection_gesture', '_timeline_divider_drag')):
            return
        canvas = self.timeline
        width = canvas.winfo_width()
        margin = self._px(24)
        usable = width-self._timeline_left-2*margin
        if usable <= 0: return
        x = self._timeline_x(self.current if position is None else position)
        left = canvas.canvasx(0)
        screen_x = x-left
        if self._timeline_left+margin <= screen_x <= width-margin:
            return
        region = tuple(float(value) for value in canvas.cget('scrollregion').split())
        if len(region) != 4 or region[2]-region[0] <= width: return
        # Page forward with room for the next shots; reverse navigation uses
        # the same rule from the other side of the visible editing area.
        fraction = .25 if screen_x > width-margin else .75
        target = x-(self._timeline_left+margin+usable*fraction)
        target = max(region[0], min(region[2]-width, target))
        if abs(target-left) < 1: return
        canvas.xview_moveto((target-region[0])/(region[2]-region[0]))
        self._pin_timeline_headers()
        self._queue_timeline_redraw()

    def timeline_press(self, event):
        if not self._available(): return
        if self._timeline_ruler_contains(event):
            if not getattr(event, 'state', 0) & (0x1 | 0x4):
                self._clear_timeline_selection()
            if self._timeline_marker_press(event): return 'break'
            self._stop_transport_hold()
            self._timeline_drag_geometry = None
            self._cancel_timeline_redraw()
            self.timeline.focus_set()
            self.timeline_drag = self.subtitle_drag = None
            self._timeline_scrubbing = True
            self._begin_preview_epoch()
            self._capture_timeline_geometry()
            self.seek(self._timeline_pointer_time(event.x))
            return 'break'
        if self._begin_timeline_divider_drag(event): return 'break'
        if self._timeline_marker_press(event): return 'break'
        if self._timeline_audio_press(event): return 'break'
        if self._keyboard_blade_press(event): return 'break'
        if self._begin_video_stack_drag(event): return
        if self._selection_press(event): return
        self._stop_transport_hold()
        self._timeline_scrubbing = False
        self._timeline_drag_geometry = None
        self._cancel_timeline_redraw()
        self.timeline.focus_set()
        x = self.timeline.canvasx(event.x)
        self.timeline_drag = None
        self.subtitle_drag = None
        self.pause()
        ids = self.timeline.find_overlapping(x-self._px(2), self.timeline.canvasy(event.y)-self._px(2), x+self._px(2), self.timeline.canvasy(event.y)+self._px(2))
        boundary_dragging = self._begin_program_boundary_drag(event)
        if boundary_dragging == 'blocked': return
        cue_id = next((self.timeline_subtitle_items[i] for i in reversed(ids) if i in self.timeline_subtitle_items), None)
        if cue_id:
            cue = next(cue for cue in self.project.subtitles.cues if cue.id == cue_id)
            self.subtitle_drag = (cue.id, x, cue.start, cue.end, False)
            self.show_creative('subtitle')
            self.creative_panel.subtitle_tree.selection_set(cue.id)
            self.creative_panel.subtitle_tree.see(cue.id)
            self.creative_panel._load_cue()
            self._capture_timeline_geometry()
            return
        transition_time = next((self.timeline_transition_items[i] for i in reversed(ids)
                                if i in self.timeline_transition_items), None)
        if boundary_dragging and transition_time is None: return
        if transition_time is not None:
            selected = next((i for i, cut in enumerate(self.project.cuts)
                             if math.floor(cut.time*self.project.fps+.5) == math.floor(transition_time*self.project.fps+.5)), None)
            if selected is not None:
                self.cut_tree.selection_set(str(selected))
                self._select_cut()
                self.creative_panel_refresh()
            self.show_creative('transition')
            label = next((label for label, value in self.creative_panel._cut_choices.items()
                          if math.floor(value*self.project.fps+.5) == math.floor(transition_time*self.project.fps+.5)), None)
            if label:
                self.creative_panel.transition_cut_var.set(label)
                self.creative_panel._load_transition()
            return
        clip_id = next((self.timeline_clip_items[i] for i in reversed(ids) if i in self.timeline_clip_items), None)
        selected_range = next((self.timeline_program_items[i] for i in reversed(ids)
                               if i in self.timeline_program_items), None)
        clicked = self._timeline_pointer_time(event.x)
        if selected_range:
            self.select_program_range(*selected_range, seek=False)
        elif clip_id:
            span = self._program_span_at(clicked)
            if span: self.select_program_range(span.start, span.end, seek=False)
        else:
            self.selected_program_range = None
            self.creative_panel_refresh()
            self.draw_timeline()
        if clip_id:
            clip = next(c for c in self.project.clips if c.id == clip_id)
            self.media_tree.selection_set(clip.id)
            self.timeline_drag = (clip.id, x, clip.start, False)
            self._capture_timeline_geometry()

    def timeline_context(self, event):
        if not self._available(): return
        if self._timeline_marker_context(event): return
        if self._timeline_audio_context(event): return
        if self._video_stack_context(event): return
        if self._selection_context(event): return
        self.timeline.focus_set(); self.pause()
        x, y = self.timeline.canvasx(event.x), self.timeline.canvasy(event.y)
        ids = self.timeline.find_overlapping(x-1, y-1, x+1, y+1)
        selected = next((self.timeline_program_items[item] for item in reversed(ids)
                         if item in self.timeline_program_items), None)
        position = self._timeline_origin() + (x-self._timeline_left)/self._timeline_scale()
        if selected is None:
            span = self._program_span_at(position)
            selected = (span.start, span.end) if span else None
        if selected is None:
            self._show_timeline_insert_menu(event)
            return
        if ('program', selected) not in self._timeline_selection:
            self._set_timeline_selection({('program', selected)}, redraw=False)
        else:
            self._set_timeline_selection({key for key in self._timeline_selection if key[0] == 'program'}, redraw=False)
        self.select_program_range(*selected, seek=False)
        menu = tk.Menu(self, tearoff=False, bg=PANEL, fg=INK, activebackground='#3c5263')
        cameras = tk.Menu(menu, tearoff=False, bg=PANEL, fg=INK)
        for camera in self._media_camera_order():
            label = self._label_camera(camera) if camera in self.project.camera_names else f'机位 {camera_number(self.project, camera)}'
            cameras.add_command(label=label, command=lambda value=camera: self.switch(value))
        menu.add_cascade(label='切换机位', menu=cameras)
        self._append_multicam_view_menu(menu)
        menu.add_command(label='进入调色界面', command=lambda: self.show_creative('color'))
        image_stabilization = tk.Menu(menu, tearoff=False, bg=PANEL, fg=INK)
        image_stabilization.add_command(label='自动配置…',command=lambda:open_image_stabilization_dialog(self,mode='auto'))
        image_stabilization.add_command(label='手动参数…',command=lambda:open_image_stabilization_dialog(self,mode='manual'))
        image_stabilization.add_command(label='移除所选片段防抖',command=self.remove_selected_stabilization,
                                       state='normal' if self.get_selected_stabilization() else 'disabled')
        menu.add_cascade(label='画面防抖（无需陀螺仪）',menu=image_stabilization)
        stabilization = tk.Menu(menu, tearoff=False, bg=PANEL, fg=INK)
        stabilization.add_command(label='自动配置…', command=lambda: open_stabilization_dialog(self,mode='auto'))
        stabilization.add_command(label='手动参数…', command=lambda: open_stabilization_dialog(self,mode='manual'))
        stabilization.add_command(label='移除所选片段防抖', command=self.remove_selected_stabilization,
                                  state='normal' if self.get_selected_stabilization() else 'disabled')
        menu.add_cascade(label='Gyroflow 防抖', menu=stabilization)
        transitions = tk.Menu(menu, tearoff=False, bg=PANEL, fg=INK)
        for title, kind in [('叠化','fade'), ('溶解','dissolve'), ('向左擦除','wipeleft'),
                ('向右擦除','wiperight'), ('向左滑动','slideleft'), ('向右滑动','slideright'),
                ('圆形展开','circleopen'), ('黑场','fadeblack'), ('白场','fadewhite')]:
            transitions.add_command(label=title, command=lambda value=kind: self.add_transition_at_selected_end(value))
        enabled = selected[1] < self.project.duration - 1/self.project.fps/2
        menu.add_cascade(label='在片段末尾添加转场', menu=transitions,
                         state='normal' if enabled else 'disabled')
        self._append_timeline_insert_menu(menu, event)
        self.timeline_context_menu = menu
        try: menu.tk_popup(event.x_root, event.y_root)
        finally: menu.grab_release()

    def timeline_motion(self, event):
        if self._move_timeline_divider_drag(event): return 'break'
        if self._selection_motion(event): return
        if self._move_video_stack_drag(event): return
        if self._timeline_scrubbing:
            self.seek(self._timeline_pointer_time(event.x))
            return
        if self._move_program_boundary_drag(event): return
        if self.subtitle_drag:
            cue_id, x, start, end, changed = self.subtitle_drag
            delta = self.timeline.canvasx(event.x) - x
            if abs(delta) < self._px(3) and not changed: return
            if not changed: self._remember()
            cue = next(cue for cue in self.project.subtitles.cues if cue.id == cue_id)
            new_start = max(0, round((start + delta/self._timeline_scale()) * self.project.fps) / self.project.fps)
            cue.start, cue.end = new_start, new_start + end - start
            self.subtitle_drag = (cue_id, x, start, end, True)
            self._queue_timeline_redraw()
            return
        if not self.timeline_drag: return
        clip_id, x, start, changed = self.timeline_drag
        delta = self.timeline.canvasx(event.x)-x
        if abs(delta) < 4 and not changed: return
        clip = next(c for c in self.project.clips if c.id == clip_id)
        value = round((start+delta/self._timeline_scale())*self.project.fps)/self.project.fps
        if not self._can_move_timeline_clip(clip, value): return
        if not changed: self._remember()
        self._move_clip_start(clip, value)
        self.offset_var.set(format_signed_time(clip.start))
        self.timeline_drag = (clip_id, x, start, True)
        self._queue_timeline_redraw()

    def timeline_release(self, event):
        if self._end_timeline_divider_drag(): return 'break'
        if self._finish_selection_gesture(): return
        if self._end_video_stack_drag(): return
        if self._timeline_scrubbing:
            self._finish_preview_epoch(seek=False)
            self.seek(self._timeline_origin()+(self.timeline.canvasx(event.x)-self._timeline_left)/self._timeline_scale())
            self._timeline_scrubbing = False
            self._timeline_drag_geometry = None
            return
        if self._end_program_boundary_drag(): return
        self._cancel_timeline_redraw()
        self._timeline_drag_geometry = None
        if self.subtitle_drag:
            if self.subtitle_drag[-1]: self._refresh()
            self.subtitle_drag = None
            return
        if self.timeline_drag and self.timeline_drag[3]:
            clip_id = self.timeline_drag[0]
            self._refresh()
            clip = next((clip for clip in self.project.clips if clip.id == clip_id), None)
            if clip is not None: self._reveal_timeline_clip(clip)
        self.timeline_drag = None

    def _poll_player(self, *, reschedule=True):
        if not self.alive: return
        self._check_preview_foreground()
        latest_state = None
        try:
            for _ in range(2048):
                kind, payload = self.player_queue.get_nowait()
                if self._handle_stack_preview_job(kind, payload): continue
                if kind == 'state':
                    if self.player is not None and self._accept_transport_state(payload):
                        latest_state = payload
                elif kind == 'program_swap':
                    if self.player is not None and self._show_program_view(payload):
                        self.update_idletasks()
                        self.player.submit('program_swap_ack', window=payload)
                elif kind=='gpu_live_state':
                    if self.player is not None:self._set_gpu_live_state(payload)
                elif kind=='comparison_swap':
                    if self.player is not None and self._show_comparison_view(payload):
                        self.update_idletasks();self.player.submit('comparison_swap_ack',window=payload)
                elif kind=='camera_windows_released':self._release_camera_frames(payload)
                elif kind == 'playback_metrics': self._apply_playback_metrics(payload)
                elif kind == 'status': self.status.set(str(payload))
                elif kind == 'error':
                    self.status.set(str(payload)); self.app._log('多机位监看：' + str(payload))
        except queue.Empty: pass
        if latest_state is not None:
            payload = latest_state
            previous_time = self.current
            self.current = float(payload['time']); self.playing = bool(payload['playing'])
            self._follow_color_playhead()
            if self.playing or self.current != previous_time:
                self._follow_timeline_playhead()
            camera = payload.get('camera')
            if self.project.video_stack_enabled and self._displayed_camera in self.project.cameras:
                camera = self._displayed_camera
            self._sync_comparison_state(payload)
            self._set_program_label(camera,payload.get('preview',False))
            self._highlight(camera); self._show_time(); self.draw_playhead()
        if reschedule: self._player_poll_after = self.after(8, self._poll_player)

    def _poll(self):
        if not self.alive: return
        self._poll_player(reschedule=False)
        try:
            for _ in range(64):
                kind, payload = self.jobs.get_nowait()
                if self._handle_interchange_job(kind, payload): continue
                if self._handle_camera_import_job(kind, payload): continue
                if self._handle_timeline_merge_job(kind, payload): continue
                if self._handle_transport_job(kind, payload): continue
                if kind.startswith('quick_proxy_') and self._handle_quick_proxy_job(kind, payload): continue
                if self._handle_library_job(kind, payload): continue
                if kind == 'timeline_import_ready':
                    self._finish_timeline_import(payload); continue
                if kind == 'timeline_import_error':
                    self.busy = False; self.app._set_working(False)
                    text, cancelled = payload
                    self.status.set('已取消拖入，保留原时间线。' if cancelled else text)
                    if not cancelled: messagebox.showerror('拖入时间线', text, parent=self)
                    continue
                if kind == 'proxy_validated':
                    self.busy = False
                    project, identifier, source, path = payload
                    clip = next((clip for clip in self.project.clips if clip.id == identifier and clip.path == source), None)
                    if project is self.project and clip is not None:
                        self._remember(); clip.proxy_path = path; clip.proxy_disabled = False
                        register_proxy(source, path)
                        self._configure_player()
                        self.status.set('代理检查通过，已用于预览；最终导出仍读取原片。')
                    continue
                if kind == 'proxy_validation_error':
                    self.busy = False; self.status.set(str(payload))
                    messagebox.showerror('预览代理不匹配', str(payload), parent=self)
                    continue
                if kind=='batch_import_progress':
                    percent,text=payload
                    self.status.set(text);self.app.progress_var.set(percent);self.app.progress_text_var.set(text);continue
                if kind=='batch_import_error':
                    self.busy=False;self.app._set_working(False)
                    text,cancelled=payload;self.status.set('已取消批量导入，保留原工程' if cancelled else text)
                    if not cancelled:messagebox.showerror('导入机位',text,parent=self)
                    continue
                if kind=='batch_import_ready':
                    self._handle_camera_import_job('camera_import_ready',
                        (self.project, [(camera, [info]) for camera, info in payload]))
                    continue
                if kind.startswith('camera_match_'):
                    self._handle_camera_match_job(kind,payload);continue
                if kind.startswith('auto_color_'):
                    self._handle_auto_color_job(kind,payload);continue
                if kind == 'camera_metadata':
                    identifier,path,metadata = payload
                    changed=False
                    for clip in (clip for clip in self.project.clips if clip.path==path):
                        changed=changed or (clip.camera_make,clip.camera_model)!=(metadata.make,metadata.model)
                        clip.camera_make,clip.camera_model,clip.camera_metadata_source=metadata.make,metadata.model,metadata.source
                    if changed: self._mark_dirty()
                    self._refresh_camera_labels();self.draw_timeline()
                    continue
                if kind.startswith('stabilization_') or kind in ('transition_ready','transition_error'):
                    self._handle_effect_job(kind,payload)
                    continue
                if kind == 'import':
                    self.busy = False; self._remember()
                    camera, infos = payload
                    start = max((c.start+c.duration for c in self.project.clips if c.camera == camera), default=0)
                    first = not self.project.clips
                    for info in infos:
                        self.project.clips.append(CameraClip(uuid.uuid4().hex, camera, info.path, start, info.duration,has_alpha=bool(getattr(info,'has_alpha',False)),has_audio=info.has_audio))
                        start += info.duration
                        if not self.project.master_audio and info.has_audio:
                            self.project.master_audio = info.path; self.project.master_duration = info.duration; self.project.master_audio_clips = []
                    if first and not self.project.project_settings:
                        self.project.fps = infos[0].fps or 30; self.fps_var.set(f'{self.project.fps:.8g}')
                    if not self.project.cuts: self.project.set_cut(0, camera)
                    self._refresh(); self.status.set(f'机位 {camera_number(self.project, camera)} 已导入 {len(infos)} 段；不同机位初始都从 00:00 开始，请同步。')
                elif kind == 'master':
                    self.busy = False; self._remember()
                    self.project.master_audio, self.project.master_duration = payload
                    self.project.master_audio_clips = []
                    self.project.alignment_reference_camera = None
                    self.sync_results.clear()
                    self._refresh(); self.status.set('已选择连续主音频。可自动同步全部或填写片段在主录音中的起点。')
                elif kind == 'aligned':
                    pairs, elapsed = payload
                    self._finish_alignment(pairs, elapsed)
                elif kind == 'sync_progress':
                    percent, phase = payload
                    self.app.progress_var.set(percent)
                    self.app.progress_text_var.set(f'同步并对齐 {percent:.1f}% · {phase}')
                    self.status.set(str(phase))
                elif kind in {'align_cancelled', 'align_error'}:
                    self.busy = False; self.sync_running = False
                    self.app._set_working(False)
                    message = '已取消同步，保留原时间线' if kind == 'align_cancelled' else str(payload)
                    self.status.set(message); self.app.progress_text_var.set(message)
                    if kind == 'align_error' and not self._record_alignment_failure(message):
                        messagebox.showerror('同步并对齐', message, parent=self)
                elif kind == 'error':
                    self.busy = False; self.status.set(str(payload)); messagebox.showerror('多机位', str(payload), parent=self)
                elif kind == 'preview_progress':
                    percent, phase = payload
                    self.app.progress_var.set(percent)
                    self.app.progress_text_var.set(f'效果预览 {percent:.1f}% · {phase}')
                elif kind == 'preview_ready':
                    self.busy = False; self.app._set_working(False)
                    path, start, end = payload
                    self.app.progress_var.set(100)
                    self.app.progress_text_var.set('效果预览已生成')
                    self.start_monitors()
                    if self.player:
                        self.player.submit('render_preview', path=path, start=start, end=end, play=True)
                    self.status.set('正在播放当前播放头附近的效果预览；修改参数后可再次生成。')
                elif kind == 'preview_error':
                    self.busy = False; self.app._set_working(False)
                    text, cancelled = payload
                    self.app.progress_text_var.set('已取消效果预览' if cancelled else '效果预览失败')
                    self.status.set(self.app.progress_text_var.get())
                    if not cancelled: messagebox.showerror('效果预览', text, parent=self)
                elif kind == 'export_metrics':
                    self._update_export_metrics(payload)
                elif kind == 'progress' and not self._export_last_snapshot:
                    percent, phase = payload
                    self.app.progress_var.set(percent); self.app.progress_text_var.set(f'多机位 {percent:.1f}% · {phase}')
                    self.status.set(str(phase))
                elif kind == 'exported':
                    self.busy = False; self.app._set_working(False)
                    self.delivery_export_button.configure(state='normal')
                    snapshot = dict(self._export_last_snapshot)
                    if snapshot.get('stage') != 'done':
                        if self._export_started_at is not None:
                            snapshot['elapsed'] = time.monotonic() - self._export_started_at
                        snapshot.update(stage='done', phase='导出完成', progress_percent=100,
                                        eta=0, fps=0, speed=0, active_workers=0)
                    self._update_export_metrics(snapshot)
                    self.status.set('已导出：' + str(payload))
                    self.app._log('多机位导出完成：'+str(payload))
                    if not self.finishing_workspace.complete():
                        messagebox.showinfo('多机位导出完成', str(payload), parent=self)
                elif kind == 'export_error':
                    self.busy = False; self.app._set_working(False)
                    self.delivery_export_button.configure(state='normal')
                    text, cancelled = payload
                    snapshot = dict(self._export_last_snapshot)
                    if self._export_started_at is not None:
                        snapshot['elapsed'] = time.monotonic() - self._export_started_at
                    snapshot.update(stage='cancelled' if cancelled else 'failed',
                                    phase='已取消导出' if cancelled else '导出失败',
                                    eta=None, active_workers=0)
                    self._update_export_metrics(snapshot)
                    self.status.set('已取消导出' if cancelled else text)
                    self.app._log('多机位导出：' + text)
                    self.finishing_workspace.complete(error=text, cancelled=cancelled)
                    if not cancelled: messagebox.showerror('多机位导出', text, parent=self)
        except queue.Empty: pass
        self.after(80, self._poll)

    def help(self):
        messagebox.showinfo('多机位剪辑操作',
            '1. “导入素材”只添加到素材库；从素材库拖到时间线，可指定起点与轨道。\n'
            '   同机位分段可选择机位后用“追加到机位”，明确将素材接到该机位末尾。\n'
            '   监看上方可分别选择1–6行、1–6列，最多6×6同屏36机位；超过当前网格容量时左右箭头翻页。\n'
            '   数字键1–9选择本页前九格，第10–36格请点击机位按钮；网格设置随工作区布局保存。\n'
            '2. “对齐参考”可选主音频或单个机位；参考机位固定，其他机位按其波形对齐。\n'
            '   时间线上 Ctrl/Shift 多选或框选视频，右键“自动对齐所选视频”，选择主音频或选中的音频作参考。\n'
            '   只移动所选视频；参考音频及其绑定视频保持原位，未选中素材不参与移动，可 Ctrl+Z 撤销。\n'
            '   无法自动确认的片段会列入“未对齐片段”列表，显示机位、文件名和原因；可定位到所选片段检查。\n'
            '   机位列表上方“全部收起 / 全部展开”可一键折叠全部机位；刷新后保留展开状态。\n'
            '   也可手填片段起点、拖动时间线或逐帧微调；同步不会替换主音频。\n'
            '3. 点“监看”，勾选“记录”，播放时按 1–9 或点击机位按钮记录切点。\n'
            '4. 空格播放/暂停；←/→按下立即暂停并移动一帧，长按连续倒放/正放，松开保持暂停。\n'
            f'   拖动时间线标尺可连续定位；定位播放头后按 {self._split_shortcut_label()} 切开，切点会保留。\n'
            '   鼠标移到节目轨两段之间，出现左右箭头后按住拖动可移动切点；Esc 取消，Ctrl+Z 撤销。\n'
            '   切点按帧对齐，两侧至少保留一帧；已有转场会随切点移动并限制可移动范围。\n'
            '   相邻片段已应用库叠加特效时，请先移除特效，调整切点后重新应用。\n'
            '5. 左键选中“节目”轨道片段后，按 1–9 仅切换所选片段的机位；Esc 取消选中。\n'
            '   Delete / Backspace 删除选中片段；Ctrl+Z 撤销，素材库原片保留。\n'
            '6. 右键片段可切换机位、进入调色，或在片段末尾与后续片段之间添加转场。\n'
            '   “Gyroflow 防抖”提供自动配置/手动参数，检测并处理所选片段，完成后预览与导出共用。\n'
            '   无陀螺仪或识别失败时，可用“画面防抖”：通过图像特征分析运动，提供平滑、锁定机位和自动裁边。\n'
            '   转场会在后台自动准备，看到“转场预览已就绪”后普通回放即可查看。\n'
            '7. “调色”页默认只调Cut后选中的片段，并自动识别该片段机位；拖动色轮实时显示。\n'
            '   “曲线”内页支持主亮度/R/G/B，点击加点、拖动调节、右键删除内部点。\n'
            '   “自动 / 人像”提供自然微亮和人物美白预设，默认曝光偏好+0.25EV，分析后一次应用可撤销。\n'
            '   人物预设会纠正偏黄；“色彩参考”可选择其他机位，让白衣与肤色向它靠近。\n'
            '   防抖完成后，右上“防抖对比”可同屏查看原片完整视野与防抖裁切后的画面。\n'
            '   只有显式切换到“整机位”或“全片”目标时才会调其他片段。\n'
            f'   拖动选区两端可修改范围；该页同样支持 {self._split_shortcut_label()} 和逐帧。点“返回剪辑”恢复时间线。\n'
            f'8. Ctrl+Z 撤销、{self._keyboard_shortcut_label("redo")} 重做。保存工程后，点“交付 / 导出”设置并导出。\n\n'
            '“布局 → 键位选择”可选择当前、DaVinci Resolve 或 Premiere Pro；子菜单中的“键位表”可查看本软件支持的映射。\n'
            '媒体库素材可直接拖入时间线；中键可上下左右拖动画布，滚轮横移，Alt+滚轮逐帧移动播放头，Ctrl+滚轮围绕播放头缩放。\n'
            '时间线右键可插入空视频轨道或在此时间插入素材；上方轨道叠在画面顶层。\n'
            '素材支持上下换轨；Ctrl+左键多选，右键合并会按先后首尾接齐，保留第一段起点。\n'
            '合并文件保存在软件目录 merged_media，原片保留；Ctrl+Z 可撤销时间线替换。\n'
            '空格暂停保留解码缓存，继续播放复用；需要主动回收时再点“释放缓存”。\n'
            '透明视频拖入时间线会自动作为顶层叠加；“图层叠加”开启时，上方轨道位于画面上层。\n'
            '拖左侧V轨道标签可上下调序，右键轨道可置顶、下移或隐藏；关闭叠加仍保留原节目切点。\n'
            '叠加模式中，点击监看机位或按数字键只选择该图层的调色目标，不改变合成顺序或写入切点。\n'
            'A0 为连续主音频，A1/A2 等对应同号视频轨原声；点击轨头“出声/静音”选择监听和导出音轨。\n'
            '点击“机位原声”整体展开/收起非主音频；轨头三角可逐轨折叠；上下拖动音视频之间的分隔条调整轨道大小。\n'
            '音频波形在后台读取；M 在播放头处添加标记，右键标记可删除，标记与音轨状态随工程保存。\n'
            '中文输入法下可直接使用剪辑快捷键；文字输入框保留正常中文输入。所选机位停机处输出黑场。\n'
            '“吸附”使时间线光标吸附到附近素材边缘和节目切点；“链接”控制视频与机位原声是否一起选择、移动和删除。\n'
            '机位编号旁显示已代理、部分代理、未代理或代理丢失；关闭代理预览仍保留代理标志。\n'
            '8K 多路监看可点“一键1080p代理”，生成期间仍可剪辑；完成后自动挂载，导出始终读取原片。\n'
            '“释放缓存”回收播放器解码缓存与显存，再加载当前帧并保持暂停，不删除素材或代理。\n'
            '工作面板可拖动标签/标题浮出窗口，拖到其他面板中心合并标签，四边分割停靠。\n'
            '“布局 → 面板 → 浮动整个标签组”可一起移出整组；拖动组标题整体停靠，拖动单个标签只移动该页。\n'
            '浮动窗口关闭会停靠回工作区；“布局”菜单可显示、浮动、隐藏面板或恢复默认布局。\n'
            '布局独立保存，不改变工程剪辑；精细调色面板也可独立浮动。\n'
            '自动同步调整恒定偏移；长录制时钟漂移需分段检查并单独微调。', parent=self)

    def request_close(self):
        return self._confirm_discard()

    def close(self):
        audio = vars(self).get('audio_workspace')
        if audio is not None: audio.close()
        self._close_timeline_view()
        crop_editor = vars(self).get('_crop_editor')
        if crop_editor is not None: crop_editor.close()
        service = vars(self).get("_exposure_service")
        if service is not None: service.close()
        self._finish_selection_gesture(cancel=True)
        self.alive = False
        self._close_prerender()
        self._close_timeline_audio()
        if getattr(self, '_player_poll_after', None) is not None:
            self.after_cancel(self._player_poll_after)
            self._player_poll_after = None
        self._end_video_stack_drag(cancel=True)
        self._close_preview_focus()
        self._close_camera_list_ui()
        self._close_camera_drop()
        self._close_workspace_docking()
        self._close_transport_controls()
        self._close_quick_proxy()
        self._library_apply_token = getattr(self, '_library_apply_token', 0) + 1
        self._close_timeline_interaction()
        self._close_auto_color()
        self._camera_metadata_cancel.set()
        self._close_effects()
        if self.sync_running or self.busy: self.app.cancel_event.set()
        player, worker, folder = self.player, self._creative_preview_worker, self._creative_preview_folder
        self.stop_monitors()
        if folder is not None:
            def cleanup():
                if worker is not None and worker.is_alive(): worker.join(timeout=20)
                if worker is not None and worker.is_alive(): return
                if player is not None: player.wait_closed(timeout=10)
                resolved = folder.resolve()
                if (resolved.parent == cache_dir('previews/effects').resolve()
                        and resolved.name.startswith('okk_effect_preview_')):
                    shutil.rmtree(resolved, ignore_errors=True)
            threading.Thread(target=cleanup, daemon=False).start()

    def prepare_delivery_export(self):
        """Validate and snapshot the settings currently shown on Deliver."""
        if not self.project.clips:
            raise ValueError('请先在多机位剪辑页导入视频素材。')
        if not self.output_var.get(): self.choose_output()
        output = self.output_var.get().strip()
        if not output: return None
        project = copy.deepcopy(self.project)
        project.range_start, project.range_end, project.fps = self._read_range()
        project.validate()
        project.segments()
        settings, suffix = make_delivery_settings(self)
        output = self.output_var.get().strip()
        if Path(output).suffix.lower() != suffix:
            output = str(Path(output).with_suffix(suffix))
            self.output_var.set(output)
        from hardware_encoders import available_codecs
        if settings.codec not in available_codecs(self.app.caps):
            raise ValueError('当前编码器不可用；请等待 GPU 检测完成或选择 CPU 兼容模式。')
        if not self.app.caps.ffmpeg_path or not self.app.caps.ffprobe_path:
            raise ValueError('未找到 FFmpeg / ffprobe。')
        return project, settings, output

