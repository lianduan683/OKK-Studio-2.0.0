"""Programme Delete removes selected media ranges and leaves clock gaps."""
from copy import deepcopy
import unittest

from multicam_core import CameraClip, Cut, MulticamProject
from program_edits import program_media_spans
from timeline_audio import source_audio_clips
from timeline_edits import delete_program_clips


class ProgramDeleteTests(unittest.TestCase):
    def project(self, *, linked=True):
        return MulticamProject(clips=[CameraClip('a', 1, 'a.mov', 0., 10.),
                                      CameraClip('b', 2, 'b.mov', 0., 10.)],
                               cuts=[Cut(0., 1)], edit_points=[3., 7.],
                               timeline_link_enabled=linked)

    def test_middle_delete_removes_only_selected_camera_picture_and_linked_sound(self):
        value = self.project()
        delete_program_clips(value, [(3., 7.)])
        self.assertEqual([(c.start, c.end, c.source_in) for c in value.clips if c.camera == 1],
                         [(0., 3., 0.), (7., 10., 7.)])
        self.assertEqual([(c.start, c.end) for c in value.clips if c.camera == 2], [(0., 10.)])
        self.assertIsNone(value.media_at(1, 5.))
        self.assertEqual(value.media_at(1, 8.)[1], 8.)
        self.assertFalse(any(c.start <= 5. < c.end for c in source_audio_clips(value) if c.camera == 1))
        self.assertEqual([(s.start, s.end) for s in program_media_spans(value)], [(0., 3.), (7., 10.)])
        self.assertEqual([s.path for s in value.segments()], ['a.mov', None, 'a.mov'])
        self.assertEqual(sorted(s.path for s in value.source_media), ['a.mov', 'b.mov'])
        value.validate()

    def test_unlinked_delete_preserves_continuous_source_sound(self):
        value = self.project(linked=False)
        delete_program_clips(value, [(3., 7.)])
        self.assertTrue(any(c.start <= 5. < c.end for c in source_audio_clips(value) if c.camera == 1))
        self.assertIsNone(value.media_at(1, 5.))

    def test_deleting_entire_camera_keeps_black_gap_and_round_trips(self):
        value = self.project()
        value.cuts = []  # Default programme camera is also preserved explicitly.
        delete_program_clips(value, [(0., 10.)])
        self.assertEqual(value.cameras, [2])
        self.assertEqual(value.timeline_empty_tracks, [1])
        self.assertEqual(value.camera_at(5.), 1)
        self.assertFalse(program_media_spans(value))
        self.assertTrue(all(segment.path is None for segment in value.segments()))
        loaded = MulticamProject.from_payload(value.to_payload('.'), '.')
        self.assertEqual(loaded.camera_at(5.), 1)
        self.assertTrue(all(segment.path is None for segment in loaded.segments()))
        self.assertEqual(len(loaded.source_media), 2)

    def test_stack_delete_removes_only_visible_layers_in_selected_range(self):
        value = self.project()
        value.video_stack_enabled = True
        delete_program_clips(value, [(3., 7.)])
        self.assertTrue(all(not (c.start <= 5. < c.end) for c in value.clips))
        self.assertEqual([(s.start, s.end) for s in program_media_spans(value)], [(0., 3.), (7., 10.)])

    def test_explicit_source_and_programme_selection_are_deleted_atomically(self):
        value = self.project()
        delete_program_clips(value, [(3., 7.)], {'a'})
        self.assertEqual([c.id for c in value.clips], ['b'])
        self.assertEqual(value.camera_at(5.), 1)
        before = deepcopy(value)
        with self.assertRaises(ValueError): delete_program_clips(value, [(1., 30.)], {'b'})
        self.assertEqual(value, before)

    def test_disabled_media_remains_visible_until_deleted(self):
        value = self.project()
        value.clips[0].enabled = False
        self.assertEqual([(s.start, s.end) for s in program_media_spans(value)],
                         [(0., 3.), (3., 7.), (7., 10.)])


if __name__ == '__main__':
    unittest.main()
