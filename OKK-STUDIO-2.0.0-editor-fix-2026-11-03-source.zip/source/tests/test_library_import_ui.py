"""Library imports remain independent until an original is dropped on the timeline."""
from copy import deepcopy
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from exporter_core import MediaInfo
from multicam_core import MulticamProject
from source_media import SOURCE_PREFIX
from tests import test_timeline_drag_merge as fixture


class LibraryImportTests(unittest.TestCase):
    setUp = fixture.TimelineDropTests.setUp
    tearDown = fixture.TimelineDropTests.tearDown

    def import_library(self, infos):
        workspace = self.workspace
        workspace._handle_camera_import_job('camera_import_ready',
            (workspace.project, [(3, infos)]))
        self.assertEqual(self.errors, [])

    def test_import_does_not_edit_existing_timeline_or_playhead_and_is_undoable(self):
        workspace = self.workspace
        workspace.seek(4.)
        before = deepcopy(workspace.project)
        current = workspace.current
        self.import_library([MediaInfo(path='new.mov', duration=20, fps=24, has_audio=True)])
        expected = deepcopy(before)
        expected.source_media = deepcopy(workspace.project.source_media)
        self.assertEqual(workspace.project, expected)
        self.assertEqual(workspace.current, current)
        added = workspace.project.source_media[-1]
        self.assertEqual(workspace.media_tree.selection(), (SOURCE_PREFIX+added.id,))
        self.assertEqual(workspace.project.source_media[-1].path, 'new.mov')
        self.assertEqual(len(workspace.undo_stack), 1)
        after = deepcopy(workspace.project)
        workspace.undo()
        self.assertEqual(workspace.project, before)
        workspace.redo()
        self.assertEqual(workspace.project, after)

    def test_library_only_project_roundtrip_and_real_drag_to_empty_timeline(self):
        workspace = self.workspace
        workspace.project = MulticamProject()
        workspace._refresh(reconfigure=False)
        with tempfile.TemporaryDirectory() as folder:
            original = Path(folder)/'original.mov'
            original.write_bytes(b'original bytes')
            info = MediaInfo(path=str(original), duration=12, width=1920, height=1080,
                             fps=24, has_audio=True)
            self.import_library([info])
            self.assertEqual(workspace.project.clips, [])
            self.assertEqual(workspace.project.cuts, [])
            self.assertEqual(workspace.project.master_audio, '')
            self.assertEqual(workspace.project.fps, 30)
            saved = Path(folder)/'library-only.rtxproj'
            workspace.project.save(saved)
            workspace.project = MulticamProject.load(saved)
            workspace._refresh(reconfigure=False)
            before_drop = deepcopy(workspace.project)
            # Give the requested frame enough screen pixels for a precise
            # mouse drop, just as a user zooms in before a frame-level edit.
            workspace.zoom = 4.
            workspace.draw_timeline()
            row = SOURCE_PREFIX+workspace.project.source_media[0].id
            tree = workspace.media_tree
            tree.see(row)
            self.root.update_idletasks()
            x, y, width, height = tree.bbox(row, '#0')
            press = SimpleNamespace(x=x+25, y=y+height/2,
                x_root=tree.winfo_rootx()+x+25, y_root=tree.winfo_rooty()+y+height/2)
            workspace._media_drag_press(press)
            canvas = workspace.timeline
            target = SimpleNamespace(
                x_root=canvas.winfo_rootx()+workspace._timeline_x(7.)-canvas.canvasx(0),
                y_root=canvas.winfo_rooty()+min(60, canvas.winfo_height()/2))
            self.assertEqual(workspace._timeline_drop_position(target.x_root, target.y_root)[0], 7.)
            self.assertEqual(workspace._media_drag_motion(target), 'break')
            self.assertTrue(canvas.find_withtag('media-drop'))
            with patch('timeline_interaction.batch_import', return_value=[(1, info)]):
                workspace._media_drag_release(target)
                kind, payload = workspace.jobs.get(timeout=5)
                self.assertEqual(kind, 'timeline_import_ready')
                workspace._finish_timeline_import(payload)
            inserted = workspace.project.clips[0]
            self.assertEqual((inserted.path, inserted.start, inserted.duration), (str(original), 7., 12))
            self.assertEqual(workspace.project.fps, 24)
            self.assertEqual(workspace.project.master_audio, '')
            self.assertTrue(inserted.has_audio)
            self.assertNotEqual(inserted.id, workspace.project.source_media[0].id)
            self.assertTrue(tree.exists(row))
            self.assertEqual(original.read_bytes(), b'original bytes')
            workspace.undo()
            self.assertEqual(workspace.project, before_drop)
            workspace.redo()
            self.assertEqual(workspace.project.clips[0].id, inserted.id)
            self.assertEqual(self.errors, [])

    def test_duplicate_import_keeps_one_original_and_no_extra_undo(self):
        workspace = self.workspace
        info = MediaInfo(path='new.mov', duration=12, fps=24, has_audio=True)
        self.import_library([info, info])
        before = deepcopy(workspace.project)
        count = len(workspace.undo_stack)
        self.import_library([info])
        self.assertEqual(workspace.project, before)
        self.assertEqual(len(workspace.undo_stack), count)
        self.assertEqual(sum(c.path == 'new.mov' for c in workspace.project.source_media), 1)

    def test_add_camera_worker_imports_library_and_discards_replaced_project(self):
        workspace = self.workspace
        self.root._begin_shared_progress = Mock()
        info = MediaInfo(path='from-dialog.mov', duration=12, fps=24, has_audio=True)
        before = deepcopy(workspace.project)
        with patch('multicam_ui.filedialog.askopenfilenames', return_value=[info.path]), \
                patch('camera_import_ui.grouped_import', return_value=[(3, [info])]) as probe:
            workspace.add_camera()
            kind, payload = workspace.jobs.get(timeout=5)
            self.assertEqual(kind, 'camera_import_ready')
            self.assertIs(payload[0], workspace.project)
            self.assertTrue(payload[2])
            self.assertTrue(probe.call_args.kwargs['separate_files'])
            workspace._handle_camera_import_job(kind, payload)
        self.assertEqual(workspace.project.clips, before.clips)
        self.assertEqual(workspace.project.cuts, before.cuts)
        self.assertEqual(workspace.project.master_audio, before.master_audio)
        self.assertEqual(workspace.project.source_media[-1].path, info.path)
        with patch('multicam_ui.filedialog.askopenfilenames', return_value=['stale.mov']), \
                patch('camera_import_ui.grouped_import', return_value=[(4, [info])]):
            workspace.add_camera()
            kind, payload = workspace.jobs.get(timeout=5)
        workspace.project = MulticamProject()
        replacement = deepcopy(workspace.project)
        count = len(workspace.undo_stack)
        workspace._handle_camera_import_job(kind, payload)
        self.assertEqual(workspace.project, replacement)
        self.assertEqual(len(workspace.undo_stack), count)
        self.assertFalse(workspace.busy)
        self.assertFalse(self.root.working)
        self.assertEqual(self.errors, [])

    def test_first_drop_keeps_explicit_fps_and_zero_start_source_becomes_master(self):
        workspace = self.workspace
        from project_settings import DEFAULT_SETTINGS
        workspace.project = MulticamProject(project_settings=dict(DEFAULT_SETTINGS))
        workspace.project.fps = 25
        workspace._refresh(reconfigure=False)
        info = MediaInfo(path='audio-video.mov', duration=12, width=1920, height=1080,
                         fps=24, has_audio=True)
        workspace._finish_timeline_import((workspace.project, 0., None, [info]))
        self.assertEqual(workspace.project.fps, 25)
        self.assertEqual(workspace.project.master_audio, info.path)
        self.assertEqual(workspace.project.master_duration, 12)
        self.assertEqual(self.errors, [])


if __name__ == '__main__':
    unittest.main()
