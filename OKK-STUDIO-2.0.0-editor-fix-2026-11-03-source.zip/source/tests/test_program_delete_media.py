"""Verify programme deletion produces black gaps in the rendered movie."""
import unittest

from tests import test_multicam as media_tests
from multicam_core import CameraClip, Cut
from timeline_edits import delete_program_clips


class ProgramDeleteRenderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        media_tests.FFmpegMulticamTests.setUpClass()

    @classmethod
    def tearDownClass(cls):
        media_tests.FFmpegMulticamTests.tearDownClass()

    def test_deleting_entire_selected_camera_renders_gap_without_substituting_other_camera(self):
        media = media_tests.FFmpegMulticamTests()
        project = media.project()
        project.clips = [CameraClip('red', 1, str(media.red), 0, 3),
                         CameraClip('blue', 2, str(media.blue), 1, 1)]
        project.cuts = [Cut(0, 1), Cut(1, 2), Cut(2, 1)]
        delete_program_clips(project, [(1, 2)])
        output = media.render('deleted-programme.mp4', project)
        media.assert_frames(output, 96)
        for timestamp, color in [(0.5, (255, 0, 0)), (1.5, (0, 0, 0)),
                                 (2.5, (255, 0, 0)), (3.5, (0, 0, 0))]:
            media.assert_color(output, timestamp, color)
        media.assert_continuous_master(output, 0, 4)


if __name__ == '__main__':
    unittest.main()
