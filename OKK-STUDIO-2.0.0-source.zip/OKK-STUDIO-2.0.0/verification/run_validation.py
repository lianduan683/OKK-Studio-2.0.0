"""Run reproducible related tests in isolated groups; no user media are used."""
from pathlib import Path
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import os
import subprocess
import sys
import time
import unittest

GROUPS = {
    'editing': [
        'test_source_media_library', 'test_timeline_edits', 'test_timeline_split',
        'test_timeline_drag_merge', 'test_timeline_selection', 'test_camera_order_ui',
        'test_camera_list_ui', 'test_camera_rename', 'test_camera_folder_import',
        'test_batch_camera_ui', 'test_material_proxy_actions', 'test_audio_current_version',
        'test_project_open_compat', 'test_project_upgrade', 'test_studio_session', 'test_multicam'],
    'export': [
        'test_export_checkpoint', 'test_checkpoint_writer', 'test_export_resume_integration', 'test_simple_export_resume',
        'test_realtime_export_pipeline', 'test_export_parallel', 'test_gpu_lut_shader',
        'test_gpu_lut_cache', 'test_export_progress_ui', 'test_export_auto_ui',
        'test_timeline_viewport'],
    'retained_and_alpha': [
        'test_keyboard_profiles', 'test_audio_console', 'test_audio_mixer',
        'test_gpu_export_routing', 'test_gpu_route_scope_regressions', 'test_gpu_stack_composite', 'test_stack_gpu',
        'test_stack_gpu_pipeline', 'test_alpha_track_export_acceptance'],
}

def walk(suite):
    for test in suite:
        if isinstance(test, unittest.TestSuite):
            yield from walk(test)
        else:
            yield test

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--scratch-root', type=Path)
    parser.add_argument('--group', choices=tuple(GROUPS))
    args=parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    if args.group:
        sys.path[:0]=[str(args.source),str(args.source/'tests')]
        modules=['tests.'+name for name in GROUPS[args.group]]
        loaded=unittest.defaultTestLoader.loadTestsFromNames(modules)
        unique={}
        for test in walk(loaded):
            # Imported TestCase fixtures are helpers, not additional coverage.
            if test.__class__.__module__ in modules or test.__class__.__name__=='_FailedTest':
                unique.setdefault(test.id(),test)
        suite=unittest.TestSuite(unique.values())
        start=time.monotonic()
        result=unittest.TextTestRunner(verbosity=2).run(suite)
        summary=dict(group=args.group, modules=modules, tests=list(unique),
                     tests_run=result.testsRun, failures=len(result.failures), errors=len(result.errors),
                     skipped=[dict(test=str(test),reason=reason) for test,reason in result.skipped],
                     failed_tests=[str(test) for test,_ in result.failures+result.errors],
                     elapsed_seconds=round(time.monotonic()-start,3), success=result.wasSuccessful())
        (args.output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
        return 0 if result.wasSuccessful() else 1
    def execute(group):
        folder=args.output/group
        folder.mkdir()
        scratch=(args.scratch_root or args.output/'scratch')/str(tuple(GROUPS).index(group))
        for sub in ('temp','cache'):
            (scratch/sub).mkdir(parents=True,exist_ok=False)
        (folder/'alpha').mkdir()
        environment=dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONIOENCODING='utf-8',
            TEMP=str(scratch/'temp'),TMP=str(scratch/'temp'),OKK_CACHE_DIR=str(scratch/'cache'),
            OKK_ALPHA_ACCEPTANCE_DIR=str(folder/'alpha'),OKK_TEST_NVENC='1')
        command=[sys.executable,'-B',str(Path(__file__).resolve()),'--source',str(args.source),
                 '--output',str(folder),'--group',group]
        with (folder/'tests.log').open('w',encoding='utf-8') as log:
            completed=subprocess.run(command,env=environment,cwd=args.source,stdout=log,stderr=subprocess.STDOUT)
        path=folder/'summary.json'
        summary=json.loads(path.read_text('utf-8')) if path.exists() else dict(group=group,success=False,exit_code=completed.returncode)
        print(json.dumps({k:v for k,v in summary.items() if k not in ('modules','tests')},ensure_ascii=False),flush=True)
        return summary
    with ThreadPoolExecutor(max_workers=3) as executor:
        summaries=list(executor.map(execute,GROUPS))
    result=dict(groups=summaries,success=all(s['success'] for s in summaries),
                tests_run=sum(s.get('tests_run',0) for s in summaries),
                failures=sum(s.get('failures',0) for s in summaries),errors=sum(s.get('errors',0) for s in summaries))
    (args.output/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='groups'}),flush=True)
    return 0 if result['success'] else 1

if __name__=='__main__':
    raise SystemExit(main())
