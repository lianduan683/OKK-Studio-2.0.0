"""Audit this public source tree; report metadata only, never suspected secrets."""
from __future__ import annotations

import argparse
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
REPORTS = {"PUBLIC_SOURCE_MANIFEST.json", "PUBLIC_SOURCE_AUDIT.json"}
PATTERNS = {
    "user_home_path": re.compile(r'(?i)(?:[a-z]:[\\/]+Users[\\/]+[^\\/\s"\x27]+|/(?:Users|home)/[^/\s"\x27]+)'),
    "possible_credential": re.compile(r'gh[pousr]_[A-Za-z0-9_]{20,}|github_pat_[A-Za-z0-9_]{20,}|sk-[A-Za-z0-9_-]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|AKIA[A-Z0-9]{16}'),
}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write-manifest", action="store_true", help="Write relative-path inventory and audit summaries")
    args = parser.parse_args()
    entries, findings = [], []
    assets = json.loads((ROOT / "small_assets.json").read_text("utf-8"))
    approved = {"source/assets/" + item["path"]: item for item in assets}
    text_count = python_count = 0
    for path in sorted(ROOT.rglob("*")):
        if ".git" in path.relative_to(ROOT).parts:
            continue
        relative = path.relative_to(ROOT).as_posix()
        if relative in REPORTS:
            continue
        if path.is_symlink():
            findings.append({"file": relative, "kind": "symlink"})
            continue
        if not path.is_file():
            continue
        data = path.read_bytes()
        entries.append({"path": relative, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
        if any(part.lower() in {"__pycache__", "bin", "native_runtime", "effects_library", ".venv"}
               for part in path.relative_to(ROOT).parts) or path.suffix.lower() in {
                   ".exe", ".dll", ".pyd", ".pyc", ".zip", ".7z", ".mp4", ".mov", ".mkv", ".wav", ".log"}:
            findings.append({"file": relative, "kind": "excluded_distribution_content"})
        if path.suffix.lower() in {".png", ".ico"}:
            if relative not in approved:
                findings.append({"file": relative, "kind": "unapproved_image"})
            continue
        try:
            text = data.decode("utf-8-sig")
        except UnicodeDecodeError:
            findings.append({"file": relative, "kind": "unexpected_non_utf8_file"})
            continue
        text_count += 1
        for number, line in enumerate(text.splitlines(), 1):
            for kind, pattern in PATTERNS.items():
                if pattern.search(line):
                    findings.append({"file": relative, "line": number, "kind": kind})
        if path.suffix.lower() in {".py", ".spec"}:
            python_count += 1
            try:
                ast.parse(text, filename=relative)
            except SyntaxError as error:
                findings.append({"file": relative, "line": error.lineno, "kind": "python_syntax_error"})
    actual = {entry["path"]: entry for entry in entries if entry["path"].startswith("source/assets/")}
    if len(approved) != 16 or actual.keys() != approved.keys():
        findings.append({"kind": "ui_asset_whitelist_mismatch"})
    for name in actual.keys() & approved.keys():
        if actual[name]["bytes"] != approved[name]["size"] or actual[name]["sha256"] != approved[name]["sha256"]:
            findings.append({"file": name, "kind": "ui_asset_digest_mismatch"})
    audit = {"scope": "Public source tree, excluding Git internals and these two generated reports",
             "checked_at_utc": datetime.now(timezone.utc).isoformat(), "files": len(entries),
             "text_files": text_count, "python_and_spec_files": python_count,
             "approved_ui_assets": len(approved), "findings": findings,
             "limitations": "Pattern scan and syntax checks do not prove absence of all private data or validate runtime behavior."}
    if args.write_manifest:
        (ROOT / "PUBLIC_SOURCE_MANIFEST.json").write_text(
            json.dumps({"self_excluded_reports": sorted(REPORTS), "files": entries}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        (ROOT / "PUBLIC_SOURCE_AUDIT.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    return 1 if findings else 0


if __name__ == "__main__":
    raise SystemExit(main())
