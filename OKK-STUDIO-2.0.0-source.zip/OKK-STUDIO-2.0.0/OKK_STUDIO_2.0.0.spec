from pathlib import Path
from PyInstaller.utils.hooks import collect_all, copy_metadata
build = Path(SPECPATH)
root = build / 'source'
ped_data, ped_bins, ped_hidden = collect_all('pedalboard')
ped_metadata = copy_metadata('pedalboard')
dnd_data, dnd_binaries, dnd_hidden = collect_all('tkinterdnd2')
numpy_metadata = copy_metadata('numpy')
pillow_metadata = copy_metadata('Pillow')
otio_data, otio_binaries, otio_hidden = collect_all('opentimelineio')
aaf_data, aaf_binaries, aaf_hidden = collect_all('otio_aaf_adapter')
aaf2_data, aaf2_binaries, aaf2_hidden = collect_all('aaf2')
timeline_metadata = copy_metadata('otio-aaf-adapter')+copy_metadata('opentimelineio')+copy_metadata('pyaaf2')
import json
asset_names = [item['path'] for item in json.loads((build/'small_assets.json').read_text(encoding='utf-8'))]
ui_data = [(str(root/'assets'/name), 'assets') for name in asset_names]
contract_data = [(str(root/'effect_contract_schema.json'), '.')]
contract_data += [(str(root/'effect_contract_examples'/name), 'effect_contract_examples')
                  for name in ('blur-instance.json', 'dissolve-instance.json')]
a = Analysis([str(root/'rtx5090_exporter.py')], pathex=[str(root)],
    binaries=ped_bins+dnd_binaries+otio_binaries+aaf_binaries+aaf2_binaries, datas=ped_data+ped_metadata+ui_data+contract_data+dnd_data+numpy_metadata+pillow_metadata+otio_data+aaf_data+aaf2_data+timeline_metadata,
    hiddenimports=['audio_plugin_worker', 'pedalboard_native', *ped_hidden, 'okk_cli', *otio_hidden, *aaf_hidden, *aaf2_hidden, *[m for m in dnd_hidden if '.__pyinstaller' not in m]],
    hookspath=[], runtime_hooks=[], excludes=[], noarchive=False)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name='OKK STUDIO',
    debug=False, bootloader_ignore_signals=False, strip=False, upx=False,
    console=False, contents_directory='.', icon=str(root/'assets/app_icon.ico'),
    version=str(build/'version_info.txt'))
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name='OKK STUDIO 2.0.0')
