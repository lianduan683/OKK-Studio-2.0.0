"""Export telemetry follows committed intervals without moving edit state."""
from __future__ import annotations

import copy
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import Mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from export_progress_ui import (ExportProgressUIMixin, export_cache_text,
                                export_cursor_time, export_phase_text)
from multicam_ui import MulticamWorkspace


class Workspace(ExportProgressUIMixin):
    def __init__(self):
        self.project = SimpleNamespace(duration=120., range_start=0., range_end=120.,
                                       fps=30., clips=['unchanged'])
        self.current = 9.
        self.timeline = Mock()
        self.timeline.xview.return_value = (.25, .75)
        self.time_var = Mock()
        self.export_cache_var = Mock()
        self._follow_timeline_playhead = Mock()
        self.draw_playhead = Mock()
        self._pin_timeline_headers = Mock()
        self._queue_timeline_redraw = Mock()
        self.seek = Mock(side_effect=AssertionError('Export telemetry must not seek.'))


class ExportCursorTests(unittest.TestCase):
    def snapshot(self, **changes):
        result = dict(stage='encoding', timeline_start=30., total_seconds=60.,
                      contiguous_completed_seconds=0., processed_seconds=40.,
                      encoded_frames=1200, progress_percent=63.)
        result.update(changes)
        return result

    def test_later_parallel_completions_do_not_advance_contiguous_cursor(self):
        # Many frames have completed in later chunks but the first is pending.
        self.assertEqual(export_cursor_time(self.snapshot()), 30.)
        self.assertEqual(export_cursor_time(self.snapshot(contiguous_completed_seconds=10.)), 40.)

    def test_old_telemetry_never_fakes_a_position_from_aggregate_frames(self):
        snapshot = self.snapshot()
        del snapshot['contiguous_completed_seconds']
        self.assertIsNone(export_cursor_time(snapshot))
        self.assertEqual(export_cursor_time(snapshot, 35.), 35.)

    def test_cursor_is_monotonic_and_clamped_to_export_range(self):
        self.assertEqual(export_cursor_time(self.snapshot(contiguous_completed_seconds=2.), 40.), 40.)
        self.assertEqual(export_cursor_time(self.snapshot(contiguous_completed_seconds=100.)), 90.)
        self.assertEqual(export_cursor_time(self.snapshot(contiguous_completed_seconds=-20.)), 30.)

    def test_invalid_progress_does_not_change_position(self):
        for value in (None, float('nan'), float('inf'), 'bad', True):
            with self.subTest(value=value):
                self.assertEqual(export_cursor_time(self.snapshot(contiguous_completed_seconds=value), 42.), 42.)

    def test_delivery_rate_and_range_override_still_follow_current_timeline(self):
        ws = Workspace()
        project = copy.copy(ws.project)
        project.range_start, project.range_end, project.fps = 30., 90., 24.
        ws._begin_export_tracking(project, 'D:/deliver.mp4')
        ws._update_export_tracking(self.snapshot(contiguous_completed_seconds=5.))
        self.assertEqual(ws._export_cursor_time, 35.)
        self.assertEqual(ws.current, 9.)
        ws._follow_timeline_playhead.assert_called_once_with(position=35.)
        ws.seek.assert_not_called()
        ws._update_export_tracking(self.snapshot(contiguous_completed_seconds=5.))
        self.assertEqual(ws.draw_playhead.call_count, 1, 'Unchanged progress should not redraw.')

    def test_terminal_results_restore_viewport_without_changing_edit_state(self):
        for stage in ('done', 'failed', 'cancelled'):
            with self.subTest(stage=stage):
                ws = Workspace()
                ws._begin_export_tracking(ws.project, 'D:/deliver.mp4')
                ws._update_export_tracking(self.snapshot(contiguous_completed_seconds=12.))
                ws._update_export_tracking(self.snapshot(stage=stage, contiguous_completed_seconds=12.))
                self.assertIsNone(ws._export_cursor_time)
                self.assertEqual(ws.current, 9.)
                ws.timeline.xview_moveto.assert_called_once_with(.25)
                ws.seek.assert_not_called()
                ws._update_export_tracking(self.snapshot(stage=stage))
                self.assertEqual(ws.timeline.xview_moveto.call_count, 1)

    def test_different_queued_timeline_does_not_move_current_editor_cursor(self):
        ws = Workspace()
        project = copy.copy(ws.project)
        project.clips = ['older queue snapshot']
        ws._begin_export_tracking(project, 'D:/queued.mp4')
        ws._update_export_tracking(self.snapshot(contiguous_completed_seconds=20.))
        self.assertIsNone(ws._export_cursor_time)
        ws.draw_playhead.assert_not_called()

    def test_progress_cannot_follow_replaced_project(self):
        ws = Workspace()
        ws._begin_export_tracking(ws.project, 'D:/deliver.mp4')
        ws.project = copy.copy(ws.project)
        ws._update_export_tracking(self.snapshot(contiguous_completed_seconds=20.))
        ws.draw_playhead.assert_not_called()

    def test_cache_locations_survive_sparse_terminal_snapshot(self):
        ws = Workspace()
        ws._begin_export_tracking(ws.project, 'D:/deliver.mp4')
        ws._update_export_tracking(self.snapshot(work_directory='D:/temp/chunks',
                                                checkpoint_directory='D:/resume/hash'))
        ws._update_export_tracking(dict(stage='cancelled'))
        text = ws.export_cache_var.set.call_args.args[0]
        for expected in ('D:/temp/chunks', 'D:/resume/hash', 'D:/deliver.mp4', '本次未生成完整成片'):
            self.assertIn(expected, text)
        self.assertNotIn('已写入', text)

    def test_new_export_resets_progress_and_directory_state(self):
        ws = Workspace()
        ws._begin_export_tracking(ws.project, 'D:/old.mp4')
        ws._update_export_tracking(self.snapshot(contiguous_completed_seconds=50.,
                                                work_directory='D:/old-cache'))
        ws._update_export_tracking(self.snapshot(stage='done'))
        ws._begin_export_tracking(ws.project, 'D:/new.mp4')
        ws._update_export_tracking(self.snapshot(contiguous_completed_seconds=0.))
        self.assertEqual(ws._export_cursor_time, 30.)
        self.assertNotIn('old-cache', ws.export_cache_var.set.call_args.args[0])

    def test_draw_uses_export_cursor_but_preserves_edit_time(self):
        ws = Workspace()
        ws._export_cursor_time = 45.
        ws._timeline_x = lambda value: value * 10
        ws._px = lambda value: value
        ws._color_mode = False
        ws.timeline.canvasy.side_effect = lambda value: value
        ws.timeline.winfo_height.return_value = 200
        MulticamWorkspace.draw_playhead(ws)
        self.assertEqual(ws.timeline.create_line.call_args.args[0], 450.)
        self.assertEqual(ws.current, 9.)

    def test_phase_and_locations_describe_final_output_publication(self):
        self.assertIn('拼接', export_phase_text(dict(stage='muxing', phase='合并分段')))
        self.assertIn('准备', export_phase_text(dict(stage='preparing')))
        text = export_cache_text(dict(stage='encoding', work_directory='D:/tmp',
                                      checkpoint_directory='D:/resume', output_path='D:/result.mp4'))
        self.assertIn('全部片段拼接成功后写入', text)
        self.assertIn('重试时自动复用', text)


if __name__ == '__main__':
    unittest.main()
