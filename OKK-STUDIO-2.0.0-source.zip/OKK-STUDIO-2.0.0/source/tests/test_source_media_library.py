"""Original media survives source-instance editing and can be inserted again."""
from copy import deepcopy
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from exporter_core import MediaInfo
from multicam_core import CameraClip, Cut, MulticamProject
from source_media import SOURCE_GROUP, SOURCE_PREFIX, retain_source_media, populate_source_rows
from timeline_edits import delete_source_clips
from timeline_split import split_timeline
from tests import test_timeline_drag_merge as fixture


class SourceLibraryModelTests(unittest.TestCase):
    def test_split_delete_all_instances_retains_full_original_and_disk_bytes(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'原片.mov'
            path.write_bytes(b'unchanged source')
            project = MulticamProject(clips=[CameraClip('a', 1, str(path), 0, 12, has_audio=False)], cuts=[Cut(0, 1)])
            before = deepcopy(project)
            edited, count, _ = split_timeline(project, 5., {('clip', 'a')})
            self.assertEqual(count, 1)
            self.assertEqual(project, before)
            self.assertEqual(edited.source_media[0].duration, 12)
            delete_source_clips(edited, [clip.id for clip in edited.clips])
            self.assertEqual(edited.clips, [])
            self.assertEqual(edited.duration, 0)
            self.assertEqual(edited.cameras, [])
            self.assertEqual([(s.path, s.source_in, s.duration) for s in edited.source_media], [(str(path), 0, 12)])
            self.assertEqual(path.read_bytes(), b'unchanged source')
            edited.validate()

    def test_same_file_instances_share_one_library_reference(self):
        project = MulticamProject(clips=[CameraClip('a', 1, 'recording.mov', 0, 4),
                                       CameraClip('b', 3, 'recording.mov', 9, 8, source_in=4)])
        retain_source_media(project)
        self.assertEqual(len(project.source_media), 1)
        self.assertEqual(project.source_media[0].duration, 12)
        delete_source_clips(project, ['a'])
        self.assertEqual([c.id for c in project.clips], ['b'])
        self.assertEqual(project.source_media[0].duration, 12)
        retained = deepcopy(project.source_media)
        retain_source_media(project)
        self.assertEqual(project.source_media, retained)

    def test_library_survives_save_reload_after_last_instance_is_gone(self):
        with tempfile.TemporaryDirectory() as folder:
            path = str(Path(folder)/'offline-original.mov')
            project = MulticamProject(clips=[CameraClip('original', 1, path, -2, 15)])
            delete_source_clips(project, ['original'])
            payload = project.to_payload(folder)
            self.assertEqual(payload['version'], 25)
            self.assertEqual(payload['source_media'][0]['path'], 'offline-original.mov')
            restored = MulticamProject.from_payload(payload, folder)
            self.assertEqual(restored.source_media, project.source_media)
            self.assertEqual(restored.clips, [])
            tree = Mock()
            populate_source_rows(tree, restored, {})
            self.assertEqual(tree.insert.call_count, 2)
            self.assertIn('离线', tree.insert.call_args.kwargs['text'])

    def test_legacy_payload_is_supported_and_noop_does_not_mutate_it(self):
        project = MulticamProject(clips=[CameraClip('a', 1, 'a.mp4', 0, 10)])
        with tempfile.TemporaryDirectory() as folder:
            payload = project.to_payload(folder)
            self.assertNotIn('source_media', payload)
            restored = MulticamProject.from_payload(payload, folder)
            self.assertEqual(restored.source_media, [])
            untouched, count, _ = split_timeline(restored, 20, {('clip', 'a')})
            self.assertEqual(count, 0)
            self.assertEqual(untouched, restored)
            delete_source_clips(restored, ['a'])
            self.assertEqual(restored.source_media[0].duration, 10)

    def test_duplicate_basenames_show_unambiguous_original_paths(self):
        project = MulticamProject(clips=[CameraClip('a', 1, 'camera-a/C0001.MP4', 0, 12),
                                       CameraClip('b', 2, 'camera-b/C0001.MP4', 0, 16)])
        retain_source_media(project)
        self.assertEqual(len(project.source_media), 2)
        tree = Mock()
        populate_source_rows(tree, project, {})
        rows = tree.insert.call_args_list[1:]
        self.assertIn('camera-a/C0001.MP4', rows[0].kwargs['text'])
        self.assertIn('camera-b/C0001.MP4', rows[1].kwargs['text'])
        self.assertTrue(all(row.kwargs['values'][1] for row in rows))

    def test_final_split_instance_proxy_preference_is_retained(self):
        project = MulticamProject(clips=[CameraClip('a', 1, 'a.mp4', 0, 10, has_audio=False)])
        edited, _, _ = split_timeline(project, 4., {('clip', 'a')})
        delete_source_clips(edited, ['a'])
        remaining = edited.clips[0]
        remaining.proxy_path, remaining.proxy_disabled = 'verified-proxy.mp4', True
        delete_source_clips(edited, [remaining.id])
        self.assertEqual(edited.source_media[0].proxy_path, 'verified-proxy.mp4')
        self.assertTrue(edited.source_media[0].proxy_disabled)
        self.assertEqual(edited.source_media[0].duration, 10)

    def test_deleted_original_reading_metadata_survives_duplicate_roundtrip(self):
        changes = {'proxy_path': 'different-proxy.mp4', 'proxy_disabled': True,
                   'camera_make': 'Other make', 'camera_model': 'Other model',
                   'camera_metadata_source': 'other metadata', 'has_alpha': True,
                   'has_audio': True}
        with tempfile.TemporaryDirectory() as folder:
            path = str(Path(folder)/'original.mov')
            for name, changed in changes.items():
                with self.subTest(field=name):
                    original = CameraClip('a', 1, path, 0, 10)
                    project = MulticamProject(clips=[original])
                    retain_source_media(project)
                    for identifier, start in (('b', 10), ('c', 20)):
                        duplicate = deepcopy(original)
                        duplicate.id, duplicate.start = identifier, start
                        setattr(duplicate, name, changed)
                        project.clips.append(duplicate)
                    delete_source_clips(project, ['a'])
                    retain_source_media(project)
                    before = deepcopy(project)
                    payload = project.to_payload(folder)
                    self.assertEqual(project, before)
                    self.assertEqual(payload['version'], 25)
                    self.assertIn('source_media', payload)
                    restored = MulticamProject.from_payload(payload, folder)
                    retain_source_media(restored)
                    self.assertEqual(getattr(restored.source_media[0], name),
                                     getattr(original, name))

    def test_equivalent_duplicate_does_not_upgrade_schema_for_library_id(self):
        project = MulticamProject(clips=[CameraClip('a', 1, 'same.mov', 0, 10)])
        retain_source_media(project)
        project.clips.extend([CameraClip('b', 1, 'same.mov', 10, 10),
                              CameraClip('c', 1, 'same.mov', 20, 10)])
        delete_source_clips(project, ['a'])
        self.assertEqual(project.source_media[0].id, 'a')
        with tempfile.TemporaryDirectory() as folder:
            payload = project.to_payload(folder)
            self.assertNotIn('source_media', payload)
            self.assertEqual(payload['version'], 8)
            restored = MulticamProject.from_payload(payload, folder)
            retain_source_media(restored)
            self.assertEqual(restored.source_media[0].id, 'b')
            self.assertEqual(restored.source_media[0].duration, 10)

    def test_bad_library_rejected_before_publish(self):
        with tempfile.TemporaryDirectory() as folder:
            project = MulticamProject(clips=[CameraClip('a', 1, 'a.mp4', 0, 10)])
            delete_source_clips(project, ['a'])
            payload = project.to_payload(folder)
            for bad in ({}, [None], [dict(payload['source_media'][0], duration=-1)],
                        [payload['source_media'][0], dict(payload['source_media'][0], id='b')]):
                with self.subTest(bad=bad), self.assertRaises(ValueError):
                    MulticamProject.from_payload(dict(payload, source_media=bad), folder)


class SourceLibraryUITests(unittest.TestCase):
    setUp = fixture.TimelineDropTests.setUp
    tearDown = fixture.TimelineDropTests.tearDown
    root_position = fixture.TimelineDropTests.root_position
    # Inherit the same hidden-window fixture, not its previous test cases.
    def test_original_row_remains_after_deletion_and_reinsert_is_undoable(self):
        workspace = self.workspace
        workspace.project.clips[0].proxy_path = 'approved-proxy.mp4'
        workspace.project.clips[0].proxy_disabled = True
        workspace._refresh()
        original = deepcopy(workspace.project)
        workspace._set_timeline_selection({('clip', 'one')})
        workspace._delete_timeline_selection()
        self.assertNotIn('one', [clip.id for clip in workspace.project.clips])
        self.assertTrue(workspace.media_tree.exists(SOURCE_PREFIX+'one'))
        self.assertFalse(workspace.media_tree.exists('one'))
        after_delete = deepcopy(workspace.project)
        info = MediaInfo(path='one.mp4', duration=10, width=1920, height=1080, fps=30)
        workspace._media_drag = dict(id=SOURCE_PREFIX+'one', active=True, project=workspace.project)
        target = self.root_position(3, 2)
        with patch('timeline_interaction.batch_import', return_value=[(1, info)]):
            workspace._media_drag_release(target)
            kind, payload = workspace.jobs.get(timeout=5)
            self.assertEqual(kind, 'timeline_import_ready')
            workspace._finish_timeline_import(payload)
        inserted = workspace.project.clips[-1]
        self.assertNotEqual(inserted.id, 'one')
        self.assertEqual(inserted.proxy_path, 'approved-proxy.mp4')
        self.assertTrue(inserted.proxy_disabled)
        self.assertEqual((inserted.path, inserted.start, inserted.source_in, inserted.duration), ('one.mp4', 3, 0, 10))
        self.assertEqual(workspace.project.clips[0].start, 0)
        self.assertEqual(len(workspace.project.source_media), 2)
        workspace.undo()
        self.assertEqual(workspace.project, after_delete)
        workspace.redo()
        self.assertEqual(workspace.project.clips[-1].id, inserted.id)
        workspace.undo()
        workspace.undo()
        self.assertEqual(workspace.project, original)
        self.assertEqual(self.errors, [])

    def test_reopened_library_drag_keeps_deleted_original_proxy_policy(self):
        workspace = self.workspace
        with tempfile.TemporaryDirectory() as folder:
            original_path = str(Path(folder)/'original.mov')
            proxy_path = str(Path(folder)/'original-proxy.mp4')
            alternate = str(Path(folder)/'alternate-proxy.mp4')
            project = MulticamProject(clips=[CameraClip('a', 1, original_path, 0, 10,
                proxy_path=proxy_path, has_audio=False)], cuts=[Cut(0, 1)])
            retain_source_media(project)
            project.clips.extend([
                CameraClip('b', 1, original_path, 10, 10, proxy_path=alternate,
                           proxy_disabled=True, has_audio=False),
                CameraClip('c', 1, original_path, 20, 10, has_audio=False)])
            delete_source_clips(project, ['a'])
            retain_source_media(project)
            project_file = Path(folder)/'saved.json'
            project.save(project_file)
            workspace.project = MulticamProject.load(project_file)
            workspace._refresh()
            self.assertTrue(workspace.media_tree.exists(SOURCE_PREFIX+'a'))
            before = deepcopy(workspace.project)
            workspace._media_drag = dict(id=SOURCE_PREFIX+'a', active=True,
                                        project=workspace.project)
            target = self.root_position(3, 1)
            info = MediaInfo(path=original_path, duration=10, width=1920,
                             height=1080, fps=30, has_audio=False)
            with patch('timeline_interaction.batch_import', return_value=[(1, info)]):
                workspace._media_drag_release(target)
                kind, payload = workspace.jobs.get(timeout=5)
                self.assertEqual(kind, 'timeline_import_ready')
                workspace._finish_timeline_import(payload)
            inserted = workspace.project.clips[-1]
            self.assertEqual(inserted.proxy_path, proxy_path)
            self.assertFalse(inserted.proxy_disabled)
            self.assertNotIn(inserted.id, {'a', 'b', 'c'})
            self.assertEqual([(c.id, c.start) for c in workspace.project.clips[:2]],
                             [('b', 10), ('c', 20)])
            workspace.undo()
            self.assertEqual(workspace.project, before)
            self.assertEqual(self.errors, [])

    def test_deleting_library_row_is_not_a_timeline_or_disk_delete(self):
        workspace = self.workspace
        before = deepcopy(workspace.project)
        workspace.media_tree.selection_set(SOURCE_PREFIX+'one')
        workspace._delete_media_selection()
        self.assertEqual(workspace.project, before)
        self.assertEqual(workspace.undo_stack, [])
        self.assertIn('原片', workspace.status.get())

    def test_camera_drop_over_source_library_is_ignored(self):
        workspace = self.workspace
        tree = workspace.media_tree
        tree.see(SOURCE_GROUP)
        self.root.update_idletasks()
        x, y, width, height = tree.bbox(SOURCE_GROUP)
        workspace._media_drag = dict(kind='camera', camera=1, active=True, project=workspace.project,
                                    order=workspace.project.stacked_cameras(include_hidden=True), target=None)
        workspace._preview_camera_drop(tree.winfo_rootx()+x+10, tree.winfo_rooty()+y+height/2)
        self.assertIsNone(workspace._media_drag['target'])
        self.assertEqual(self.errors, [])


if __name__ == '__main__':
    unittest.main()
