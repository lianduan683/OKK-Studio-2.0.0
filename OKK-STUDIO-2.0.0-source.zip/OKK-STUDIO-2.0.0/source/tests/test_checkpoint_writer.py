"""Optional checkpoint validation stays bounded and drains on cancellation."""
import threading
import unittest

from export_checkpoint import CheckpointWriter


class CheckpointWriterTests(unittest.TestCase):
    def test_queue_bound_never_blocks_producer_and_context_drains(self):
        entered, release, finished = threading.Event(), threading.Event(), []

        def block():
            entered.set()
            self.assertTrue(release.wait(5))
            finished.append(1)

        with CheckpointWriter(max_pending=2) as writer:
            self.assertTrue(writer.submit(block))
            self.assertTrue(entered.wait(5))
            self.assertTrue(writer.submit(lambda: finished.append(2)))
            self.assertFalse(writer.submit(lambda: finished.append(3)))
            release.set()
        self.assertEqual(finished, [1, 2])

    def test_context_exception_waits_for_accepted_writes_and_releases_slots(self):
        finished = threading.Event()
        with self.assertRaisesRegex(RuntimeError, 'cancel render'):
            with CheckpointWriter(max_pending=1) as writer:
                self.assertTrue(writer.submit(finished.set))
                raise RuntimeError('cancel render')
        self.assertTrue(finished.is_set())
        self.assertIsNone(writer._pool)

    def test_callback_error_releases_capacity(self):
        entered = threading.Event()
        def fail():
            entered.set()
            raise ValueError('optional cache failed')
        with CheckpointWriter(max_pending=1) as writer:
            self.assertTrue(writer.submit(fail))
            self.assertTrue(entered.wait(5))
        # A failing cache task cannot leak its capacity semaphore.
        self.assertTrue(writer._slots.acquire(blocking=False))
        writer._slots.release()


if __name__ == '__main__': unittest.main(verbosity=2)
