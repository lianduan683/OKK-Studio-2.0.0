"""Ordinary multicam exports resume finalized chunks and report ordered progress."""
from pathlib import Path
import json
import subprocess
import tempfile
import threading
import unittest
from dataclasses import replace
from unittest.mock import patch

from exporter_core import Capabilities, CREATE_NO_WINDOW, ExportCancelled, ExportSettings
from multicam_core import CameraClip, Cut, MulticamProject, render_multicam


class SimpleExportResumeTests(unittest.TestCase):
    def setUp(self):
        app = Path(__file__).resolve().parents[1]
        self.ffmpeg, self.ffprobe = str(app/'bin/ffmpeg.exe'), str(app/'bin/ffprobe.exe')
        if not Path(self.ffmpeg).is_file(): self.skipTest('bundled FFmpeg required')
        self.temp = tempfile.TemporaryDirectory(prefix='okk-simple-resume-')
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        self.source = self.folder/'camera-a.mp4'
        self.command([self.ffmpeg, '-v', 'error', '-y', '-f', 'lavfi', '-i',
            'testsrc2=s=160x90:r=30:d=0.3', '-an', '-c:v', 'libx264',
            '-preset', 'ultrafast', '-threads', '1', str(self.source)])
        self.other = self.folder/'camera-b.mp4'
        self.other.write_bytes(self.source.read_bytes())
        self.project = MulticamProject(fps=30., clips=[
            CameraClip('a', 1, str(self.source), 0., .3),
            CameraClip('b', 2, str(self.other), 0., .3)],
            cuts=[Cut(0., 1), Cut(.1, 2), Cut(.2, 1)])
        self.settings = ExportSettings(codec='libx264', preset='ultrafast', quality=0,
            audio='none', decode_mode='cpu', bit_depth='8-bit', parallel_workers=1,
            extra_args=['-threads', '1'])
        self.commands = []

    def command(self, args):
        result = subprocess.run(args, capture_output=True, timeout=30, creationflags=CREATE_NO_WINDOW)
        self.assertEqual(result.returncode, 0, result.stderr.decode('utf8', 'replace')[-2000:])
        return result.stdout

    def runner(self, args, report):
        self.commands.append(args)
        self.command(args)
        return 0, ''

    def render(self, output, **kwargs):
        return render_multicam(self.project, output, self.ffmpeg, self.ffprobe,
            kwargs.pop('settings', self.settings), Capabilities(),
            kwargs.pop('runner', self.runner), work_directory=self.folder, **kwargs)

    def pixels(self, path):
        return self.command([self.ffmpeg, '-v', 'error', '-threads', '1', '-i', str(path),
            '-pix_fmt', 'yuv420p', '-threads', '1', '-f', 'rawvideo', 'pipe:1'])

    def test_cancelled_plain_export_reuses_only_complete_chunks_and_is_frame_identical(self):
        output = self.folder/'delivery.mp4'
        output.write_bytes(b'previous delivery')
        cancel = threading.Event()

        def stop_second(command, report):
            if command[-1].endswith('camera_000001.mp4'):
                Path(command[-1]).write_bytes(b'incomplete')
                cancel.set()
                return 1, 'synthetic cancellation'
            return self.runner(command, report)

        with self.assertRaises(ExportCancelled):
            self.render(output, runner=stop_second, cancel_event=cancel)
        self.assertEqual(output.read_bytes(), b'previous delivery')
        self.commands.clear()
        snapshots = []
        self.render(output, metrics=snapshots.append)
        self.assertEqual(len([c for c in self.commands if '-frames:v' in c]), 2)
        self.assertEqual(snapshots[-1]['reused_segments'], 1)
        self.assertEqual(snapshots[-1]['reused_frames'], 3)
        self.assertAlmostEqual(snapshots[-1]['contiguous_completed_seconds'], .3)
        reference = self.folder/'fresh.mp4'
        self.render(reference)
        self.assertEqual(self.pixels(output), self.pixels(reference))
        stream = json.loads(self.command([self.ffprobe, '-v', 'error', '-count_frames',
            '-show_streams', '-of', 'json', str(output)]))['streams'][0]
        self.assertEqual((stream['nb_read_frames'], stream['avg_frame_rate']), ('9', '30/1'))
        self.commands.clear()
        changed = []
        self.render(output, settings=replace(self.settings, quality=18), metrics=changed.append)
        self.assertEqual(changed[-1]['reused_segments'], 0)
        self.assertEqual(len([c for c in self.commands if '-frames:v' in c]), 3)

    def test_parallel_progress_waits_for_contiguous_completed_prefix(self):
        later_completed = threading.Event()
        snapshots = []

        def metrics(snapshot):
            snapshots.append(snapshot)
            if snapshot.get('completed_segments', 0) and snapshot.get('contiguous_completed_seconds') == 0:
                later_completed.set()

        def runner(command, report):
            result = self.runner(command, report)
            if command[-1].endswith('camera_000000.mp4'):
                report({'frame': '3', 'out_time_us': '100000'})
                self.assertTrue(later_completed.wait(8), 'later chunk never completed independently')
            return result

        self.render(self.folder/'parallel.mp4', settings=replace(self.settings, parallel_workers=2),
                    runner=runner, metrics=metrics)
        values = [s['contiguous_completed_seconds'] for s in snapshots if 'contiguous_completed_seconds' in s]
        self.assertEqual(values, sorted(values))
        self.assertTrue(later_completed.is_set())
        self.assertAlmostEqual(values[-1], .3)
        self.assertTrue(any(s.get('processed_seconds', 0) > 0 and
                            s.get('contiguous_completed_seconds') == 0 for s in snapshots))
        self.assertTrue(snapshots[-1]['work_directory'])
        self.assertTrue(Path(snapshots[-1]['checkpoint_directory']).is_dir())
        self.assertEqual(snapshots[-1]['timeline_start'], 0.)

    def test_checkpoint_validation_overlaps_next_encode(self):
        from export_checkpoint import CheckpointStore
        entered, next_started = threading.Event(), threading.Event()
        original = CheckpointStore.commit

        def commit(store, command, *args, **kwargs):
            self.assertIsNotNone(kwargs.get('prepared_signature'))
            if command[-1].endswith('camera_000000.mp4'):
                entered.set()
                self.assertTrue(next_started.wait(8), 'checkpoint blocked the encoding worker')
            return original(store, command, *args, **kwargs)

        def runner(command, report):
            if command[-1].endswith('camera_000001.mp4'):
                self.assertTrue(entered.wait(8), 'checkpoint worker did not start')
                next_started.set()
            return self.runner(command, report)

        with patch.object(CheckpointStore, 'commit', commit):
            self.render(self.folder/'overlap.mp4', runner=runner)
        self.assertTrue(next_started.is_set())


if __name__ == '__main__': unittest.main(verbosity=2)
