"""Route selection respects only the geometry of the job being exported.

Real render planning, CPU effect graphs, delivery and trace writing execute;
metadata probes, GPU planners and process execution are in-memory fixtures.
No FFmpeg executable or GPU device is launched by these tests.
"""
from contextlib import ExitStack
from dataclasses import replace
from fractions import Fraction
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from clip_transform import ClipTransform, ClipTransformRange
from creative_core import ColorGrade, Transition
from exporter_core import Capabilities, ExportSettings, MediaInfo
import multicam_core as module
from multicam_core import CameraClip, Cut, MulticamProject
from video_placement import placement_filter


class GpuRouteScopeRegressions(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='okk-gpu-route-scope-')
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        self.source = self.folder / 'a.mp4'
        self.other = self.folder / 'b.mp4'
        self.ffmpeg = self.folder / 'fixture-ffmpeg.exe'
        self.gpu = self.folder / 'fixture-gpu.exe'
        for path in (self.source, self.other, self.ffmpeg, self.gpu):
            path.write_bytes(b'fixture bytes; never executed')
        self.commands, self.metrics = [], []
        self.settings = ExportSettings(codec='hevc_nvenc', preset='p4',
            bit_depth='8-bit', audio='none', decode_mode='cuda',
            auto_parallel=False, parallel_workers=1)
        self.caps = Capabilities(nvenc_codecs={'hevc_nvenc'}, cuda_decode=True, scale_cuda=True)
        self.media = MediaInfo(str(self.source), duration=4., width=1280, height=720,
            fps=30., video_codec='hevc', pixel_format='yuv420p', bit_depth=8,
            color_primaries='bt709', color_transfer='bt709', color_space='bt709', color_range='tv')
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.stack.enter_context(patch.object(module, 'probe_media',
            side_effect=lambda _, path: replace(self.media, path=path)))
        self.stack.enter_context(patch.object(module, 'probe_partition_rates',
            return_value={str(self.source): Fraction(30), str(self.other): Fraction(30)}))
        self.stack.enter_context(patch.object(module, 'find_gpu_export_ffmpeg', return_value=str(self.gpu)))
        self.plan = self.stack.enter_context(patch.object(module, 'build_gpu_video_plan',
            return_value=SimpleNamespace(global_options=(), input_options=('-hwaccel', 'cuda'),
                filter_chain='fixture_gpu_grade', color_options=(), gpu_resident=False)))
        checkpoint = SimpleNamespace(root=self.folder/'checkpoints',
            signature=lambda *a, **k: None, reuse=lambda *a, **k: False,
            transcode_candidate=lambda *a, **k: None, commit=lambda *a, **k: False)
        self.stack.enter_context(patch('export_checkpoint.CheckpointStore', return_value=checkpoint))
        self.stack.enter_context(patch('subprocess.run', side_effect=AssertionError('External process launched')))

    def project(self):
        return MulticamProject(clips=[
            CameraClip('a', 1, str(self.source), 0., 4.),
            CameraClip('b', 2, str(self.other), 0., 4.)],
            cuts=[Cut(0., 1)], fps=30., range_start=0., range_end=1.,
            camera_grades={1: ColorGrade(exposure=.25)})

    def runner(self, command, callback):
        self.commands.append(list(command))
        Path(command[-1]).write_bytes(b'completed fixture output')
        if callback is not None:
            callback({'frame': '30', 'out_time_us': '1000000'})
        return 0, ''

    def export(self, project):
        module.render_multicam(project, self.folder/'delivery.mp4', str(self.ffmpeg),
            'fixture-ffprobe', self.settings, self.caps, self.runner,
            work_directory=self.folder, metrics=self.metrics.append)
        return [command for command in self.commands if '-frames:v' in command]

    @staticmethod
    def option(command, key):
        return command[command.index(key)+1]

    def assert_cpu_geometry(self, command, values):
        self.assertEqual(command[0], str(self.ffmpeg))
        graph = self.option(command, '-filter_complex' if '-filter_complex' in command else '-vf')
        self.assertIn(placement_filter(values, 1280, 720), graph)
        self.assertIn('lutrgb=', graph, 'CPU fallback must retain grading')

    def test_unrelated_camera_placement_does_not_disable_current_gpu_grade(self):
        project = self.project()
        project.clips[1].placement = dict(x=.1, y=0., scale=.8)
        commands = self.export(project)
        self.plan.assert_called_once()
        self.assertEqual(commands[0][0], str(self.gpu))
        self.assertEqual(self.option(commands[0], '-vf'), 'fixture_gpu_grade')

    def test_unrelated_later_program_placement_does_not_disable_current_gpu_grade(self):
        project = self.project()
        project.clip_transforms = [ClipTransformRange(2., 3.,
            ClipTransform(placement=dict(x=.1, y=0., scale=.8)))]
        commands = self.export(project)
        self.plan.assert_called_once()
        self.assertEqual(commands[0][0], str(self.gpu))

    def test_current_camera_placement_keeps_cpu_geometry_and_grade(self):
        project = self.project()
        project.clips[0].placement = dict(x=.1, y=.2, scale=.8)
        commands = self.export(project)
        self.plan.assert_not_called()
        self.assert_cpu_geometry(commands[0], (.1, .2, .8))

    def test_current_program_placement_keeps_cpu_geometry_and_grade(self):
        project = self.project()
        project.clip_transforms = [ClipTransformRange(0., 1.,
            ClipTransform(placement=dict(x=-.1, y=.2, scale=.8)))]
        commands = self.export(project)
        self.plan.assert_not_called()
        self.assert_cpu_geometry(commands[0], (-.1, .2, .8))

    def test_transition_geometry_on_either_side_never_reaches_geometry_blind_gpu_plan(self):
        for side in (0, 1):
            for kind in ('source', 'program'):
                with self.subTest(side=side, kind=kind):
                    project = self.project()
                    project.cuts = [Cut(0., 1), Cut(2., 2)]
                    project.transitions = [Transition(2., 'fade', .4)]
                    project.range_start, project.range_end = 1.8, 2.2
                    values = (.1, .2, .8)
                    if kind == 'source':
                        project.clips[side].placement = dict(zip(('x', 'y', 'scale'), values))
                    else:
                        project.clip_transforms = [ClipTransformRange(0. if side == 0 else 2.,
                            2. if side == 0 else 4., ClipTransform(
                                placement=dict(zip(('x', 'y', 'scale'), values))))]
                    self.commands.clear()
                    with patch.object(module, 'build_gpu_transition_command',
                            side_effect=AssertionError('Geometry-blind GPU transition invoked')) as transition:
                        commands = self.export(project)
                    transition.assert_not_called()
                    self.assertEqual(len(commands), 1)
                    self.assert_cpu_geometry(commands[0], values)

    def test_plain_cuda_fast_path_reports_cuda_pipeline_in_trace(self):
        project = self.project()
        project.camera_grades = {}
        commands = self.export(project)
        self.plan.assert_not_called()
        self.assertEqual(self.option(commands[0], '-hwaccel'), 'cuda')
        self.assertEqual(self.option(commands[0], '-hwaccel_output_format'), 'cuda')
        self.assertEqual(self.option(commands[0], '-c:v'), 'hevc_nvenc')
        trace = Path(self.metrics[-1]['diagnostic_path'])
        events = [json.loads(line) for line in trace.read_text('utf-8').splitlines()]
        starts = [item for item in events if item['event'] == 'attempt_start']
        finishes = [item for item in events if item['event'] == 'attempt_finish']
        self.assertEqual([item['backend'] for item in starts], ['cuda_pipeline'])
        self.assertEqual([item['backend'] for item in finishes], ['cuda_pipeline'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
