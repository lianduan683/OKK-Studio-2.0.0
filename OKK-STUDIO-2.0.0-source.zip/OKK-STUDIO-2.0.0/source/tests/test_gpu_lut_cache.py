"""Repeated-cut LUT preparation keeps content identity and bounded memory."""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import FrozenInstanceError
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import gpu_lut_shader as lut
from creative_core import ColorGrade
from realtime_grade import shader_source

IDENTITY = ('LUT_3D_SIZE 2\nDOMAIN_MIN 0 0 0\nDOMAIN_MAX 1 1 1\n'
            '0 0 0\n1 0 0\n0 1 0\n1 1 0\n0 0 1\n1 0 1\n0 1 1\n1 1 1\n')


class GpuLutCacheTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='okk-lut-cache-')
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        self.path = self.folder / 'grade.cube'
        self.path.write_text(IDENTITY, encoding='utf-8')
        self.clear_cache()
        self.addCleanup(self.clear_cache)

    @staticmethod
    def clear_cache():
        with lut._texture_cache_lock:
            lut._texture_cache.clear()
            lut._texture_cache_bytes = 0

    def test_1020_segments_parse_once_and_reuse_hex(self):
        expected = lut._parse_cube_texture(IDENTITY.encode())
        with patch.object(lut, '_parse_cube_texture', wraps=lut._parse_cube_texture) as parse:
            original, original_hex = lut._cached_cube_texture(self.path)
            for _ in range(1019):
                cube, texture_hex = lut._cached_cube_texture(self.path)
                self.assertIs(cube, original)
                self.assertIs(texture_hex, original_hex)
            self.assertEqual(parse.call_count, 1)
        self.assertEqual(original, expected)
        self.assertEqual(original_hex, expected.rgba.hex())
        with self.assertRaises(FrozenInstanceError):
            original.size = 9

    def test_same_path_size_and_mtime_replacement_changes_shader(self):
        grade = ColorGrade(lut_path=str(self.path))
        before = lut.attach_grade_luts(shader_source(), (grade,))
        stamp = self.path.stat()
        updated = IDENTITY.replace('0 0 0\n1 0 0', '1 0 0\n1 0 0')
        self.assertEqual(len(updated), len(IDENTITY))
        self.path.write_text(updated, encoding='utf-8')
        os.utime(self.path, ns=(stamp.st_atime_ns, stamp.st_mtime_ns))
        self.assertEqual(self.path.stat().st_mtime_ns, stamp.st_mtime_ns)
        after = lut.attach_grade_luts(shader_source(), (grade,))
        self.assertNotEqual(before, after)
        self.assertEqual(lut.read_cube_texture(self.path), lut._parse_cube_texture(updated.encode()))

    def test_cached_result_never_masks_missing_or_invalid_source(self):
        lut.read_cube_texture(self.path)
        self.path.unlink()
        with self.assertRaises(lut.LutShaderUnsupported):
            lut.read_cube_texture(self.path)
        self.path.write_text('LUT_3D_SIZE 2\n0 0 0\n', encoding='utf-8')
        with self.assertRaises(lut.LutShaderUnsupported):
            lut.read_cube_texture(self.path)
        self.path.write_bytes(b'\xff\xfe\x00')
        with self.assertRaises(lut.LutShaderUnsupported):
            lut.read_cube_texture(self.path)

    def test_simultaneous_workers_parse_content_once(self):
        with patch.object(lut, '_parse_cube_texture', wraps=lut._parse_cube_texture) as parse:
            with ThreadPoolExecutor(max_workers=8) as pool:
                results = list(pool.map(lut.read_cube_texture, [self.path] * 64))
            self.assertEqual(parse.call_count, 1)
        self.assertTrue(all(cube is results[0] for cube in results))

    def test_identical_content_at_different_paths_shares_immutable_texture(self):
        other = self.folder / 'another.cube'
        other.write_bytes(self.path.read_bytes())
        with patch.object(lut, '_parse_cube_texture', wraps=lut._parse_cube_texture) as parse:
            first = lut.read_cube_texture(self.path)
            self.assertIs(first, lut.read_cube_texture(other))
            self.assertEqual(parse.call_count, 1)

    def test_entry_count_is_bounded_and_evicts_least_recently_used_content(self):
        paths = []
        for index in range(5):
            path = self.folder / f'grade-{index}.cube'
            path.write_text(f'TITLE "{index}"\n' + IDENTITY, encoding='utf-8')
            paths.append(path)
        with patch.object(lut, '_parse_cube_texture', wraps=lut._parse_cube_texture) as parse:
            for path in paths[:4]:
                lut.read_cube_texture(path)
            lut.read_cube_texture(paths[0])  # Retain the oldest-used content.
            lut.read_cube_texture(paths[4])
            self.assertEqual(len(lut._texture_cache), 4)
            lut.read_cube_texture(paths[0])
            self.assertEqual(parse.call_count, 5)
            lut.read_cube_texture(paths[1])
            self.assertEqual(parse.call_count, 6)
        self.assertLessEqual(lut._texture_cache_bytes, lut.MAX_TEXTURE_CACHE_BYTES)

    def test_payload_byte_budget_also_bounds_entries(self):
        payload = 2 ** 3 * 16 * 3  # RGBA float bytes plus their ASCII hex.
        with patch.object(lut, 'MAX_TEXTURE_CACHE_BYTES', payload * 2):
            for index in range(4):
                self.path.write_text(f'TITLE "{index}"\n' + IDENTITY, encoding='utf-8')
                lut.read_cube_texture(self.path)
            self.assertEqual(len(lut._texture_cache), 2)
            self.assertEqual(lut._texture_cache_bytes, payload * 2)
        self.clear_cache()
        with patch.object(lut, 'MAX_TEXTURE_CACHE_BYTES', payload - 1):
            self.assertEqual(lut.read_cube_texture(self.path).size, 2)
            self.assertFalse(lut._texture_cache)
            self.assertEqual(lut._texture_cache_bytes, 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
