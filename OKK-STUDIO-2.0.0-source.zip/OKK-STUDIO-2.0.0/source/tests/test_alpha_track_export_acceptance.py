"""Real ProRes 4444 Alpha import, outer-track preview and opaque export acceptance.

Set OKK_ALPHA_ACCEPTANCE_DIR to retain synthetic media, frames, reports and outputs.
Set OKK_TEST_NVENC=1 to exercise detected NVIDIA hardware (otherwise explicit skip).
No user media, running app, system input or existing installation is used.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, replace
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time
import unittest
from unittest.mock import patch
import uuid

import numpy as np
from PIL import Image

from exporter_core import (Capabilities, CREATE_NO_WINDOW, ExportSettings,
                           detect_capabilities, probe_media)
from multicam_core import CameraClip, Cut, MulticamProject, render_multicam
from multicam_outer import resolve_compound
from project_settings import DEFAULT_SETTINGS
from video_stack_preview import preview_command, preview_segments


class AlphaTrackExportAcceptanceTests(unittest.TestCase):
    width, height, fps, frames = 320, 180, 24, 48

    @classmethod
    def command(cls, args, **kwargs):
        result = subprocess.run(args, capture_output=True, timeout=60,
                                creationflags=CREATE_NO_WINDOW, **kwargs)
        if result.returncode:
            raise AssertionError(result.stderr.decode('utf8', 'replace')[-6000:])
        return result.stdout

    @classmethod
    def setUpClass(cls):
        cls.app = Path(__file__).resolve().parents[1]
        cls.ffmpeg = str(cls.app/'bin'/'ffmpeg.exe')
        cls.ffprobe = str(cls.app/'bin'/'ffprobe.exe')
        if not Path(cls.ffmpeg).is_file() or not Path(cls.ffprobe).is_file():
            raise unittest.SkipTest('Bundled FFmpeg and FFprobe required for real Alpha media acceptance')
        destination = os.environ.get('OKK_ALPHA_ACCEPTANCE_DIR')
        if destination:
            cls.folder = Path(destination)/('run-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:8])
            cls.folder.mkdir(parents=True, exist_ok=False)
        else:
            temporary = tempfile.TemporaryDirectory(prefix='okk-alpha-acceptance-')
            cls.addClassCleanup(temporary.cleanup)
            cls.folder = Path(temporary.name)
        cls.base = cls.folder/'background-pattern.mp4'
        cls.alpha = cls.folder/'prores4444-alpha.mov'
        y, x = np.indices((cls.height, cls.width))
        checker = ((x//40+y//30) % 2).astype(np.uint8)
        base = np.empty((cls.height, cls.width, 4), np.uint8)
        base[..., 0] = 20+checker*30
        base[..., 1] = 55+checker*45
        base[..., 2] = 205-checker*35
        base[..., 3] = 255
        # Flat zones plus a straight soft edge reveal dropped/premultiplied Alpha.
        top = np.zeros_like(base)
        top[..., :3] = (235, 55, 25)
        top[..., 3] = np.where(x < 80, 0, np.where(x < 160, 128,
                                np.where(x < 192, (x-160)*255//31, 255))).astype(np.uint8)
        Image.fromarray(base, 'RGBA').save(cls.folder/'background-source.png')
        Image.fromarray(top, 'RGBA').save(cls.folder/'alpha-source.png')
        signal = ['-color_primaries', 'bt709', '-color_trc', 'bt709',
                  '-colorspace', 'bt709', '-color_range', 'tv']
        common = [cls.ffmpeg, '-v', 'error', '-y', '-f', 'rawvideo', '-pixel_format', 'rgba',
                  '-video_size', f'{cls.width}x{cls.height}', '-framerate', str(cls.fps),
                  '-i', 'pipe:0', '-an']
        signal_filter = ',setsar=1,setparams=range=limited:color_primaries=bt709:color_trc=bt709:colorspace=bt709'
        cls.command([*common, '-vf', 'scale=in_range=pc:out_range=tv:out_color_matrix=bt709,format=yuv420p'+signal_filter,
                     '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '0', '-threads', '1',
                     *signal, str(cls.base)], input=base.tobytes()*cls.frames)
        cls.command([*common, '-vf', 'scale=in_range=pc:out_range=tv:out_color_matrix=bt709,format=yuva444p10le'+signal_filter,
                     '-c:v', 'prores_ks', '-profile:v', '4', '-alpha_bits', '16', '-threads', '1',
                     *signal, str(cls.alpha)], input=top.tobytes()*36)
        cls.alpha_info = probe_media(cls.ffprobe, str(cls.alpha))
        cls.base_rgb = cls.decode(cls.base)[0]
        cls.alpha_rgba = cls.decode(cls.alpha, 'rgba', 4)[0]
        cls.source_report = dict(input=asdict(cls.alpha_info), canvas=[cls.width, cls.height],
                                 fps=cls.fps, total_frames=cls.frames,
                                 alpha_timeline_range=[.25, 1.75], output_alpha=False)
        (cls.folder/'source-manifest.json').write_text(json.dumps(cls.source_report, indent=2), 'utf8')
        print('Alpha acceptance artifacts: '+str(cls.folder), flush=True)

    @classmethod
    def decode(cls, path, pixel='rgb24', channels=3):
        raw = cls.command([cls.ffmpeg, '-v', 'error', '-threads', '1', '-i', str(path),
                           '-map', '0:v:0', '-an', '-threads:v', '1', '-pix_fmt', pixel,
                           '-f', 'rawvideo', 'pipe:1'])
        return np.frombuffer(raw, np.uint8).reshape(-1, cls.height, cls.width, channels)

    def import_alpha_through_ui(self):
        # The production completion callback receives REAL probed ProRes metadata;
        # only the background file-selection/probe thread is omitted.
        from tests.test_program_edit_ui import ProgramEditWorkspaceTests
        ui = ProgramEditWorkspaceTests(methodName='runTest')
        ui.setUp()
        try:
            w = ui.workspace
            w.app.caps = Capabilities(ffmpeg_path=self.ffmpeg, ffprobe_path=self.ffprobe)
            w.project = MulticamProject(fps=self.fps, clips=[
                CameraClip('background', 1, str(self.base), 0., 2., has_audio=False)],
                cuts=[Cut(0., 1)], master_duration=2., range_end=2.,
                project_settings=dict(DEFAULT_SETTINGS, width=self.width, height=self.height))
            w._refresh()
            w.set_multicam_timeline_view(True)
            w._finish_timeline_import((w.project, .25, None, [self.alpha_info], None,
                                       ('above', 0), {}))
            ui.root.update()
            clip = next(c for c in w.project.clips if c.path == str(self.alpha))
            self.assertTrue(clip.has_alpha)
            self.assertEqual((clip.start, clip.duration), (.25, 1.5))
            self.assertEqual(w.project.multicam_outer_order, [clip.camera, 0])
            self.assertTrue(w.project.video_stack_enabled)
            self.assertEqual(w.project.cuts, [Cut(0., 1)])
            self.assertEqual(len(w.project.clips), 2)
            self.assertLess(w._timeline_track_bounds[clip.camera][0], w._timeline_program_bounds[0])
            self.assertEqual(ui.callback_errors, [])
            project = deepcopy(w.project)
            path = self.folder/'alpha-outer-track-project.multicam.json'
            project.save(path)
            restored = MulticamProject.load(path)
            self.assertEqual(restored.multicam_outer_order, project.multicam_outer_order)
            self.assertTrue(next(c for c in restored.clips if c.path == str(self.alpha)).has_alpha)
            return project
        finally:
            ui.tearDown()

    def preview(self, project, frame):
        segment = next(preview_segments(project, frame/self.fps, single_frame=True))
        segment = resolve_compound(segment, project, self.ffmpeg, self.ffprobe,
                                   self.width, self.height, preview=True)
        media = {layer.path: probe_media(self.ffprobe, layer.path) for layer in segment.layers}
        command, rate = preview_command(segment, project, self.ffmpeg, media,
                                        self.width, self.height, single_frame=True)
        self.assertEqual(rate, self.fps)
        raw = self.command(command)
        return np.frombuffer(raw, np.uint8).reshape(self.height, self.width, 4)[..., :3]

    def check_export(self, name, settings, caps, *, placement=False):
        project = self.import_alpha_through_ui()
        if placement:
            next(c for c in project.clips if c.path == str(self.alpha)).placement = dict(x=.1, y=-.05, scale=.75)
        original = deepcopy(project)
        folder = self.folder/name
        folder.mkdir()
        output = folder/(name+'.mp4')
        commands, snapshots = [], []
        def runner(command, callback):
            commands.append(list(command))
            result = subprocess.run(command, capture_output=True, timeout=60, creationflags=CREATE_NO_WINDOW)
            packet = {}
            for line in result.stdout.decode('utf8', 'replace').splitlines():
                key, sep, value = line.partition('=')
                if sep:
                    packet[key] = value
                    if key == 'progress': callback(packet); packet = {}
            return result.returncode, result.stderr.decode('utf8', 'replace')
        began = time.monotonic()
        render_multicam(project, output, self.ffmpeg, self.ffprobe, settings, caps, runner,
                        metrics=snapshots.append, work_directory=folder, checkpoint_root=folder/'checkpoints')
        elapsed = time.monotonic()-began
        probe = json.loads(self.command([self.ffprobe, '-v', 'error', '-select_streams', 'v:0',
            '-count_frames', '-show_streams', '-of', 'json', str(output)]))['streams'][0]
        frames = self.decode(output)
        metrics = {}
        y, x = np.indices((self.height, self.width))
        # CPU swscale and Vulkan/libplacebo have different chroma reconstruction
        # kernels at a 4:2:0 discontinuity. Judge flat interiors and the soft-alpha
        # ramp independently; still report all full-frame tails without hiding them.
        interiors = ((x % 40 > 2) & (x % 40 < 37) & (y % 30 > 2)
                     & (y % 30 < 27) & (np.abs(x-192) > 3))
        for frame in (0, 6, 12, 30, 42, 47):
            preview = self.preview(project, frame)
            delta = np.abs(preview.astype(np.int16)-frames[frame].astype(np.int16))
            metrics[str(frame)] = dict(mean=float(delta.mean()), p99=float(np.percentile(delta, 99)),
                                       max=int(delta.max()), interior_p99=float(np.percentile(delta[interiors], 99)),
                                       soft_edge_mean=float(delta[40:50, 166:186].mean()),
                                       soft_edge_max=int(delta[40:50, 166:186].max()))
            if frame == 12:
                Image.fromarray(preview).save(folder/'preview-frame-12.png')
                Image.fromarray(frames[frame]).save(folder/'export-frame-12.png')
                sheet = Image.new('RGB', (self.width*2, self.height))
                sheet.paste(Image.fromarray(preview), (0, 0))
                sheet.paste(Image.fromarray(frames[frame]), (self.width, 0))
                sheet.save(folder/'preview-left-export-right.png')
        trace = [json.loads(line) for line in Path(snapshots[-1]['diagnostic_path']).read_text('utf8').splitlines()]
        backends = [dict(task=v.get('task'), backend=v.get('backend'), returncode=v.get('returncode'))
                    for v in trace if v.get('event') == 'attempt_finish']
        report = dict(output=str(output), stream=probe, preview_comparison=metrics, backends=backends,
                      gpu_route_skips=[v for v in trace if v.get('event') == 'gpu_route_skipped'],
                      elapsed_seconds=elapsed, placement=placement, encoder=settings.codec,
                      note='Opaque delivery; ProRes Alpha is composited over the background, not preserved in MP4.')
        (folder/'acceptance-report.json').write_text(json.dumps(report, indent=2), 'utf8')
        (folder/'commands.json').write_text(json.dumps(commands, indent=2), 'utf8')
        self.assertEqual(project, original)
        self.assertEqual((probe['width'], probe['height'], probe['avg_frame_rate'], probe['nb_read_frames']),
                         (self.width, self.height, '24/1', str(self.frames)))
        self.assertAlmostEqual(float(probe['duration']), 2., places=5)
        self.assertEqual(probe['codec_name'], 'h264' if '264' in settings.codec else 'hevc')
        self.assertNotIn('a', probe['pix_fmt'], 'H264/HEVC delivery should be an opaque composition')
        self.assertEqual(len(frames), self.frames)
        for frame, result in metrics.items():
            with self.subTest(frame=frame, encoder=settings.codec):
                self.assertLessEqual(result['mean'], 4.5)
                if settings.codec.endswith('_nvenc') and not placement and int(frame) in (6, 12, 30):
                    self.assertLessEqual(result['interior_p99'], 12.)
                    self.assertLessEqual(result['soft_edge_mean'], 6.)
                    self.assertLessEqual(result['soft_edge_max'], 18)
                else:
                    self.assertLessEqual(result['p99'], 20.)
        # Exact half-open Alpha interval: frames 0..5 and 42..47 remain background.
        for frame in (0, 5, 42, 47):
            self.assertLess(np.abs(frames[frame].astype(int)-self.base_rgb.astype(int)).mean(), 4.)
        if not placement:
            opacity = self.alpha_rgba[..., 3:4].astype(float)/255
            expected = np.rint(self.alpha_rgba[..., :3]*opacity+self.base_rgb*(1-opacity))
            samples = {'transparent': (40, 45), 'half': (120, 45), 'opaque': (260, 45),
                       'soft_edge': (176, 45)}
            for region, (x, y) in samples.items():
                a = frames[12, y-3:y+4, x-3:x+4].astype(float).mean((0, 1))
                b = expected[y-3:y+4, x-3:x+4].mean((0, 1))
                with self.subTest(region=region):
                    np.testing.assert_allclose(a, b, atol=10.)
        else:
            # Translated/scaled layer has transparent padding, never a black rectangle.
            np.testing.assert_allclose(frames[12, 5, 40], self.base_rgb[5, 40], atol=10.)
            self.assertGreater(int(frames[12, 60, 270, 0]), 200)
        if settings.codec.endswith('_nvenc'):
            self.assertTrue(any(settings.codec in command for command in commands))
            alpha_commands = [c for c in commands if str(self.alpha) in c]
            self.assertTrue(alpha_commands)
            # Hardware H264 background may share the command; ProRes Alpha must
            # have its OWN software input rather than being sent through NVDEC.
            for command in alpha_commands:
                at = command.index(str(self.alpha))
                previous = max((i+2 for i, v in enumerate(command[:at-1]) if v == '-i'), default=0)
                self.assertNotIn('-hwaccel', command[previous:at-1])
        return report

    def test_cpu_h264_true_alpha_outer_track_preview_and_export(self):
        self.assertEqual(self.alpha_info.video_codec, 'prores')
        self.assertTrue(self.alpha_info.has_alpha)
        self.assertTrue(self.alpha_info.pixel_format.startswith('yuva'))
        self.assertEqual((self.alpha_info.color_primaries, self.alpha_info.color_transfer,
                          self.alpha_info.color_space, self.alpha_info.color_range),
                         ('bt709', 'bt709', 'bt709', 'tv'))
        self.assertIn(self.alpha_info.sample_aspect_ratio, ('1:1', '1/1'))
        self.assertLessEqual(int(self.alpha_rgba[45, 40, 3]), 1)
        self.assertAlmostEqual(int(self.alpha_rgba[45, 120, 3]), 128, delta=2)
        self.assertGreaterEqual(int(self.alpha_rgba[45, 260, 3]), 254)
        settings = ExportSettings(codec='libx264', preset='ultrafast', quality=0, bframes=0,
            resolution='timeline', audio='none', decode_mode='cpu', bit_depth='8-bit',
            parallel_workers=1, extra_args=['-threads', '1'])
        self.check_export('cpu-h264', settings, Capabilities())

    def test_cpu_hevc_ten_bit_alpha_placement_and_preview(self):
        settings = ExportSettings(codec='libx265', preset='ultrafast', quality=0, bframes=0,
            resolution='timeline', audio='none', decode_mode='cpu', bit_depth='10-bit',
            parallel_workers=1, extra_args=['-threads', '1', '-x265-params',
                                           'pools=1:frame-threads=1:lossless=1:log-level=error'])
        report = self.check_export('cpu-hevc10-placement', settings, Capabilities(), placement=True)
        self.assertEqual(report['stream']['pix_fmt'], 'yuv420p10le')

    @unittest.skipUnless(os.environ.get('OKK_TEST_NVENC') == '1', 'Set OKK_TEST_NVENC=1 for actual NVIDIA validation')
    def test_detected_nvenc_alpha_actual_route_and_preview(self):
        caps = detect_capabilities(self.app)
        if 'hevc_nvenc' not in caps.nvenc_codecs:
            self.skipTest('Detected machine has no usable HEVC NVENC encoder')
        settings = ExportSettings(codec='hevc_nvenc', preset='p1', quality=14, bframes=0,
            resolution='timeline', audio='none', decode_mode='cuda', bit_depth='10-bit',
            parallel_workers=1, auto_parallel=False, extra_args=['-rc', 'constqp', '-qp', '14'])
        report = self.check_export('nvenc-hevc10', settings, caps)
        self.assertTrue(any(row['returncode'] == 0 for row in report['backends']))
        from gpu_export import find_gpu_export_ffmpeg
        from gpu_resident import supported
        gpu_ffmpeg = find_gpu_export_ffmpeg(self.app)
        if gpu_ffmpeg and supported(gpu_ffmpeg):
            self.assertTrue(any(row['backend'] == 'gpu_composite_upload' and row['returncode'] == 0
                                for row in report['backends']), report['gpu_route_skips'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
