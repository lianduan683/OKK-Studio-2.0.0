"""Persistent source references, independent of editable timeline instances.

The library never owns or deletes files. Duration is the known source span; a
fresh timeline insertion probes the original again so trimmed legacy clips do
not restrict reinsertion to their old trimmed range.
"""
from copy import deepcopy
from dataclasses import replace
from pathlib import Path

from media_pool_core import media_key

SOURCE_GROUP = 'source_library'
SOURCE_PREFIX = 'source::'


def retain_source_media(project):
    """Remember source paths before an instance is split, trimmed or removed."""
    by_path = {media_key(clip.path): clip for clip in project.source_media}
    used_ids = {clip.id for clip in project.source_media}
    counts = {}
    for clip in project.clips:
        key = media_key(clip.path)
        counts[key] = counts.get(key, 0) + 1
    for clip in project.clips:
        key = media_key(clip.path)
        existing = by_path.get(key)
        duration = clip.source_in + clip.duration
        if existing is not None:
            existing.duration = max(existing.duration, duration)
            # Preserve the original instance's reading policy, or the last
            # remaining instance before it is deleted. Differently configured
            # duplicates are not silently collapsed into one policy.
            if clip.id == existing.id or counts[key] == 1:
                existing.proxy_path = clip.proxy_path
                existing.proxy_disabled = clip.proxy_disabled
            continue
        # IDs are references in the library only, not timeline instance IDs.
        identifier = clip.id
        if identifier in used_ids:
            import uuid
            identifier = uuid.uuid4().hex
        original = replace(deepcopy(clip), id=identifier, start=0.,
                           source_in=0., duration=duration, enabled=True)
        project.source_media.append(original)
        by_path[key] = original
        used_ids.add(identifier)


def source_for_row(project, identifier):
    if not isinstance(identifier, str) or not identifier.startswith(SOURCE_PREFIX):
        return None
    source_id = identifier[len(SOURCE_PREFIX):]
    return next((clip for clip in project.source_media if clip.id == source_id), None)


def populate_source_rows(tree, project, expanded):
    """Keep original paths visible even when the last instance was deleted."""
    if not project.source_media:
        return
    tree.insert('', 'end', iid=SOURCE_GROUP,
                text=f'素材库原片 ({len(project.source_media)})',
                open=expanded.get(SOURCE_GROUP, True))
    from editor_core import format_time
    names = {}
    for clip in project.source_media:
        name = Path(clip.path).name.casefold()
        names[name] = names.get(name, 0) + 1
    for clip in project.source_media:
        offline = not Path(clip.path).is_file()
        name = Path(clip.path).name
        if names[name.casefold()] > 1:
            name = clip.path  # Different cameras often both produce C0001.MP4.
        tree.insert(SOURCE_GROUP, 'end', iid=SOURCE_PREFIX+clip.id,
                    text=('离线 · ' if offline else '')+name,
                    values=('原片', format_time(clip.duration)), tags=('review',) if offline else ())


def needs_source_library_payload(project):
    """Persist originals only when untrimmed instances cannot reconstruct them.

    A fresh import does not need a new project format just to repeat metadata
    already present on its full source clip. After a trim/split/delete, the
    original reference must be stored independently to prevent losing it.
    """
    if not project.source_media:
        return False
    # Reproduce the actual legacy-load reconstruction without touching either
    # timeline instances or the live library. A full-length duplicate may have
    # a different proxy policy from the original that was subsequently deleted.
    from types import SimpleNamespace
    reconstructed = SimpleNamespace(clips=project.clips, source_media=[])
    retain_source_media(reconstructed)
    rebuilt = {media_key(clip.path): clip for clip in reconstructed.source_media}
    complete = {}
    for clip in project.clips:
        if clip.source_in == 0:
            key = media_key(clip.path)
            complete[key] = max(complete.get(key, 0.), clip.duration)

    def reading_metadata(clip):
        return (media_key(clip.proxy_path) if clip.proxy_path else '',
                clip.proxy_disabled, clip.camera_make, clip.camera_model,
                clip.camera_metadata_source, clip.has_alpha, clip.has_audio)

    for source in project.source_media:
        key = media_key(source.path)
        restored = rebuilt.get(key)
        if (restored is None or complete.get(key, 0.) + 1e-8 < source.duration
                or abs(restored.duration - source.duration) > 1e-8
                or reading_metadata(restored) != reading_metadata(source)):
            return True
    # IDs and timeline-only camera/placement fields do not alter source reading.
    # Do not upgrade a legacy schema just because reconstruction creates a new
    # library row identity after an otherwise equivalent original was deleted.
    return False
