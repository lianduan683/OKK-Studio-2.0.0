"""Camera-linked audio rows, mute controls, and asynchronous real waveforms."""
from __future__ import annotations

from camera_display import camera_number

from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import queue
import threading
import tkinter as tk

from audio_waveform import Waveform, decode_waveform, envelope_points, waveform_key
from exporter_core import find_binary
from timeline_audio import audio_track_enabled, source_audio_clips, master_audio_clips
from timeline_layout_ui import TimelineLayoutMixin


class TimelineAudioUIMixin(TimelineLayoutMixin):
    def _init_timeline_audio(self):
        self._init_timeline_layout()
        self._waveform_results = queue.Queue()
        self._waveform_cache = OrderedDict()
        self._waveform_pending = set()
        self._waveform_stop = threading.Event()
        self._waveform_processes = set()
        self._waveform_lock = threading.Lock()
        self._waveform_pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix='audio-waveform')
        self._audio_track_buttons = {}
        self._waveform_poll_after = self.after(120, self._poll_timeline_audio)

    def _timeline_audio_tracks(self, cameras):
        from timeline_tracks import audio_tracks
        if getattr(self.project, 'timeline_multicam_collapsed', False):
            cameras = self.project.timeline_cameras
        return audio_tracks(self.project, cameras)

    def _waveform_for(self, path):
        if not hasattr(self, '_waveform_cache'): self._init_timeline_audio()
        key = waveform_key(path)
        if key is None: return None
        cached = self._waveform_cache.get(key)
        if cached is not None:
            self._waveform_cache.move_to_end(key)
            return cached
        if key in self._waveform_pending or len(self._waveform_pending) >= 8 or self._waveform_stop.is_set():
            return None
        ffmpeg = self.app.caps.ffmpeg_path or find_binary('ffmpeg', Path(__file__).parent)
        if not ffmpeg or not Path(ffmpeg).is_file():
            cached = Waveform((), state='unavailable')
            self._waveform_cache[key] = cached
            return cached
        self._waveform_pending.add(key)
        def started(process):
            with self._waveform_lock:
                self._waveform_processes.add(process)
                if self._waveform_stop.is_set():
                    try: process.terminate()
                    except OSError: pass
        def finished(process):
            with self._waveform_lock: self._waveform_processes.discard(process)
        def worker():
            try:
                value = decode_waveform(ffmpeg, path, self._waveform_stop,
                                        process_started=started, process_finished=finished)
            except Exception:
                value = Waveform((), state='unavailable')
            self._waveform_results.put((key, value))
        try: self._waveform_pool.submit(worker)
        except RuntimeError: self._waveform_pending.discard(key)
        return None

    def _poll_timeline_audio(self):
        self._waveform_poll_after = None
        if self._waveform_stop.is_set(): return
        changed = False
        try:
            while True:
                key, waveform = self._waveform_results.get_nowait()
                self._waveform_pending.discard(key)
                if waveform is not None:
                    self._waveform_cache[key] = waveform
                    self._waveform_cache.move_to_end(key)
                    while len(self._waveform_cache) > 128: self._waveform_cache.popitem(last=False)
                    changed = True
        except queue.Empty:
            pass
        if changed and self.winfo_exists(): self.draw_timeline()
        self._waveform_poll_after = self.after(120, self._poll_timeline_audio)

    def _set_timeline_audio_track(self, track, enabled, *, solo=False):
        if not self._available(): return
        tracks = self._timeline_audio_tracks(self._timeline_camera_order())
        states = {candidate: audio_track_enabled(self.project, candidate) for candidate in tracks}
        target = {candidate: candidate == track for candidate in tracks} if solo else dict(states)
        if not solo: target[track] = bool(enabled)
        if target == states: return
        self._remember()
        # The first explicit setting must retain the old fallback state of all
        # other tracks. Otherwise enabling A2 would silently turn A1 off.
        self.project.audio_track_enabled.update(target)
        update = getattr(self, '_audio_track_changed', None)
        if update is not None: update()
        else: self._configure_player()
        self.draw_timeline()
        state = '出声' if audio_track_enabled(self.project, track) else '静音'
        self.status.set(f'A{camera_number(self.project, track)} 已设为{state}；Ctrl+Z 撤销。')

    def _toggle_timeline_audio_track(self, track):
        self._set_timeline_audio_track(track, not audio_track_enabled(self.project, track))

    def _timeline_audio_press(self, event):
        if self._timeline_audio_fold_press(event): return True
        x, y = self.timeline.canvasx(event.x), self.timeline.canvasy(event.y)
        for track, (left, top, right, bottom) in getattr(self, '_audio_track_buttons', {}).items():
            if left <= x <= right and top <= y <= bottom:
                self._toggle_timeline_audio_track(track)
                return True
        return False

    def _timeline_audio_context(self, event):
        x, y = self.timeline.canvasx(event.x), self.timeline.canvasy(event.y)
        header_left = self.timeline.canvasx(0)
        if not header_left <= x <= header_left+self._timeline_left: return False
        track = next((track for track, (top, bottom) in getattr(self, '_timeline_audio_track_bounds', {}).items()
                      if top <= y <= bottom), None)
        if track is None: return False
        menu = tk.Menu(self, tearoff=False, bg='#292b2e', fg='#dedfe3', activebackground='#3c5263')
        state = 'normal' if not (self.busy or self.app.working) else 'disabled'
        enabled = audio_track_enabled(self.project, track)
        menu.add_command(label='设为静音' if enabled else '设为出声', state=state,
                         command=lambda: self._toggle_timeline_audio_track(track))
        menu.add_command(label='仅此轨出声', state=state,
                         command=lambda: self._set_timeline_audio_track(track, True, solo=True))
        append_delete = getattr(self, '_append_track_delete_menu', None)
        if append_delete is not None: append_delete(menu, 'A', track)
        previous = getattr(self, 'audio_track_context_menu', None)
        if previous is not None: previous.destroy()
        self.audio_track_context_menu = menu
        try: menu.tk_popup(event.x_root, event.y_root)
        finally: menu.grab_release()
        return True

    def _draw_timeline_audio(self, cameras, audio_y, audio_h, width, label_font, timeline_x, visible):
        canvas = self.timeline
        self._audio_track_buttons = {}
        self._audio_fold_buttons = {}
        self._audio_group_button = None
        self._timeline_audio_track_bounds = {}
        self.timeline_camera_audio_items = {}
        self.timeline_master_audio_items = {}
        self._timeline_audio_bounds = None
        tracks = self._timeline_audio_tracks(cameras)
        duration = self._timeline_view_duration()
        view_left = canvas.canvasx(0)
        view_right = canvas.canvasx(canvas.winfo_width())
        pps = self._timeline_scale()
        y = audio_y
        group_drawn = False
        group_folded = getattr(self, '_camera_audio_collapsed', False)
        folded = getattr(self, '_collapsed_audio_tracks', set())
        for track in tracks:
            if track != 0 and not group_drawn:
                group_h = getattr(self, '_timeline_audio_group_h', self._px(24))
                self._audio_group_button = (view_left, y, view_right, y+group_h)
                if visible(0, y, width, y+group_h):
                    canvas.create_rectangle(0, y, width, y+group_h, fill='#303a36', outline='', tags=('audio-group',))
                    self._draw_audio_fold_icon(view_left+self._px(10), y+group_h/2, group_folded, 'audio-group')
                    canvas.create_text(view_left+self._px(22), y+group_h/2,
                        text='机位原声', anchor='w',
                        fill='#a7c6b8', font=label_font, tags=('audio-group',))
                    canvas.create_text(view_left+self._timeline_left+self._px(8), y+group_h/2,
                        text=f'{len([track for track in tracks if track != 0])} 轨 · 点击'+('展开' if group_folded else '收起'),
                        anchor='w', fill='#a7c6b8', font=label_font, tags=('audio-group',))
                y += group_h
                group_drawn = True
            if track != 0 and group_folded: continue
            row_h = getattr(self, '_timeline_audio_row_heights', {}).get(track, audio_h)
            top, y = y, y+row_h
            self._timeline_audio_track_bounds[track] = (top, y)
            if track == 0: self._timeline_audio_bounds = (top, y)
            if not visible(0, top, width, y): continue
            self._draw_timeline_audio_row(track, top, row_h, width, label_font, timeline_x, visible,
                                          duration, view_left, view_right, pps, track in folded and track != 0)

    def _draw_timeline_audio_row(self, track, y, audio_h, width, label_font, timeline_x, visible,
                                 duration, view_left, view_right, pps, compact):
        canvas = self.timeline
        enabled = audio_track_enabled(self.project, track)
        canvas.create_rectangle(0, y, width, y+audio_h, fill='#232c29' if enabled else '#27292b', outline='')
        if track == 0:
            clips = [(self.project.master_audio, clip.start, clip.duration, True, clip.id, clip.source_in, clip.enabled)
                     for clip in master_audio_clips(self.project)]
        else:
            clips = [(clip.path, clip.start, clip.duration, getattr(clip, 'has_audio', None), getattr(clip, 'id', None), getattr(clip, 'source_in', 0.), getattr(clip, 'enabled', True))
                     for clip in source_audio_clips(self.project) if clip.camera == track]
        for path, start, length, has_audio, identifier, source_in, clip_enabled in clips:
            x, x2 = timeline_x(start), timeline_x(start+length)
            if x2 <= x or not visible(x, y, x2, y+audio_h): continue
            audible = enabled and clip_enabled
            fill = '#36594e' if audible else '#343c3b'
            item = canvas.create_rectangle(x, y+self._px(2), x2, y+audio_h-self._px(2),
                                           fill=fill, outline='#5e8074' if audible else '#465650', tags=('audio-track',))
            if track == 0:
                self.timeline_audio_items.add(item)
                self.timeline_master_audio_items[item] = identifier
            elif identifier is not None and has_audio is not False:
                self.timeline_camera_audio_items[item] = identifier
            waveform = self._waveform_for(path) if has_audio is not False and not compact else None
            wave_left, wave_right = max(x, view_left), min(x2, view_right)
            wave_top, wave_bottom = y+self._px(17), y+audio_h-self._px(4)
            if not compact and waveform is not None and waveform.state == 'ready' and wave_right > wave_left:
                source_start = source_in+max(0., (wave_left-x)/pps)
                source_end = source_in+min(length, (wave_right-x)/pps)
                peaks = envelope_points(waveform, source_start, source_end,
                                        max(1, int((wave_right-wave_left)/max(1,self._px(2)))))
                center, amplitude = (wave_top+wave_bottom)/2, max(1., (wave_bottom-wave_top)/2)
                if len(peaks):
                    step = (wave_right-wave_left)/len(peaks)
                    top = [(wave_left+i*step, center-float(value)*amplitude) for i,value in enumerate(peaks)]
                    bottom = [(wave_left+i*step, center+float(value)*amplitude) for i,value in reversed(list(enumerate(peaks)))]
                    points = [value for point in top+bottom for value in point]
                    if len(points) >= 6:
                        canvas.create_polygon(*points, fill='#9ed6bf' if audible else '#6d8f7f', outline='', tags=('audio-waveform',))
            if x2-x > self._px(65):
                status = ''
                if has_audio is False or (waveform is not None and waveform.state == 'no_audio'): status = ' · 无音频'
                elif compact: pass
                elif waveform is None: status = ' · 读取波形…' if waveform_key(path) else ' · 离线'
                elif waveform.state != 'ready': status = ' · 波形不可用'
                title = ('已禁用 · ' if not clip_enabled else '')+Path(path).name+status
                title = self._timeline_fit_label(label_font, title, x2-x-self._px(10))
                item = canvas.create_text(x+self._px(5), y+(audio_h/2 if compact else self._px(9)), text=title,
                    fill='#d1e5db' if audible else '#a5b0ac', anchor='w', font=label_font, tags=('audio-track',))
                if track == 0:
                    self.timeline_audio_items.add(item)
                    self.timeline_master_audio_items[item] = identifier
                elif identifier is not None and has_audio is not False:
                    self.timeline_camera_audio_items[item] = identifier
        # Draw headers last, covering the part of negative-start audio beneath them.
        canvas.create_rectangle(view_left, y, view_left+self._timeline_left, y+audio_h, fill='#242c2a', outline='')
        if track != 0:
            bounds = view_left, y, view_left+self._px(20), y+audio_h
            self._audio_fold_buttons[track] = bounds
            self._draw_audio_fold_icon(view_left+self._px(10), y+audio_h/2, compact, 'audio-fold-button')
        canvas.create_text(view_left+self._px(5 if track == 0 else 22), y+audio_h/2,
                           text=f'A{camera_number(self.project, track)}', fill='#8ab7a4', anchor='w', font=label_font)
        left, right = view_left+self._px(28 if track == 0 else 52), view_left+self._timeline_left-self._px(3)
        if right > left:
            bounds = left, y+self._px(5), right, y+audio_h-self._px(5)
            self._audio_track_buttons[track] = bounds
            canvas.create_rectangle(*bounds, fill='#42715d' if enabled else '#3d4143',
                                    outline='#77af93' if enabled else '#62686b', tags=('audio-mute-button',))
            button_label = ('主音频 · ' if track == 0 else '') + ('出声' if enabled else '静音')
            canvas.create_text((left+right)/2, y+audio_h/2, text=button_label,
                               fill='#e3f1e8' if enabled else '#b9bec1', font=label_font, tags=('audio-mute-button',))

    def _close_timeline_audio(self):
        if not hasattr(self, '_waveform_stop'): return
        self._waveform_stop.set()
        pending = getattr(self, '_waveform_poll_after', None)
        if pending is not None:
            try: self.after_cancel(pending)
            except Exception: pass
            self._waveform_poll_after = None
        with self._waveform_lock:
            for process in tuple(self._waveform_processes):
                if process.poll() is None:
                    try: process.terminate()
                    except OSError: pass
        self._waveform_pool.shutdown(wait=False, cancel_futures=True)
