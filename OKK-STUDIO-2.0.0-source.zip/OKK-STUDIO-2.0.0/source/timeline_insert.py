"""Context insertion of persistent video tracks and media at a frozen time."""
from __future__ import annotations

from camera_display import camera_number

import math
import copy
import tkinter as tk
from tkinter import filedialog
from timeline_tracks import remove_tracks, track_empty


class TimelineInsertMixin:
    def _timeline_insert_target(self, event):
        canvas = self.timeline
        seconds = self._timeline_origin() + (canvas.canvasx(event.x)-self._timeline_left)/self._timeline_scale()
        seconds = max(0., math.floor(seconds*self.project.fps+.5)/self.project.fps)
        y = canvas.canvasy(event.y)
        camera = next((camera for camera, (top, bottom) in self._timeline_track_bounds.items()
                       if top <= y < bottom), None)
        return seconds, camera

    def _place_inserted_video_layer(self, camera, placement):
        """Inside the caller's undo transaction; front of order is topmost."""
        from multicam_outer import place_outer
        if self.project.multicam_outer_order or self.project.timeline_multicam_collapsed or placement[1] == 0:
            place_outer(self.project, camera, placement)
            return
        side, reference = placement
        order = [value for value in self.project.stacked_cameras(include_hidden=True) if value != camera]
        if reference in order and side in {'above', 'below'}:
            index = order.index(reference) + (side == 'below')
        else:
            index = len(order) if side == 'bottom' else 0
        order.insert(index, camera)
        self.project.video_stack_order = order
        self.project.video_stack_hidden = [value for value in self.project.video_stack_hidden if value != camera]
        self.project.video_stack_enabled = True

    def insert_video_track(self, placement=('top', None)):
        if not self._available(): return None
        self.pause()
        camera = max([*self.project.timeline_cameras,
                      *[int(track[1:]) for track in self.project.timeline_removed_tracks]], default=0)+1
        self._remember()
        self.project.timeline_empty_tracks.append(camera)
        # An empty track must not change the existing multicam programme.
        enabled = self.project.video_stack_enabled
        self._place_inserted_video_layer(camera, placement)
        if not self.project.multicam_outer_order: self.project.video_stack_enabled = enabled
        self._refresh()
        self.status.set(f'已插入空视频轨道 V{camera_number(self.project, camera)}；可在任意时间放入素材，上方轨道叠在上层。Ctrl+Z 撤销。')
        return camera

    def remove_empty_video_track(self, camera):
        if track_empty(self.project, 'V', camera):
            return self._delete_tracks('V', [camera])

    def _delete_tracks(self, kind, tracks):
        if not self._available(): return False
        available = (self._timeline_camera_order() if kind == 'V' else
                     self._timeline_audio_tracks(self._timeline_camera_order()))
        tracks = sorted(set(tracks).intersection(available))
        if kind == 'V': tracks = [track for track in tracks if track != 0]
        if not tracks: return False
        candidate = copy.deepcopy(self.project)
        self._capture_timeline_range(candidate)
        try:
            remove_tracks(candidate, kind, tracks)
        except ValueError as error:
            self.status.set(str(error)); return False
        self.pause()
        self._remember_timeline_change()
        self.project = candidate
        self._set_timeline_selection(set(), redraw=False)
        self._restore_timeline_range_fields()
        self._refresh()
        self.seek(self.current)
        self.status.set(f'已删除 {len(tracks)} 条'+('视频' if kind == 'V' else '音频')+'轨道；Ctrl+Z 撤销。')
        return True

    def _empty_timeline_tracks(self, kind):
        tracks = (self._timeline_camera_order() if kind == 'V' else
                  self._timeline_audio_tracks(self._timeline_camera_order()))
        return [track for track in tracks if not (kind == 'V' and track == 0)
                and track_empty(self.project, kind, track)]

    def _append_track_delete_menu(self, menu, kind, track):
        if kind == 'V' and track == 0: return
        menu.add_separator()
        state = 'normal' if not (self.busy or self.app.working) else 'disabled'
        menu.add_command(label='删除轨道', state=state,
                         command=lambda: self._delete_tracks(kind, [track]))
        menu.add_command(label='删除空白轨道',
                         state=state if self._empty_timeline_tracks(kind) else 'disabled',
                         command=lambda: self._delete_tracks(kind, self._empty_timeline_tracks(kind)))

    def _insert_timeline_media(self, position, camera=None, placement=None):
        if not self._available(): return False
        paths = filedialog.askopenfilenames(parent=self, title='在此位置插入时间线素材',
            filetypes=[('视频', '*.mp4 *.mov *.mkv *.mxf *.avi *.mts *.m2ts *.webm'), ('所有文件', '*.*')])
        if not paths: return False
        return self.import_timeline_paths(paths, start=position, camera=camera, layer_placement=placement)

    def _append_timeline_insert_menu(self, menu, event):
        position, camera = self._timeline_insert_target(event)
        menu.add_separator()
        tracks = tk.Menu(menu, tearoff=False, bg='#292b2e', fg='#dedfe3')
        tracks.add_command(label='插入最上方（顶层）', command=lambda: self.insert_video_track(('top', None)))
        if camera is not None:
            label = '多机位轨道' if camera == 0 else f'V{camera_number(self.project, camera)}'
            tracks.add_command(label=f'插入 {label} 上方', command=lambda: self.insert_video_track(('above', camera)))
            tracks.add_command(label=f'插入 {label} 下方', command=lambda: self.insert_video_track(('below', camera)))
        tracks.add_command(label='插入最下方', command=lambda: self.insert_video_track(('bottom', None)))
        menu.add_cascade(label='插入视频轨道', menu=tracks)
        media = tk.Menu(menu, tearoff=False, bg='#292b2e', fg='#dedfe3')
        media.add_command(label='新建顶层轨道', command=lambda: self._insert_timeline_media(position, placement=('top', None)))
        if camera is not None:
            if camera != 0:
                media.add_command(label=f'当前轨道 V{camera_number(self.project, camera)}', command=lambda: self._insert_timeline_media(position, camera))
            media.add_command(label=f'新轨道 · {label} 上方',
                command=lambda: self._insert_timeline_media(position, placement=('above', camera)))
            media.add_command(label=f'新轨道 · {label} 下方',
                command=lambda: self._insert_timeline_media(position, placement=('below', camera)))
        menu.add_cascade(label=f'在此位置插入素材…（{position:.3f} 秒）', menu=media)
        if camera is not None:
            key = self._timeline_hit_key(event)
            if key is not None and key[0] == 'clip':
                menu.add_command(label='转代理…', command=lambda: self.show_proxy_settings([key[1]]),
                                 state='disabled' if self._quick_proxy_running else 'normal')
            self._append_track_delete_menu(menu, 'V', camera)
        else:
            y = self.timeline.canvasy(event.y)
            track = next((track for track, (top, bottom) in self._timeline_audio_track_bounds.items()
                          if top <= y < bottom), None)
            if track is not None: self._append_track_delete_menu(menu, 'A', track)

    def _show_timeline_insert_menu(self, event):
        self.timeline.focus_set()
        self.pause()
        menu = tk.Menu(self, tearoff=False, bg='#292b2e', fg='#dedfe3', activebackground='#3c5263')
        self._append_timeline_insert_menu(menu, event)
        self.timeline_context_menu = menu
        try: menu.tk_popup(event.x_root, event.y_root)
        finally: menu.grab_release()
        return True
