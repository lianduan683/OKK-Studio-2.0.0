"""Export telemetry presentation without seeking or decoding media."""
from __future__ import annotations

import copy
import math

from editor_core import format_time


TERMINAL_STAGES = frozenset({'done', 'failed', 'cancelled'})
LOCATION_FIELDS = ('work_directory', 'checkpoint_directory', 'output_path')


def _finite(value):
    if isinstance(value, bool):
        return None
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return result if math.isfinite(result) else None


def export_cursor_time(snapshot, previous=None):
    """Use committed contiguous segments, never aggregate in-flight frames.

    Old telemetry lacks this field and must not invent a position. A later
    segment can finish before an earlier one when rendering in parallel.
    """
    start = _finite(snapshot.get('timeline_start'))
    duration = _finite(snapshot.get('total_seconds'))
    completed = _finite(snapshot.get('contiguous_completed_seconds'))
    if start is None or duration is None or completed is None or duration < 0:
        return previous
    value = start + min(duration, max(0., completed))
    old = _finite(previous)
    return max(value, old) if old is not None else value


def export_phase_text(snapshot):
    stage = str(snapshot.get('stage', 'encoding'))
    label = {'preparing': '准备', 'encoding': '渲染', 'muxing': '拼接 / 封装',
             'done': '完成', 'failed': '失败', 'cancelled': '已取消'}.get(stage, '导出')
    phase = str(snapshot.get('phase') or '')
    return phase if phase.startswith(label) else f'{label} · {phase}' if phase else label


def export_cache_text(snapshot):
    """Explain why the output folder stays empty until final publication."""
    stage = str(snapshot.get('stage', 'preparing'))
    work = str(snapshot.get('work_directory') or '')
    checkpoint = str(snapshot.get('checkpoint_directory') or '')
    output = str(snapshot.get('output_path') or '')
    lines = []
    if work:
        suffix = '（任务结束后清理）' if stage in TERMINAL_STAGES else '（分段渲染中，结束后清理）'
        lines.append('临时文件：' + work + ' ' + suffix)
    else:
        lines.append('临时文件：正在准备目录')
    if checkpoint:
        lines.append('续渲缓存：' + checkpoint + '（保留已校验片段，重试时自动复用）')
    elif stage != 'preparing':
        lines.append('续渲缓存：本次不可用')
    if output:
        state = ('已写入' if stage == 'done' else '本次未生成完整成片' if stage in TERMINAL_STAGES
                 else '全部片段拼接成功后写入')
        lines.append('成片：' + output + '（' + state + '）')
    return '\n'.join(lines)


def same_export_timeline(editor, rendered):
    """Delivery range/rate overrides do not change the editing timeline."""
    candidate = copy.copy(rendered)
    for name in ('range_start', 'range_end', 'fps'):
        setattr(candidate, name, getattr(editor, name))
    return candidate == editor


class ExportProgressUIMixin:
    def _begin_export_tracking(self, project, output):
        self._export_locations = {'output_path': str(output)}
        self._export_cursor_time = None
        self._export_follow_project = self.project if same_export_timeline(self.project, project) else None
        self._export_saved_xview = self.timeline.xview()[0]

    def _update_export_tracking(self, snapshot):
        # Called by _poll on the Tk thread, never by FFmpeg worker callbacks.
        locations = vars(self).setdefault('_export_locations', {})
        for name in LOCATION_FIELDS:
            if snapshot.get(name):
                locations[name] = str(snapshot[name])
        display = {**snapshot, **locations}
        variable = vars(self).get('export_cache_var')
        if variable is not None:
            variable.set(export_cache_text(display))
        stage = str(snapshot.get('stage', 'encoding'))
        if stage in TERMINAL_STAGES:
            self._finish_export_tracking()
            return
        if vars(self).get('_export_follow_project') is not self.project:
            return
        previous = vars(self).get('_export_cursor_time')
        position = export_cursor_time(snapshot, previous)
        if position is None or position == previous:
            return
        self._export_cursor_time = position
        self._follow_timeline_playhead(position=position)
        self.draw_playhead()
        self.time_var.set('渲染至 ' + format_time(position))

    def _finish_export_tracking(self):
        had_cursor = vars(self).get('_export_cursor_time') is not None
        self._export_cursor_time = None
        self._export_follow_project = None
        saved = vars(self).pop('_export_saved_xview', None)
        if not had_cursor:
            return
        if saved is not None:
            self.timeline.xview_moveto(saved)
            self._pin_timeline_headers()
            self._queue_timeline_redraw()
        self.draw_playhead()
        self.time_var.set(f'{format_time(self.current)} / {format_time(self.project.duration)}')
