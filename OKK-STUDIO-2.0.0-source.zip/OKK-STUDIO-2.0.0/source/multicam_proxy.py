"""Non-blocking, serial 1080p proxy preparation for multicamera editing."""
from __future__ import annotations

import os
from pathlib import Path
import threading
import time
import tkinter as tk
from tkinter import filedialog, ttk

from exporter_core import ExportCancelled
from proxy_settings_ui import ProxySettingsMixin


def _identity(path):
    return os.path.normcase(os.path.abspath(path))


def _stamp(path):
    try:
        info = Path(path).stat()
        return info.st_size, info.st_mtime_ns
    except OSError:
        return None


class MulticamProxyMixin(ProxySettingsMixin):
    def unlink_material_proxies(self, identifiers=None):
        """Opt out for this camera's references to each selected original.

        Split/overlapping instances of one recording share this action so a
        later half cannot silently bring its old proxy back into the monitor.
        Other cameras, media files and the global proxy preference stay intact.
        """
        if not self._available(): return False
        identifiers = set(self.media_tree.selection() if identifiers is None else identifiers)
        sources = {(clip.camera, _identity(clip.path)) for clip in self.project.clips
                   if clip.id in identifiers or f'camera_{clip.camera}' in identifiers}
        clips = [clip for clip in self.project.clips
                 if (clip.camera, _identity(clip.path)) in sources]
        changed = [clip for clip in clips if not clip.proxy_disabled or clip.proxy_path]
        if not changed:
            self.status.set('所选素材已使用原片；可重新链接或生成代理。')
            return False
        self._remember()
        # Discard already queued background bindings as well as future results.
        self._reset_quick_proxy()
        for clip in changed:
            clip.proxy_path = ''
            clip.proxy_disabled = True
        self._refresh()
        self._refresh_proxy_badges(force=True)
        self.status.set(f'已取消 {len(sources)} 份素材的代理（含同机位分割片段），使用原片；Ctrl+Z 撤销。')
        return True

    def _preview_use_proxies(self):
        """The editing proxy preference stays independent of colour targets."""
        return bool(self.proxy_var.get())

    def _color_original_cameras(self):
        if not vars(self).get('_color_mode', False):
            return ()
        target = self.grade_target
        if target == 'selection' and self.selected_program_range:
            from program_edits import program_spans
            first, last = self.selected_program_range
            cameras = {span.camera for span in program_spans(self.project)
                       if span.start < last - 1e-8 and span.end > first + 1e-8}
        elif type(target) is int:
            cameras = {target}
        else:
            cameras = set(self.project.cameras)
        if self.project.color_reference_camera is not None:
            cameras.add(self.project.color_reference_camera)
        return tuple(sorted(cameras & set(self.project.cameras)))

    def _refresh_color_media_policy(self):
        color = bool(vars(self).get('_color_mode', False))
        if self.player and color != vars(self).get('_published_color_monitoring', False):
            self.player.submit('color_monitoring', enabled=color)
            self._published_color_monitoring = color
        cameras = self._color_original_cameras()
        if self.player and cameras != vars(self).get('_published_original_cameras'):
            self.player.submit('original_cameras', cameras=cameras)
            self._published_original_cameras = cameras

    def _refresh_proxy_badges(self, *, force=False):
        """Show attachment state independently of the proxy-preview switch."""
        now = time.monotonic()
        if not force and now < vars(self).get('_proxy_badges_next_check', 0.):
            return
        self._proxy_badges_next_check = now + 1.
        from proxy_media import PreviewProxyResolver
        resolver = vars(self).get('_badge_proxy_resolver')
        if resolver is None:
            resolver = self._badge_proxy_resolver = PreviewProxyResolver()
        if force: resolver.reset()
        by_camera = {}
        for clip in self.project.clips:
            by_camera.setdefault(clip.camera, []).append(clip)
        self._refresh_clip_proxy_icons(resolver)
        for camera, badge in vars(self).get('camera_proxy_badges', {}).items():
            clips = by_camera.get(camera, ())
            ready = sum(not clip.proxy_disabled and _identity(resolver(clip.path, clip.proxy_path)) != _identity(clip.path) for clip in clips)
            missing = sum(not clip.proxy_disabled and bool(clip.proxy_path) and not Path(clip.proxy_path).is_file() for clip in clips)
            if clips and ready == len(clips):
                text, color = '已代理', '#82c9aa'
            elif ready:
                text, color = f'部分代理 {ready}/{len(clips)}', '#dfbc73'
            elif missing:
                text, color = '代理丢失', '#ef8d82'
            elif clips and all(clip.proxy_disabled for clip in clips):
                text, color = '使用原片', '#969ba3'
            else:
                text, color = '未代理', '#969ba3'
            if badge.cget('text') != text or badge.cget('fg') != color:
                badge.configure(text=text, fg=color)

    def _init_quick_proxy(self):
        self._quick_proxy_token = 0
        self._quick_proxy_cancel = threading.Event()
        self._quick_proxy_running = False
        self._quick_proxy_thread = None
        self.quick_proxy_status = tk.StringVar(self, value='')
        self._proxy_link_token = 0
        self._proxy_link_cancel = threading.Event()
        self._proxy_link_running = False

    def _build_quick_proxy_controls(self, parent):
        self.quick_proxy_button = ttk.Button(parent, text='一键 1080p 代理',
            style='Compact.TButton', command=self.start_quick_proxy)
        self.quick_proxy_button.pack(side='left', padx=(self._px(2), self._px(4)))
        self.proxy_link_button = ttk.Menubutton(parent, text='链接已有代理', style='Compact.TMenubutton')
        menu = tk.Menu(self.proxy_link_button, tearoff=False)
        menu.add_command(label='给所选素材链接代理文件…', command=self.link_existing_proxy)
        menu.add_command(label='为所选机位 / 素材从文件夹匹配…',
                         command=lambda: self.link_proxy_folder(selected_only=True))
        menu.add_command(label='为全部素材从文件夹匹配…', command=self.link_proxy_folder)
        menu.add_separator()
        menu.add_command(label='取消链接校验', command=self.cancel_proxy_link)
        self.proxy_link_button.configure(menu=menu)
        self.proxy_link_button.pack(side='left', padx=self._px(2))
        tk.Checkbutton(parent, text='代理预览', variable=self.proxy_var,
            command=self._configure_player, bg='#292b2e', fg='#73aa9c', selectcolor='#18191b',
            activebackground='#292b2e', activeforeground='#dedfe3', borderwidth=0,
            font=('Microsoft YaHei UI', 9)).pack(side='left')
        self.quick_proxy_cancel_button = ttk.Button(parent, text='取消', width=4,
            style='Compact.TButton', command=self.cancel_quick_proxy)
        self.quick_proxy_label = tk.Label(parent, textvariable=self.quick_proxy_status,
            bg='#292b2e', fg='#969ba3', font=('Microsoft YaHei UI', 8), anchor='w')
        self.quick_proxy_label.pack(side='left', padx=self._px(4))

    def _set_quick_proxy_running(self, running):
        self._quick_proxy_running = running
        button = vars(self).get('quick_proxy_button')
        cancel = vars(self).get('quick_proxy_cancel_button')
        if button is not None:
            button.configure(state='disabled' if running else 'normal')
        if cancel is not None:
            if running:
                cancel.configure(state='normal')
                cancel.pack(side='right', padx=self._px(2))
            else:
                cancel.pack_forget()

    def start_quick_proxy(self, *, clips=None, options=None):
        if self._quick_proxy_running:
            return False
        if not self.project.clips or clips == []:
            self.status.set('请先导入机位素材，再生成 1080p 代理。')
            return False
        if not self.app.caps.ffmpeg_path or not self.app.caps.ffprobe_path:
            self.status.set('FFmpeg 尚未就绪，请稍后生成代理。')
            return False
        # Current-camera material is queued first; repeated files encode once.
        camera = self.project.camera_at(self.current)
        clips = sorted(self.project.clips if clips is None else clips, key=lambda c: (
            c.camera != camera, not (c.start <= self.current < c.start+c.duration), c.camera, c.start))
        sources = {}
        for clip in clips:
            key = _identity(clip.path)
            if key not in sources:
                sources[key] = {'source': clip.path, 'stamp': _stamp(clip.path), 'clips': []}
            sources[key]['clips'].append((clip.id, clip.proxy_path))
        requests = list(sources.values())
        self._quick_proxy_description = ({'h264': 'H.264', 'dnxhr_lb': 'DNxHR LB', 'prores_proxy': 'ProRes Proxy'}[options.codec]
                                         if options is not None else '1080p')
        self._quick_proxy_token += 1
        token = self._quick_proxy_token
        cancel = threading.Event()
        self._quick_proxy_cancel = cancel
        self._set_quick_proxy_running(True)
        if not vars(self).get('_color_mode', False):
            self.proxy_var.set(True)
        self._configure_player()
        self.quick_proxy_status.set(f'0/{len(requests)}')
        self.status.set(f'后台逐个准备 {len(requests)} 份 {self._quick_proxy_description} 代理，完成后自动接入；可以继续剪辑。')
        ffmpeg, ffprobe, caps = self.app.caps.ffmpeg_path, self.app.caps.ffprobe_path, self.app.caps
        jobs = self.jobs

        def worker():
            successful, failures = 0, []
            try:
                from quick_proxy import prepare_1080p_proxy
                for index, request in enumerate(requests):
                    if cancel.is_set():
                        break
                    # At most one transcode competes with the visible preview decoders.
                    last_report = [0.]
                    def progress(percent, phase):
                        now = time.monotonic()
                        if now-last_report[0] >= .2 or percent >= 100:
                            last_report[0] = now
                            jobs.put(('quick_proxy_progress', (token, index, len(requests), float(percent))))
                    try:
                        if options is None:
                            path = prepare_1080p_proxy(request['source'], ffmpeg, ffprobe, caps,
                                                      cancel_event=cancel, progress=progress)
                        else:
                            from configured_proxy import prepare_configured_proxy
                            path = prepare_configured_proxy(request['source'], ffmpeg, ffprobe, caps, options,
                                                            cancel_event=cancel, progress=progress)
                        if cancel.is_set():
                            break
                        successful += 1
                        jobs.put(('quick_proxy_ready', (token, request, str(path))))
                    except ExportCancelled:
                        break
                    except Exception as exc:
                        failures.append((request['source'], str(exc)))
                        jobs.put(('quick_proxy_error', (token, request['source'], str(exc))))
            except Exception as exc:
                failures.append(('', str(exc)))
                jobs.put(('quick_proxy_error', (token, '', str(exc))))
            finally:
                jobs.put(('quick_proxy_done', (token, successful, len(requests), failures, cancel.is_set())))

        # Keep Python alive long enough to reap a cancelled FFmpeg on exit.
        self._quick_proxy_thread = threading.Thread(target=worker, name='multicam-1080p-proxies', daemon=False)
        self._quick_proxy_thread.start()
        return True

    def cancel_quick_proxy(self):
        if self._quick_proxy_running:
            self._quick_proxy_cancel.set()
            self.quick_proxy_status.set('正在取消…')
            self.quick_proxy_cancel_button.configure(state='disabled')
            self.status.set('正在停止代理任务；已完成并挂载的代理会保留。')

    def _reset_quick_proxy(self):
        window = vars(self).get('_proxy_settings_window')
        if window is not None and window.winfo_exists(): window.destroy()
        self._quick_proxy_cancel.set()
        self._quick_proxy_token += 1
        self._set_quick_proxy_running(False)
        self.quick_proxy_status.set('')
        self._reset_proxy_link()

    def _close_quick_proxy(self):
        window = vars(self).get('_proxy_settings_window')
        if window is not None and window.winfo_exists(): window.destroy()
        self._quick_proxy_cancel.set()
        self._quick_proxy_token += 1
        self._reset_proxy_link()

    def _reset_proxy_link(self):
        event = vars(self).get('_proxy_link_cancel')
        if event is not None:
            event.set()
        self._proxy_link_token = vars(self).get('_proxy_link_token', 0) + 1
        self._proxy_link_running = False

    def cancel_proxy_link(self):
        event = vars(self).get('_proxy_link_cancel')
        if event is not None and vars(self).get('_proxy_link_running', False):
            event.set()
            self.status.set('正在停止代理链接校验；当前代理保持不变。')

    def _selected_proxy_sources(self):
        """Resolve explicit media/camera and timeline selections to originals."""
        tree = vars(self).get('media_tree')
        identifiers = set(tree.selection()) if tree is not None else set()
        if not identifiers:
            identifiers = {key[1] for key in vars(self).get('_timeline_selection', ()) if key[0] == 'clip'}
        selected = [clip for clip in self.project.clips if clip.id in identifiers
                    or f'camera_{clip.camera}' in identifiers]
        if not identifiers and not selected:
            getter = getattr(self, '_selected_clip', None)
            clip = getter() if getter else None
            if clip is not None:
                selected = [clip]
        unique = {}
        for clip in selected:
            unique.setdefault(_identity(clip.path), clip.path)
        return list(unique.values())

    def link_existing_proxy(self):
        if vars(self).get('_proxy_link_running', False):
            self.status.set('正在检查已有代理，请等待完成或在链接菜单中取消。')
            return False
        sources = self._selected_proxy_sources()
        if not sources:
            self.status.set('请先在素材列表或时间线选择原片，也可以选择只含一份原片的机位。')
            return False
        if len(sources) != 1:
            self.status.set('选区包含多份原片：请只选一段手动链接，或使用“为所选机位 / 素材从文件夹匹配”。')
            return False
        path = filedialog.askopenfilename(parent=self,
            title=f'为 {Path(sources[0]).name} 选择完整代理（文件名可不同）',
            filetypes=[('视频代理', '*.mp4 *.mov *.mkv *.mxf *.avi *.mts *.m2ts *.webm *.m4v *.lrv *.mpg *.mpeg *.wmv *.ts'), ('所有文件', '*.*')])
        return self._start_proxy_link([(sources[0], path)]) if path else False

    def link_proxy_folder(self, *, selected_only=False):
        if vars(self).get('_proxy_link_running', False):
            self.status.set('正在检查已有代理，请等待完成或在链接菜单中取消。')
            return False
        if not self.project.clips:
            self.status.set('请先导入机位素材，再链接已有代理。')
            return False
        sources = self._selected_proxy_sources() if selected_only else None
        if selected_only and not sources:
            self.status.set('请先选择机位、素材或时间线片段，再批量链接该选区的代理。')
            return False
        folder = filedialog.askdirectory(parent=self, title='选择代理文件夹（含达芬奇 Proxy 子目录，支持 Proxy / PRX 命名）')
        return self._start_proxy_link(folder=folder, source_paths=sources) if folder else False

    def _start_proxy_link(self, pairs=None, *, folder=None, source_paths=None):
        if vars(self).get('_proxy_link_running', False):
            return False
        ffprobe = self.app.caps.ffprobe_path
        if not ffprobe:
            self.status.set('ffprobe 尚未就绪，暂时无法校验已有代理。')
            return False
        requests = {}
        selected_sources = None if source_paths is None else {_identity(path) for path in source_paths}
        all_originals = [clip.path for clip in self.project.clips]
        for clip in self.project.clips:
            key = _identity(clip.path)
            if selected_sources is not None and key not in selected_sources:
                continue
            if key not in requests:
                requests[key] = {'source': clip.path, 'stamp': _stamp(clip.path), 'clips': []}
            requests[key]['clips'].append((clip.id, clip.proxy_path))
        self._proxy_link_token = vars(self).get('_proxy_link_token', 0) + 1
        token = self._proxy_link_token
        cancel = self._proxy_link_cancel = threading.Event()
        self._proxy_link_running = True
        # Respect an explicit later switch-off while validation runs.
        if not vars(self).get('_color_mode', False):
            self.proxy_var.set(True)
        if self.player:
            self.player.submit('proxy_update', bindings=[], use_proxies=self._preview_use_proxies())
        self.status.set('后台检查已有代理的视频与完整时长，可以继续剪辑…')
        jobs = self.jobs

        def worker():
            ready, issues = [], []
            try:
                from external_proxy_link import match_proxy_folder, validate_existing_proxy
                selected = pairs
                if folder:
                    selected, issues = match_proxy_folder(
                        [item['source'] for item in requests.values()], folder, cancel, exclude_paths=all_originals)
                for source, path in selected or ():
                    if cancel.is_set():
                        raise ExportCancelled('已取消链接代理。')
                    request = requests.get(_identity(source))
                    if request is None:
                        continue
                    try:
                        before = _stamp(path)
                        validate_existing_proxy(ffprobe, source, path, cancel)
                        if before is None or _stamp(path) != before or _stamp(source) != request['stamp']:
                            raise ValueError('文件在校验期间发生变化，请重新链接。')
                        ready.append((request, path, before))
                    except ExportCancelled:
                        raise
                    except Exception as error:
                        issues.append((source, str(error)))
            except ExportCancelled:
                pass
            except Exception as error:
                issues.append((folder or '', str(error)))
            finally:
                jobs.put(('quick_proxy_link_done', (token, ready, issues, cancel.is_set())))

        self._proxy_link_thread = threading.Thread(target=worker, name='link-existing-proxies', daemon=False)
        self._proxy_link_thread.start()
        return True

    def _finish_proxy_link(self, payload):
        token, ready, issues, cancelled = payload
        if token != vars(self).get('_proxy_link_token', 0):
            return True
        self._proxy_link_running = False
        if cancelled or self._proxy_link_cancel.is_set():
            self.status.set('已取消代理链接校验，当前代理保持不变。')
            return True
        bindings, changes, linked = [], [], []
        for request, path, stamp in ready:
            if _stamp(path) != stamp or _stamp(request['source']) != request['stamp']:
                issues.append((request['source'], '文件已变化，未挂载。'))
                continue
            initial = dict(request['clips'])
            for clip in self.project.clips:
                if (clip.id in initial and _identity(clip.path) == _identity(request['source'])
                        and clip.proxy_path in (initial[clip.id], path)):
                    changes.append((clip, path))
                    bindings.append({'id': clip.id, 'source': clip.path, 'proxy': path})
            if any(item['source'] == request['source'] for item in bindings):
                linked.append((request['source'], path))
        if changes:
            self._remember()
            for clip, path in changes:
                clip.proxy_path = path
                clip.proxy_disabled = False
            from proxy_cache import register_proxy
            for source, path in linked:
                register_proxy(source, path)
            self._mark_dirty()
            self._refresh_proxy_badges(force=True)
            if self.player:
                self.player.submit('proxy_update', bindings=bindings, use_proxies=self._preview_use_proxies())
        for source, error in issues:
            self.app._log(f'链接代理：{source}\n{error}')
        detail = ''
        if issues:
            source, reason = issues[0]
            detail = f' {len(issues)} 份未匹配或校验失败：{Path(source).name} · {reason}'
            if len(issues) > 1:
                detail += ' 其余见任务日志。'
        self.status.set(f'已链接 {len(linked)} 份已有代理；导出使用原片。' + detail)
        return True

    def _handle_quick_proxy_job(self, kind, payload):
        if not kind.startswith('quick_proxy_'):
            return False
        if kind == 'quick_proxy_link_done':
            return self._finish_proxy_link(payload)
        if payload[0] != self._quick_proxy_token:
            return True
        if kind == 'quick_proxy_progress':
            if not self._quick_proxy_cancel.is_set():
                _, index, total, percent = payload
                self.quick_proxy_status.set(f'{index}/{total} · {percent:.0f}%')
        elif kind == 'quick_proxy_ready':
            if self._quick_proxy_cancel.is_set():
                return True
            _, request, path = payload
            if not Path(path).is_file() or _stamp(request['source']) != request['stamp']:
                return True
            initial = dict(request['clips'])
            bindings = []
            for clip in self.project.clips:
                if (clip.id in initial and _identity(clip.path) == _identity(request['source'])
                        and clip.proxy_path in (initial[clip.id], path)):
                    clip.proxy_path = path
                    clip.proxy_disabled = False
                    bindings.append({'id': clip.id, 'source': clip.path, 'proxy': path})
            if bindings:
                self._mark_dirty()
                self._refresh_proxy_badges(force=True)
                if self.player:
                    self.player.submit('proxy_update', bindings=bindings, use_proxies=self._preview_use_proxies())
        elif kind == 'quick_proxy_error':
            _, source, error = payload
            self.app._log(f'代理失败：{source}\n{error}')
        elif kind == 'quick_proxy_done':
            _, completed, total, failures, cancelled = payload
            self._set_quick_proxy_running(False)
            description = vars(self).get('_quick_proxy_description', '1080p')
            self.quick_proxy_status.set(('已取消 ' if cancelled else description+' ') + f'{completed}/{total}')
            self.status.set((f'已取消代理任务，保留 {completed} 份已完成代理。' if cancelled else
                f'{description} 代理完成 {completed}/{total}；预览使用代理，导出使用原片。') +
                (f' {len(failures)} 份失败，详见任务日志，可再次点击重试。' if failures else ''))
        return True
