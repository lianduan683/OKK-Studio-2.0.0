"""Typed timeline selection, intersecting marquee, and undoable group gestures."""
from __future__ import annotations

import copy
import math
from pathlib import Path
import tkinter as tk

from timeline_track_move import track_move_targets, validate_track_move, apply_track_move
from editor_core import format_signed_time, format_time
from timeline_edits import (delete_source_clips, move_source_clips, source_move_delta,
                            remove_program_boundaries, program_boundaries_for_ranges, finalize_source_edit)
from timeline_audio import source_audio_clips, master_audio_clips
from timeline_link import edit_keys, preserve_source_audio, move_source_audio, delete_source_audio


class TimelineSelectionMixin:
    def _init_timeline_selection(self):
        self._timeline_selection = set()
        self._clip_enabled_key_down = False
        self._selection_project = self.project
        self._selection_gesture = None
        self._selection_pan_after = None

    def _clip_enabled_key_press(self):
        if not self._clip_enabled_key_down:
            self._toggle_timeline_selection_enabled()
            self._clip_enabled_key_down = True
        return 'break'

    def _clip_enabled_key_release(self):
        self._clip_enabled_key_down = False

    def _toggle_timeline_selection_enabled(self):
        if not self._available(): return False
        if self._selection_gesture: self._finish_selection_gesture()
        from timeline_enable import toggle_timeline_enabled
        keys = set(self._timeline_selection)
        try:
            candidate, count, enabled, selection = toggle_timeline_enabled(self.project, keys)
        except (ValueError, OSError) as error:
            self.status.set(str(error)); return False
        if not count:
            self.status.set('请先选中时间线上的视频或音频素材，再按 D 禁用 / 启用。')
            return False
        self._stop_transport_hold()
        self.pause()
        self._remember_timeline_change()
        self.project = candidate
        self._refresh()
        self._set_timeline_selection(selection)
        self.status.set(('已启用' if enabled else '已禁用')+f' {count} 项所选素材；D 再次切换，Ctrl+Z 撤销。')
        return True

    def _bind_timeline_selection(self):
        self.timeline.bind('<Delete>', self._delete_timeline_selection)
        self.timeline.bind('<BackSpace>', self._delete_timeline_selection)
        self.timeline.bind('<Control-a>', self._select_all_timeline)
        self.timeline.bind('<Control-A>', self._select_all_timeline)
        self.timeline.bind('<FocusOut>', lambda _e: self._finish_selection_gesture(cancel=True), add='+')
        self.timeline.bind('<Unmap>', lambda _e: self._finish_selection_gesture(cancel=True), add='+')

    def _capture_timeline_range(self, project):
        try:
            start, end, _fps = self._read_range()
            if (project.duration <= 0 or start >= self.project.duration
                    or (end is not None and end > self.project.duration+1/self.project.fps)): return
            project.range_start, project.range_end = start, end
        except ValueError:
            pass

    def _remember_timeline_change(self):
        self._remember()
        self._capture_timeline_range(self.undo_stack[-1])

    def _restore_timeline_range_fields(self):
        self._loading_fields = True
        try:
            self.start_var.set(format_time(self.project.range_start))
            self.end_var.set(format_time(self.project.range_end) if self.project.range_end is not None else '')
            self.fps_var.set(f'{self.project.fps:.12g}')
        finally:
            self._loading_fields = False

    def _timeline_item_keys(self):
        result = {}
        for name, kind in (('timeline_clip_items', 'clip'), ('timeline_subtitle_items', 'subtitle'),
                           ('timeline_transition_items', 'transition'), ('timeline_program_items', 'program')):
            result.update((item, (kind, identifier)) for item, identifier in getattr(self, name, {}).items())
        master_items = getattr(self, 'timeline_master_audio_items', {})
        result.update((item, ('audio', master_items.get(item, 'master')))
                      for item in getattr(self, 'timeline_audio_items', ()))
        result.update((item, ('camera_audio', identifier))
                      for item, identifier in getattr(self, 'timeline_camera_audio_items', {}).items())
        return result

    def _timeline_hit_key(self, event):
        if self._timeline_ruler_contains(event): return None
        x, y = self.timeline.canvasx(event.x), self.timeline.canvasy(event.y)
        mapping = self._timeline_item_keys()
        key = next((mapping[item] for item in reversed(self.timeline.find_overlapping(x, y, x, y))
                     if item in mapping), None)
        if (key and key[0] == 'camera_audio' and self.project.timeline_link_enabled
                and any(clip.id == key[1] for clip in self.project.clips)):
            return ('clip', key[1])
        return key

    def _marquee_keys(self, left, top, right, bottom):
        # Geometry comes from the model, so auto-scrolling a selection keeps
        # clips already inside the box even after their Canvas items are culled.
        keys = set()
        scale, origin = self._timeline_scale(), self._timeline_origin()
        def tx(value): return self._timeline_left+(value-origin)*scale
        def touches(x1, y1, x2, y2):
            return x2 >= left and x1 <= right and y2 >= top and y1 <= bottom
        for clip in self.project.clips:
            bounds = self._timeline_track_bounds.get(clip.camera)
            if bounds and touches(tx(clip.start), bounds[0]+self._px(1),
                                  tx(clip.end), bounds[1]-self._px(1)):
                keys.add(('clip', clip.id))
        program_top, program_bottom = self._timeline_program_bounds
        if bottom >= program_top and top <= program_bottom:
            cached = vars(self).get('_timeline_span_cache')
            if cached:
                for span in cached[1]:
                    if touches(tx(span.start), program_top+self._px(4),
                               tx(span.end), program_bottom-self._px(3)):
                        keys.add(('program', (span.start, span.end)))
            for item in self.project.transitions:
                x1, x2 = tx(item.time-item.duration/2), tx(item.time+item.duration/2)
                if x2-x1 < self._px(10): x1, x2 = tx(item.time)-self._px(5), tx(item.time)+self._px(5)
                if touches(x1, program_top+self._px(2), x2, program_bottom-self._px(2)):
                    keys.add(('transition', item.time))
        subtitle = getattr(self, '_timeline_subtitle_bounds', None)
        if subtitle:
            offset, duration = self.project.subtitles.offset, self._timeline_view_duration()
            for cue in self.project.subtitles.cues:
                start, end = max(0., cue.start+offset), min(duration, cue.end+offset)
                if start < end and touches(tx(start), subtitle[0]+self._px(2),
                                           tx(end), subtitle[1]-self._px(2)):
                    keys.add(('subtitle', cue.id))
        audio = getattr(self, '_timeline_audio_bounds', None)
        videos = {clip.id for clip in self.project.clips}
        for clip in source_audio_clips(self.project):
            bounds = getattr(self, '_timeline_audio_track_bounds', {}).get(clip.camera)
            if bounds and clip.has_audio is not False and touches(
                    tx(clip.start), bounds[0]+self._px(2), tx(clip.end), bounds[1]-self._px(2)):
                linked = self.project.timeline_link_enabled and clip.id in videos
                keys.add(('clip' if linked else 'camera_audio', clip.id))
        if audio and self.project.master_audio:
            for clip in master_audio_clips(self.project):
                if touches(tx(clip.start), audio[0]+self._px(3), tx(clip.end), audio[1]-self._px(3)):
                    keys.add(('audio', clip.id))
        return keys

    def _set_timeline_selection(self, keys, *, redraw=True):
        previous_program_range = self.selected_program_range
        keys = set(keys)
        if self.project.timeline_link_enabled:
            videos = {clip.id for clip in self.project.clips}
            keys = {('clip', identifier) if kind == 'camera_audio' and identifier in videos else (kind, identifier)
                    for kind, identifier in keys}
        changed = keys != self._timeline_selection or self._selection_project is not self.project
        self._selection_project = self.project
        self._timeline_selection = keys
        ranges = [key[1] for key in keys if key[0] == 'program']
        self.selected_program_range = ((min(r[0] for r in ranges), max(r[1] for r in ranges)) if ranges else None)
        if changed:
            ids = [clip.id for clip in self.project.clips if ('clip', clip.id) in keys and self.media_tree.exists(clip.id)]
            self.media_tree.selection_set(ids)
        if redraw: self._draw_timeline_selection()
        if previous_program_range != self.selected_program_range:
            if self.selected_program_range is None:
                self.selected_cut = None
                if self.cut_tree.selection():
                    self.cut_tree.selection_remove(*self.cut_tree.selection())
            refresh = vars(self).get('creative_panel_refresh')
            if refresh: refresh()
            if vars(self).get('clip_inspector'): self.clip_inspector.refresh()
        elif changed and vars(self).get('clip_inspector'):
            self.clip_inspector.refresh()

    def _clear_timeline_selection(self):
        had_selection = bool(self._timeline_selection or self.selected_program_range)
        self._set_timeline_selection(set())
        if had_selection:
            self.status.set('已取消片段选中；点击机位将在播放头记录切点。')

    def _draw_timeline_selection(self):
        canvas = self.timeline
        canvas.delete('timeline-selected')
        if self._selection_project is not self.project and self._selection_gesture is None:
            self._timeline_selection.clear()
            self._selection_project = self.project
        # Programme outlines belong to selection rendering too. Leaving them
        # in draw_timeline() makes blank clicks clear state but retain blue
        # borders until an unrelated full redraw.
        canvas.delete('selection')
        program_range = self.selected_program_range
        for item, (start, end) in self.timeline_program_items.items():
            if canvas.type(item) != 'rectangle': continue
            chosen = (program_range is not None and start >= program_range[0]-1e-6
                      and end <= program_range[1]+1e-6)
            canvas.itemconfigure(item, outline='#58a6d6' if chosen else '#91a0ac',
                                 width=self._px(2) if chosen else 1)
        top, bottom = self._timeline_program_bounds
        if (program_range and bottom >= canvas.canvasy(0)
                and top <= canvas.canvasy(canvas.winfo_height())):
            canvas.create_rectangle(self._timeline_x(program_range[0]), top+self._px(2),
                self._timeline_x(program_range[1]), bottom-self._px(1),
                outline='#58a6d6', width=max(1, self._px(2)), tags=('selection',))
        selected = edit_keys(self.project, self._timeline_selection)
        for item, key in self._timeline_item_keys().items():
            if key not in selected or canvas.type(item) != 'rectangle': continue
            bounds = canvas.coords(item)
            canvas.create_rectangle(*bounds, outline='#7acbff', width=max(2, self._px(2)),
                                    tags=('timeline-selected',))
        canvas.delete('timeline-marquee')
        drag = self._selection_gesture
        if drag and drag['kind'] == 'marquee' and drag['moved']:
            canvas.create_rectangle(drag['x'], drag['y'], drag['last_x'], drag['last_y'],
                outline='#7acbff', fill='#58a6d6', stipple='gray75', width=max(1, self._px(1)),
                tags=('timeline-marquee',))
        canvas.tag_raise('head')

    def _select_all_timeline(self, _event=None):
        if not self._available(): return 'break'
        # The programme overview duplicates source clips. Select editable media
        # and subtitles, keeping the continuous master audio explicitly chosen.
        keys = {('clip', clip.id) for clip in self.project.clips}
        videos = {clip.id for clip in self.project.clips}
        keys.update(('camera_audio', clip.id) for clip in source_audio_clips(self.project)
                    if clip.has_audio is not False and
                    (not self.project.timeline_link_enabled or clip.id not in videos))
        keys.update(('subtitle', cue.id) for cue in self.project.subtitles.cues)
        self._set_timeline_selection(keys)
        self.status.set(f'已选中 {len(keys)} 个素材/字幕；可成组拖动或 Delete 删除。')
        return 'break'

    def _selection_press(self, event):
        if self._timeline_ruler_contains(event): return False
        y = self.timeline.canvasy(event.y)
        if y < self._timeline_ruler_h: return False
        if self._stack_track_at(event) is not None: return False
        self.timeline.focus_set()
        key = self._timeline_hit_key(event)
        additive = bool(getattr(event, 'state', 0) & (0x1 | 0x4))
        if key and key[0] in {'program', 'transition'} and not additive:
            self._set_timeline_selection({key}, redraw=False)
            return False  # Retain programme cut/transition inspector gestures.
        self._stop_transport_hold()
        self.pause()
        if key:
            selected = set(self._timeline_selection)
            if additive:
                if key in selected: selected.remove(key)
                else: selected.add(key)
            elif key not in selected:
                selected = {key}
            self._set_timeline_selection(selected)
            if key not in selected: return True
            if key[0] == 'audio':
                self.status.set('已选中主音频片段；Ctrl+B 切开，Delete 删除，Ctrl+Z 恢复。')
                return True
            if key[0] in {'program', 'transition'}: return True
            effective = edit_keys(self.project, selected)
            clips = {clip.id: clip.start for clip in self.project.clips if ('clip', clip.id) in effective}
            audio = {clip.id: clip.start for clip in source_audio_clips(self.project)
                     if ('camera_audio', clip.id) in effective and clip.id not in clips}
            cues = {cue.id: (cue.start, cue.end) for cue in self.project.subtitles.cues
                    if ('subtitle', cue.id) in selected}
            self._capture_timeline_geometry()
            self._selection_gesture = dict(kind='move', project=self.project,
                x=self.timeline.canvasx(event.x), y=y, moved=False, changed=False, delta=0.,
                clips=clips, cues=cues, audio=audio,
                audio_anchor=any(top <= y <= bottom for top, bottom in
                                 getattr(self, '_timeline_audio_track_bounds', {}).values()),
                clip_cameras={clip.id: clip.camera for clip in self.project.clips if clip.id in clips},
                anchor_camera=next((clip.camera for clip in self.project.clips if key == ('clip', clip.id)), None),
                track_order=list(self._timeline_camera_order()), track_bounds=dict(self._timeline_track_bounds),
                track_changed=False, stack_enabled=self.project.video_stack_enabled,
                empty_tracks=list(self.project.timeline_empty_tracks),
                stack_order=list(self.project.video_stack_order), stabilizations=[(item, item.start, item.end)
                    for item in self.project.stabilizations if item.source_id in clips],
                undo=list(self.undo_stack), redo=list(self.redo_stack), dirty=self.dirty,
                pointer=(event.x, event.y), selection=set(selected))
            self.timeline.configure(cursor='fleur')
            self.status.set(f'选中 {len(selected)} 项 · 拖动一起移动 · Ctrl/Shift 点选增减 · Esc 取消')
            return True
        # Empty-space dragging starts a marquee; a partial rectangle overlap
        # counts, including clips much longer than the visible viewport.
        if not additive: self._clear_timeline_selection()
        self._selection_gesture = dict(kind='marquee', project=self.project,
            x=self.timeline.canvasx(event.x), y=y, last_x=self.timeline.canvasx(event.x), last_y=y,
            moved=False, base=set(self._timeline_selection) if additive else set(), pointer=(event.x, event.y))
        return True

    def _selection_motion(self, event):
        drag = self._selection_gesture
        if not drag: return False
        if drag['project'] is not self.project:
            self._finish_selection_gesture(cancel=True)
            return True
        drag['pointer'] = (event.x, event.y)
        x, y = self.timeline.canvasx(event.x), self.timeline.canvasy(event.y)
        if not drag['moved'] and max(abs(x-drag['x']), abs(y-drag['y'])) < self._px(4): return True
        drag['moved'] = True
        if drag['kind'] == 'marquee':
            drag['last_x'], drag['last_y'] = x, y
            left, right = sorted((drag['x'], x)); top, bottom = sorted((drag['y'], y))
            keys = set(drag['base'])
            keys.update(self._marquee_keys(left, top, right, bottom))
            self._set_timeline_selection(keys)
            self.status.set(f'框选 {len(keys)} 项 · 碰到片段即可选中 · Delete 删除')
        else:
            fps = self.project.fps
            delta = math.floor((x-drag['x'])/self._timeline_scale()*fps+.5)/fps
            if drag['cues']:
                minimum = math.ceil(-min(start for start, _ in drag['cues'].values())*fps-1e-8)/fps
                delta = max(delta, minimum)
            targets = drag['clip_cameras'] if drag['audio_anchor'] else track_move_targets(self.project, drag, y)
            current_cameras = {clip.id: clip.camera for clip in self.project.clips if clip.id in drag['clips']}
            if abs(delta-drag['delta']) < .25/fps and current_cameras == targets:
                self._schedule_selection_pan()
                return True
            increment = delta-drag['delta']
            try:
                validate_track_move(self.project, drag, targets, delta)
                if drag['clips']: source_move_delta(self.project, drag['clips'], increment, target_cameras=targets)
            except ValueError as error:
                self.status.set(str(error)); return True
            if not drag['changed']:
                self._remember_timeline_change(); drag['baseline'] = self.undo_stack[-1]; drag['changed'] = True
                preserve_source_audio(self.project, drag['audio'])
                # Freeze picture-only audio even for a purely vertical move.
                if not self.project.timeline_link_enabled:
                    preserve_source_audio(self.project, drag['clips'])
            if drag['clips']: move_source_clips(self.project, drag['clips'], increment, target_cameras=targets)
            if drag['audio']: move_source_audio(self.project, drag['audio'], increment)
            apply_track_move(self.project, drag, targets)
            drag['track_changed'] = targets != drag['clip_cameras']
            for cue in self.project.subtitles.cues:
                if cue.id in drag['cues']:
                    start, end = drag['cues'][cue.id]; cue.start, cue.end = start+delta, end+delta
            for item, start, end in drag['stabilizations']:
                item.start, item.end = max(0., start+delta), end+delta
            drag['delta'] = delta
            self._queue_timeline_redraw()
            self.status.set(f'成组移动 {format_signed_time(delta)} · Esc 取消 · 松开提交')
        self._schedule_selection_pan()
        return True

    def _schedule_selection_pan(self):
        drag = self._selection_gesture
        if not drag or self._selection_pan_after is not None: return
        x, y = drag['pointer']; margin = self._px(22)
        if x < margin or x > self.timeline.winfo_width()-margin or y < margin or y > self.timeline.winfo_height()-margin:
            self._selection_pan_after = self.after(30, self._selection_auto_pan)

    def _selection_auto_pan(self):
        self._selection_pan_after = None
        drag = self._selection_gesture
        if not drag or not self.alive: return
        x, y = drag['pointer']; margin = self._px(22)
        dx = -1 if x < margin else 1 if x > self.timeline.winfo_width()-margin else 0
        dy = -1 if y < margin else 1 if y > self.timeline.winfo_height()-margin else 0
        if dx: self.timeline.xview_scroll(dx, 'units')
        if dy: self.timeline.yview_scroll(dy, 'units')
        if dx or dy:
            self.draw_timeline()
            from types import SimpleNamespace
            self._selection_motion(SimpleNamespace(x=x, y=y))

    def _finish_selection_gesture(self, *, cancel=False):
        drag = self._selection_gesture
        if drag is None: return False
        self._selection_gesture = None
        if self._selection_pan_after is not None:
            self.after_cancel(self._selection_pan_after); self._selection_pan_after = None
        self._cancel_timeline_redraw()
        self._timeline_drag_geometry = None
        self.timeline.configure(cursor='')
        self.timeline.delete('timeline-marquee')
        if drag['kind'] == 'move' and drag['changed']:
            reverted = cancel or (abs(drag['delta']) < .25/self.project.fps and not drag['track_changed'])
            error = None
            if not reverted:
                try:
                    self._capture_timeline_range(self.project)
                    finalize_source_edit(self.project)
                except ValueError as exc: reverted, error = True, str(exc)
            if reverted:
                self.project = drag['baseline']
                self.undo_stack, self.redo_stack, self.dirty = drag['undo'], drag['redo'], drag['dirty']
                self.project_label.configure(text=(Path(self.project_path).name if self.project_path else '未保存工程')
                    + (' *' if self.dirty else ''))
            self._selection_project = self.project
            self._restore_timeline_range_fields()
            self._refresh()
            self._set_timeline_selection(drag['selection'])
            self.seek(self.current)
            self.status.set(error or ('已取消移动。' if reverted else '已移动所选素材/字幕；Ctrl+Z 撤销。'))
        else:
            if cancel and drag['kind'] == 'marquee': self._set_timeline_selection(drag['base'])
            self._draw_timeline_selection()
        return True

    def _delete_timeline_selection(self, _event=None):
        if not self._available(): return 'break'
        if self._selection_gesture: self._finish_selection_gesture(cancel=True)
        keys = edit_keys(self.project, self._timeline_selection)
        if not keys: return 'break'
        candidate = copy.deepcopy(self.project)
        self._capture_timeline_range(candidate)
        count = 0
        try:
            ranges = [key[1] for key in keys if key[0] == 'program']
            points = program_boundaries_for_ranges(self.project, ranges)
            if points: count += remove_program_boundaries(candidate, points)
            video_ids = {key[1] for key in keys if key[0] == 'clip'}
            count += delete_source_audio(candidate, {key[1] for key in keys if key[0] == 'camera_audio'} -
                                         (video_ids if candidate.timeline_link_enabled else set()))
            count += delete_source_clips(candidate, video_ids)
            ids = {key[1] for key in keys if key[0] == 'subtitle'}
            before = len(candidate.subtitles.cues)
            candidate.subtitles.cues = [cue for cue in candidate.subtitles.cues if cue.id not in ids]
            count += before-len(candidate.subtitles.cues)
            times = {key[1] for key in keys if key[0] == 'transition'}
            before = len(candidate.transitions)
            candidate.transitions = [item for item in candidate.transitions if item.time not in times]
            count += before-len(candidate.transitions)
            master_ids = {identifier for kind, identifier in keys if kind == 'audio'}
            if master_ids and candidate.master_audio:
                before = master_audio_clips(candidate)
                remaining = [clip for clip in before if clip.id not in master_ids]
                count += len(before)-len(remaining)
                candidate.master_audio_clips = remaining
                if not remaining:
                    candidate.master_audio, candidate.master_duration = '', 0.
            if count: finalize_source_edit(candidate)
        except ValueError as error:
            self.status.set(str(error)); return 'break'
        if count:
            self.pause(); self._remember_timeline_change(); self.project = candidate
            self.media_tree.selection_set(())
            self._set_timeline_selection(set(), redraw=False)
            self._restore_timeline_range_fields()
            self._refresh(); self.seek(self.current)
            self.status.set(f'已删除 {count} 项时间线内容；原文件保留，Ctrl+Z 撤销。')
        return 'break'

    def _rekey_timeline_boundary(self, drag, reverted):
        if not drag: return
        old, new = drag['original'], drag['original'] if reverted else drag['current']
        fps = self.project.fps
        def moved(value):
            return new if math.floor(value*fps+.5) == math.floor(old*fps+.5) else value
        keys = set()
        for kind, identifier in self._timeline_selection:
            if kind == 'program': identifier = tuple(moved(point) for point in identifier)
            elif kind == 'transition': identifier = moved(identifier)
            keys.add((kind, identifier))
        self._selection_project = self.project
        self._set_timeline_selection(keys, redraw=False)

    def _selection_context(self, event):
        key = self._timeline_hit_key(event)
        if key and key[0] == 'program': return False
        if key is None and not self._timeline_selection:
            top, bottom = self._timeline_program_bounds
            if top <= self.timeline.canvasy(event.y) <= bottom: return False
            return self._show_timeline_insert_menu(event)
        self.timeline.focus_set(); self.pause()
        if key is not None and key not in self._timeline_selection: self._set_timeline_selection({key})
        menu = tk.Menu(self, tearoff=False, bg='#292b2e', fg='#dedfe3', activebackground='#3c5263')
        source_count = sum(key[0] == 'clip' for key in self._timeline_selection)
        menu.add_command(label='合并选中素材（首尾接齐）', command=self._merge_timeline_selection,
                         state='normal' if source_count >= 2 else 'disabled')
        self._append_selection_sync_menu(menu)
        label = '取消绑定主音轨' if self._timeline_selection == {('audio', 'master')} else '删除所选内容'
        menu.add_command(label=label, accelerator='Delete', command=self._delete_timeline_selection)
        menu.add_command(label='全选素材与字幕', accelerator='Ctrl+A', command=self._select_all_timeline)
        self._append_multicam_view_menu(menu)
        menu.add_separator()
        menu.add_command(label='撤销', accelerator='Ctrl+Z', command=self.undo,
                         state='normal' if self.undo_stack else 'disabled')
        self._append_timeline_insert_menu(menu, event)
        self.timeline_context_menu = menu
        try: menu.tk_popup(event.x_root, event.y_root)
        finally: menu.grab_release()
        return True
