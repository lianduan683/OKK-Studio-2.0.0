"""Build the public Windows core without downloading runtimes or effect packs."""
from __future__ import annotations

import argparse
import ast
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import uuid
import zipfile

ROOT = Path(__file__).resolve().parent
VERSION = "2.0.0"
PRODUCT = f"OKK STUDIO {VERSION}"
SPEC = ROOT / f"OKK_STUDIO_{VERSION}.spec"
CONTRACT_FILES = ("effect_contract_schema.json", "effect_contract_examples/blur-instance.json",
                  "effect_contract_examples/dissolve-instance.json")
NOTICE_FILES = ("LICENSE", "BINARY-LICENSE.txt", "README.md", "UPSTREAM.md",
                "THIRD_PARTY_NOTICES.md", "core-compliance-manifest.json",
                "pedalboard-source-manifest.json", "pedalboard-source-archive.json",
                "PUBLIC-CORE-NOTICE.txt", "CORE-SOURCE-ACCESS.txt",
                "native-build-source-manifest.json", "Pillow-13.0.0-dependencies.json",
                "third-party-source-bundle.json")


def digest(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def checked_child(folder: Path, value: str) -> Path:
    relative = Path(value)
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError(f"Not a relative package path: {value!r}")
    path = (folder / relative).resolve()
    if not path.is_relative_to(folder.resolve()):
        raise ValueError(f"Path escapes its package: {value!r}")
    return path


def verify_inputs() -> tuple[list[dict], list[str]]:
    if os.name != "nt" or sys.version_info[:3] != (3, 12, 10):
        raise RuntimeError("The documented release inputs require Windows 10/11 with CPython 3.12.10.")
    if sys.getwindowsversion().major < 10:
        raise RuntimeError("The public core build targets Windows 10/11 x64.")
    import struct
    if struct.calcsize("P") != 8:
        raise RuntimeError("Use the 64-bit CPython distribution.")
    for path in [SPEC, ROOT / "version_info.txt", *(ROOT / "source" / name for name in CONTRACT_FILES),
                 *(ROOT / name for name in NOTICE_FILES)]:
        if not path.is_file():
            raise FileNotFoundError(f"Required public build input missing: {path.name}")
    for name in CONTRACT_FILES:
        json.loads((ROOT / "source" / name).read_text("utf-8-sig"))
    module = ast.parse((ROOT / "source/rtx5090_exporter.py").read_text("utf-8-sig"))
    versions = [ast.literal_eval(node.value) for node in module.body
                if isinstance(node, ast.Assign)
                and any(isinstance(target, ast.Name) and target.id == "APP_VERSION"
                        for target in node.targets)]
    if versions != [VERSION]:
        raise ValueError(f"Application version is {versions!r}, expected {VERSION}")
    version_tree = ast.parse((ROOT / "version_info.txt").read_text("utf-8-sig"))
    fixed_versions, string_versions = {}, {}
    for node in ast.walk(version_tree):
        if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Name):
            continue
        if node.func.id == "FixedFileInfo":
            fixed_versions = {item.arg: ast.literal_eval(item.value) for item in node.keywords
                              if item.arg in {"filevers", "prodvers"}}
        elif node.func.id == "StringStruct" and len(node.args) == 2:
            key = ast.literal_eval(node.args[0])
            if key in {"FileVersion", "ProductVersion"}:
                string_versions[key] = ast.literal_eval(node.args[1])
    if fixed_versions != {"filevers": (2, 0, 0, 0), "prodvers": (2, 0, 0, 0)} or string_versions != {
            "FileVersion": "2.0.0.0", "ProductVersion": VERSION}:
        raise ValueError("Windows executable version metadata does not match 2.0.0")
    assets = json.loads((ROOT / "small_assets.json").read_text("utf-8"))
    names = [item["path"] for item in assets]
    if len(names) != 16 or len(set(names)) != 16:
        raise ValueError("The public core must have exactly 16 distinct approved UI assets")
    for item in assets:
        path = checked_child(ROOT / "source/assets", item["path"])
        if path.stat().st_size != item["size"] or digest(path) != item["sha256"]:
            raise ValueError(f"UI asset differs from its manifest: {item['path']}")
    licenses = json.loads((ROOT / "core-compliance-manifest.json").read_text("utf-8"))
    for item in licenses["license_files"]:
        path = checked_child(ROOT / "third_party_licenses", item["file"])
        if path.stat().st_size != item["bytes"] or digest(path) != item["sha256"]:
            raise ValueError(f"License differs from its manifest: {item['file']}")
    mismatches = []
    for line in (ROOT / "source/requirements-build.txt").read_text("utf-8").splitlines():
        requirement = line.strip()
        if not requirement or requirement.startswith("#"):
            continue
        name, version = requirement.split("==", 1)
        try:
            installed = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            installed = "not installed"
        if installed != version:
            mismatches.append(f"{name}: expected {version}, found {installed}")
    return assets, mismatches


def audit_core(folder: Path, assets: list[dict]) -> None:
    for name in CONTRACT_FILES:
        packaged = folder / name
        if not packaged.is_file() or digest(packaged) != digest(ROOT / "source" / name):
            raise ValueError(f"Missing or changed packaged effect contract resource: {name}")
    expected = {item["path"] for item in assets}
    actual = {p.relative_to(folder / "assets").as_posix()
              for p in (folder / "assets").rglob("*") if p.is_file()}
    if actual != expected:
        raise ValueError(f"Unexpected core UI asset set: {sorted(actual ^ expected)}")
    for item in assets:
        if digest(folder / "assets" / item["path"]) != item["sha256"]:
            raise ValueError(f"Packaged UI asset changed: {item['path']}")
    forbidden = re.compile(r"^(?:ffmpeg|ffprobe|mpv|gyroflow|exiftool)(?:\.exe)?$|^libmpv.*\.dll$"
                           r"|^api-ms-win-.*\.dll$|^ucrtbase\.dll$", re.I)
    for path in folder.rglob("*"):
        relative = path.relative_to(folder)
        if path.is_symlink():
            raise ValueError(f"Symlink not allowed in the core archive: {relative}")
        if path.is_file() and (forbidden.match(path.name)
                              or any(part.lower() in {"effects_library", "native_runtime"}
                                     for part in relative.parts)):
            raise ValueError(f"Excluded runtime/effect resource found: {relative}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="New output directory; existing paths are refused")
    parser.add_argument("--check", action="store_true", help="Validate inputs and installed versions without building")
    args = parser.parse_args()
    assets, mismatches = verify_inputs()
    if mismatches:
        raise RuntimeError("Install source/requirements-build.txt into the build environment:\n"
                           + "\n".join(mismatches))
    print("Validated application version, 16 UI assets, dependency versions and license hashes.")
    if args.check:
        return 0
    suffix = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8]
    output = (args.output or ROOT / "build-core" / suffix).resolve()
    output.mkdir(parents=True, exist_ok=False)
    python_dir = Path(sys.executable).resolve().parent
    windows_dir = Path(os.environ.get("SystemRoot", r"C:\Windows")).resolve()
    paths = (python_dir, python_dir / "Scripts", windows_dir / "System32", windows_dir)
    if not all(path.is_dir() for path in paths):
        raise RuntimeError("Required Python/Windows directories for the controlled build PATH are missing")
    temporary = output / "temp"
    temporary.mkdir()
    # Keep explicitly supplied PYTHONPATH (for a separate pinned build-deps
    # directory); native wheel .libs directories remain handled by their hooks.
    environment = dict(os.environ, PATH=os.pathsep.join(str(path) for path in paths),
                       PYTHONDONTWRITEBYTECODE="1", PYTHONIOENCODING="utf-8",
                       PYINSTALLER_CONFIG_DIR=str(output / "pyinstaller-cache"),
                       TEMP=str(temporary), TMP=str(temporary))
    command = [sys.executable, "-B", "-m", "PyInstaller", "--noconfirm", "--clean",
               "--distpath", str(output / "dist"), "--workpath", str(output / "work"), str(SPEC)]
    subprocess.run(command, cwd=ROOT, env=environment, check=True)
    core = output / "dist" / PRODUCT
    if not (core / "OKK STUDIO.exe").is_file():
        raise FileNotFoundError("PyInstaller did not produce the expected executable")
    for name in NOTICE_FILES:
        shutil.copy2(ROOT / name, core / name)
    shutil.copytree(ROOT / "third_party_licenses", core / "licenses/supplement")
    audit_core(core, assets)
    package = output / f"OKK-STUDIO-{VERSION}-core.zip"
    with zipfile.ZipFile(package, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(core.rglob("*")):
            if path.is_file():
                archive.write(path, f"{PRODUCT}/{path.relative_to(core).as_posix()}")
    checksums = {package.name: {"bytes": package.stat().st_size, "sha256": digest(package)}}
    (output / "core-checksums.json").write_text(json.dumps(checksums, indent=2) + "\n", encoding="utf-8")
    print(f"Core archive: {package}\nSHA256: {checksums[package.name]['sha256']}")
    print("Publish the application source and Pedalboard corresponding source with this binary.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        print(f"Build failed: {error}", file=sys.stderr)
        raise SystemExit(1)
